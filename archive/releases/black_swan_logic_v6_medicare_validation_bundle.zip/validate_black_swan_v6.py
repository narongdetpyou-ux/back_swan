#!/usr/bin/env python3
"""Run reproducible multi-case and rolling-holdout validation for v6."""

from __future__ import annotations

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from typing import Optional

from black_swan_v5_engine import BlackSwanV5
from black_swan_v6_engine import (
    BlackSwanV6,
    EventEvidence,
    LifecycleEvidence,
    Observation,
)


ROOT = Path(__file__).resolve().parent
PANEL_PATH = ROOT / "medicare_multicase_2013_2024.csv"

SOURCES = {
    "cms_catalog": (
        "https://catalog.data.gov/dataset/"
        "medicare-physician-other-practitioners-by-geography-and-service"
    ),
    "covid_elective": (
        "https://www.cms.gov/newsroom/press-releases/"
        "cms-releases-recommendations-adult-elective-surgeries-non-essential-medical-surgical-dental"
    ),
    "telephone_em": "https://www.cms.gov/files/document/mm11805.pdf",
    "covid_vaccine_codes": (
        "https://www.cms.gov/files/document/"
        "cy-2023-payment-allowances-and-effective-dates-covid-19-vaccines.pdf"
    ),
    "99201_retirement": (
        "https://www.federalregister.gov/documents/2020/12/28/2020-26815/"
        "medicare-program-cy-2021-payment-policies-under-the-physician-fee-schedule-and-other-changes-to-part"
    ),
    "g2211_start": (
        "https://www.cms.gov/newsroom/fact-sheets/"
        "calendar-year-cy-2024-medicare-physician-fee-schedule-final-rule"
    ),
    "90739_context": (
        "https://www.cms.gov/medicare/regulations-guidance/"
        "physician-self-referral/list-cpt-hcpcs-codes"
    ),
}


COVID_PROCEDURE_EVENT = EventEvidence(
    name="COVID-19 response and CMS elective-procedure delay",
    expected_direction="down",
    temporal_overlap=1.00,
    domain_relevance=0.95,
    direct_mechanism=0.90,
    magnitude_alignment=0.80,
    direction_alignment=1.00,
    evidence_quality=1.00,
    source_url=SOURCES["covid_elective"],
)

REGULATORY_90739_CONTEXT = EventEvidence(
    name="CY 2024 §411.355(h) Code List correction for 90739",
    expected_direction="either",
    temporal_overlap=1.00,
    domain_relevance=1.00,
    direct_mechanism=0.10,
    magnitude_alignment=0.10,
    direction_alignment=0.25,
    evidence_quality=1.00,
    source_url=SOURCES["90739_context"],
)

LIFECYCLES = {
    "0001A": LifecycleEvidence(
        "Pfizer first-dose administration code became payable 2020-12-11",
        "new_code", 2020, 1.00, SOURCES["covid_vaccine_codes"],
    ),
    "99441": LifecycleEvidence(
        "Medicare separate payment for telephone E/M during COVID-19 PHE",
        "coverage_start", 2020, 1.00, SOURCES["telephone_em"],
    ),
    "99201": LifecycleEvidence(
        "CPT 99201 deleted for CY 2021 office/outpatient E/M changes",
        "retirement", 2021, 1.00, SOURCES["99201_retirement"],
    ),
    "G2211": LifecycleEvidence(
        "Separate Medicare PFS payment for G2211 began in CY 2024",
        "coverage_start", 2024, 1.00, SOURCES["g2211_start"],
    ),
}


CASES = [
    # Pre-specified 2020 candidate pool with continuous pre-event history.
    ("66984", 2020, COVID_PROCEDURE_EVENT, None, "EXPLAINED_STRUCTURAL_BREAK"),
    ("94010", 2020, COVID_PROCEDURE_EVENT, None, "EXPLAINED_STRUCTURAL_BREAK"),
    ("G0121", 2020, COVID_PROCEDURE_EVENT, None, "EXPLAINED_STRUCTURAL_BREAK"),
    # Same macro event, but below the fixed anomaly thresholds.
    ("36415", 2020, COVID_PROCEDURE_EVENT, None, "NORMAL_WITH_CONTEXT"),
    ("45378", 2020, COVID_PROCEDURE_EVENT, None, "NORMAL_WITH_CONTEXT"),
    ("97110", 2020, COVID_PROCEDURE_EVENT, None, "NORMAL_WITH_CONTEXT"),
    ("99213", 2020, COVID_PROCEDURE_EVENT, None, "NORMAL_WITH_CONTEXT"),
    # The code has only two published years before 2020; v6 must not invent a baseline.
    ("77067", 2020, COVID_PROCEDURE_EVENT, None, "INSUFFICIENT_CONTINUOUS_HISTORY"),
    # Lifecycle cases are routed before forecasting.
    ("0001A", 2020, None, LIFECYCLES["0001A"], "NEW_CODE_STRUCTURAL_BREAK"),
    ("99441", 2020, None, LIFECYCLES["99441"], "NEW_CODE_STRUCTURAL_BREAK"),
    ("99201", 2021, None, LIFECYCLES["99201"], "CODE_RETIREMENT_STRUCTURAL_BREAK"),
    ("G2211", 2024, None, LIFECYCLES["G2211"], "NEW_CODE_STRUCTURAL_BREAK"),
    # Previously studied negative case, now with seven consecutive history years.
    ("90739", 2024, REGULATORY_90739_CONTEXT, None, "NORMAL_WITH_CONTEXT"),
]

MATURE_BACKTEST_CODES = [
    "36415", "45378", "66984", "77067", "94010", "97110", "99213", "G0121"
]


def load_panel() -> tuple[dict[str, list[Observation]], list[dict[str, str]]]:
    series: dict[str, list[Observation]] = defaultdict(list)
    raw: list[dict[str, str]] = []
    with PANEL_PATH.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            raw.append(row)
            value = float(row["total_services"]) if row["total_services"] else None
            series[row["hcpcs_code"]].append(
                Observation(int(row["reporting_year"]), value, row["observation_status"])
            )
    return dict(series), raw


def flatten_case(code: str, expected: str, result) -> dict:
    row = {
        "hcpcs_code": code,
        "target_year": result.target_year,
        "actual_services": result.actual,
        "target_status": result.target_status,
        "history_n": result.history_n,
        "continuous_history_n": result.continuous_history_n,
        "classification": result.classification,
        "expected_classification": expected,
        "matched_expected": result.classification == expected,
        "consensus": result.anomaly_consensus,
        "uncertainty": result.uncertainty_score,
        "causal_score": result.causal_score,
        "median_relative_deviation": result.median_relative_deviation,
        "black_swan_review_score": result.black_swan_review_score,
        "recommended_action": result.recommended_action,
        "quality_notes": " | ".join(result.quality_notes),
    }
    for forecast in result.forecasts:
        prefix = forecast.model
        row[f"{prefix}_expected"] = forecast.expected
        row[f"{prefix}_z"] = forecast.z
        row[f"{prefix}_relative_error"] = forecast.relative_error
        row[f"{prefix}_vote"] = forecast.anomaly_vote
    return row


def write_csv(path: Path, rows: list[dict]) -> None:
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def run_multicase(engine: BlackSwanV6, series: dict[str, list[Observation]]) -> list[dict]:
    rows = []
    for code, year, event, lifecycle, expected in CASES:
        result = engine.evaluate(
            series[code], year, event=event, lifecycle=lifecycle
        )
        rows.append(flatten_case(code, expected, result))
    return rows


def run_rolling_backtest(engine: BlackSwanV6, series: dict[str, list[Observation]]) -> list[dict]:
    rows = []
    for code in MATURE_BACKTEST_CODES:
        for year in range(2017, 2025):
            if year == 2020:
                continue  # separately evaluated as a known macro-event year
            result = engine.evaluate(series[code], year)
            rows.append({
                "hcpcs_code": code,
                "target_year": year,
                "target_status": result.target_status,
                "actual_services": result.actual,
                "quality_ok": result.quality_ok,
                "classification": result.classification,
                "consensus": result.anomaly_consensus,
                "uncertainty": result.uncertainty_score,
                "median_relative_deviation": result.median_relative_deviation,
                "recommended_action": result.recommended_action,
            })
    return rows


def legacy_lifecycle_comparison(
    engine_v6: BlackSwanV6,
    series: dict[str, list[Observation]],
) -> list[dict]:
    """Expose the v5 category error under a naive missing-to-zero pipeline."""
    v5 = BlackSwanV5()
    specifications = [
        ("0001A", [2016, 2017, 2018, 2019], [0.0] * 4, 2020, 159471.0),
        ("99441", [2016, 2017, 2018, 2019], [0.0] * 4, 2020, 2136114.0),
        ("99201", [2017, 2018, 2019, 2020], [249981, 226918, 210760, 226969], 2021, 0.0),
        ("G2211", [2020, 2021, 2022, 2023], [0.0] * 4, 2024, 24966114.1),
    ]
    rows = []
    for code, years, values, target_year, actual in specifications:
        old = v5.evaluate(years, values, target_year, actual)
        new = engine_v6.evaluate(
            series[code], target_year, lifecycle=LIFECYCLES[code]
        )
        rows.append({
            "hcpcs_code": code,
            "target_year": target_year,
            "legacy_input_assumption": "not_published imputed as numeric zero",
            "v5_classification": old.classification,
            "v5_consensus": old.anomaly_consensus,
            "v6_classification": new.classification,
            "v6_consensus": new.anomaly_consensus,
            "v6_lifecycle_event": new.lifecycle_event,
        })
    return rows


def summarize(
    case_rows: list[dict],
    backtest_rows: list[dict],
    legacy_rows: list[dict],
    raw_panel: list[dict[str, str]],
) -> dict:
    evaluable = [row for row in backtest_rows if row["quality_ok"]]
    counts = Counter(row["classification"] for row in evaluable)
    alerts = {
        "UNEXPLAINED_ANOMALY_REVIEW",
        "BLACK_SWAN_REVIEW_CANDIDATE",
        "EXPLAINED_STRUCTURAL_BREAK",
        "CONTEXTUAL_ANOMALY_REVIEW",
    }
    model_reviews = sum(row["classification"] == "MODEL_DISAGREEMENT_REVIEW" for row in evaluable)
    false_alert_proxy = sum(row["classification"] in alerts for row in evaluable)
    positive_codes = {"66984", "94010", "G0121"}
    positives = [row for row in case_rows if row["hcpcs_code"] in positive_codes]
    lifecycle_codes = {"0001A", "99441", "99201", "G2211"}
    lifecycle = [row for row in case_rows if row["hcpcs_code"] in lifecycle_codes]

    checksums = sorted({
        (int(row["reporting_year"]), row["response_sha256"])
        for row in raw_panel
    })
    return {
        "system": "Black Swan Logic v6",
        "data": {
            "dataset": "Medicare Physician & Other Practitioners - by Geography and Service",
            "reporting_years": [2013, 2024],
            "selected_codes": len({row["hcpcs_code"] for row in raw_panel}),
            "panel_observations": len(raw_panel),
            "national_total_rule": "sum published National facility and office Tot_Srvcs rows",
            "missing_rule": "not_published is retained as missing and never imputed to zero",
            "annual_response_sha256": [
                {"year": year, "sha256": digest} for year, digest in checksums
            ],
            "source": SOURCES["cms_catalog"],
        },
        "fixed_thresholds": {
            "z_threshold": 3.0,
            "min_relative_deviation": 0.25,
            "consensus_threshold": 2 / 3,
            "min_continuous_history": 4,
            "black_swan_min_impact": 0.50,
        },
        "multicase": {
            "cases": len(case_rows),
            "matched_expected": sum(bool(row["matched_expected"]) for row in case_rows),
            "numeric_structural_break_recall": (
                sum(row["classification"] == "EXPLAINED_STRUCTURAL_BREAK" for row in positives)
                / len(positives)
            ),
            "lifecycle_routing_accuracy": (
                sum(bool(row["matched_expected"]) for row in lifecycle) / len(lifecycle)
            ),
        },
        "rolling_non_event_proxy": {
            "attempted_holdouts": len(backtest_rows),
            "evaluable_holdouts": len(evaluable),
            "classification_counts": dict(sorted(counts.items())),
            "model_review_rate": model_reviews / len(evaluable),
            "unexplained_or_structural_alert_rate": false_alert_proxy / len(evaluable),
            "interpretation": (
                "Proxy only: non-2020 selected-code years were not exhaustively adjudicated "
                "for every external event."
            ),
        },
        "v5_lifecycle_regression": {
            "cases": len(legacy_rows),
            "v5_black_swan_candidates_under_zero_imputation": sum(
                row["v5_classification"] == "BLACK_SWAN_CANDIDATE" for row in legacy_rows
            ),
            "v6_black_swan_review_candidates": sum(
                row["v6_classification"] == "BLACK_SWAN_REVIEW_CANDIDATE" for row in legacy_rows
            ),
        },
        "limitations": [
            "Selected-code validation is not a population-wide CMS scan.",
            "Annual aggregation cannot establish within-year detection latency.",
            "Causal relevance scores are explicit analyst judgments, not learned causal effects.",
            "not_published may reflect code lifecycle, coverage, or publication rules; absent rows are not zeros.",
            "The dataset covers Original Medicare fee-for-service Part B, not all U.S. care or Medicare Advantage.",
            "A Black Swan is never proven by this detector; the strongest unexplained label is review candidate.",
        ],
        "sources": SOURCES,
    }


def write_report(summary: dict, case_rows: list[dict], legacy_rows: list[dict]) -> None:
    positives = [row for row in case_rows if row["hcpcs_code"] in {"66984", "94010", "G0121"}]
    lines = [
        "# รายงานตรวจสอบ Black Swan Logic v6 กับข้อมูล Medicare จริง",
        "",
        "## ผลลัพธ์หลัก",
        "",
        f"- ใช้ข้อมูล CMS รายปี 2013–2024, {summary['data']['selected_codes']} code, "
        f"{summary['data']['panel_observations']} code-year observations",
        f"- ชุดทดสอบที่กำหนดไว้: {summary['multicase']['matched_expected']}/"
        f"{summary['multicase']['cases']} case ตรงกับผลที่คาด",
        f"- structural break ที่มี baseline ต่อเนื่อง: "
        f"{summary['multicase']['numeric_structural_break_recall']:.0%} recall",
        f"- lifecycle routing: {summary['multicase']['lifecycle_routing_accuracy']:.0%}",
        f"- rolling non-event proxy: "
        f"{summary['rolling_non_event_proxy']['unexplained_or_structural_alert_rate']:.2%} alert, "
        f"{summary['rolling_non_event_proxy']['model_review_rate']:.2%} model review",
        "",
        "## Positive numeric cases ปี 2020",
        "",
        "| HCPCS | Actual services | Consensus | Deviation | Classification |",
        "|---|---:|---:|---:|---|",
    ]
    for row in positives:
        lines.append(
            f"| {row['hcpcs_code']} | {row['actual_services']:,.1f} | "
            f"{row['consensus']:.2f} | {row['median_relative_deviation']:.1%} | "
            f"{row['classification']} |"
        )
    lines.extend([
        "",
        "## การแก้ category error ของ v5",
        "",
        "v5 จะให้ผลผิดเมื่อ upstream แปลง `not_published` เป็นเลขศูนย์ "
        "เพราะ code ใหม่และ code ที่เลิกใช้ดูเหมือน shock ทางตัวเลข v6 จึงตรวจ lifecycle ก่อน forecast",
        "",
        "| HCPCS | v5 เมื่อเติมศูนย์ | v6 |",
        "|---|---|---|",
    ])
    for row in legacy_rows:
        lines.append(
            f"| {row['hcpcs_code']} | {row['v5_classification']} | {row['v6_classification']} |"
        )
    lines.extend([
        "",
        "## สิ่งที่ผลนี้พิสูจน์และยังไม่พิสูจน์",
        "",
        "ผลนี้พิสูจน์ว่า v6 แยก anomaly, model disagreement, insufficient history, "
        "new/retired code และ known structural break ได้บนชุด Medicare ที่คัดไว้ "
        "โดยไม่เปลี่ยน threshold v5 เพื่อให้ผ่าน testcase",
        "",
        "ยังไม่พิสูจน์ว่าเป็น production Black-Swan predictor: ชุด code ยังมีขนาดเล็ก, "
        "ข้อมูลเป็นรายปี, causal score ยังมาจากหลักฐานและ judgment, และช่วง non-event "
        "ยังไม่ได้ตรวจเหตุการณ์ภายนอกครบทุก code-year",
        "",
        "## แหล่งข้อมูลหลัก",
        "",
    ])
    for name, url in SOURCES.items():
        lines.append(f"- [{name}]({url})")
    (ROOT / "black_swan_v6_validation_report_th.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    series, raw_panel = load_panel()
    engine = BlackSwanV6()
    case_rows = run_multicase(engine, series)
    backtest_rows = run_rolling_backtest(engine, series)
    legacy_rows = legacy_lifecycle_comparison(engine, series)
    summary = summarize(case_rows, backtest_rows, legacy_rows, raw_panel)

    write_csv(ROOT / "black_swan_v6_multicase_results.csv", case_rows)
    write_csv(ROOT / "black_swan_v6_rolling_backtest.csv", backtest_rows)
    write_csv(ROOT / "black_swan_v5_v6_lifecycle_comparison.csv", legacy_rows)
    (ROOT / "black_swan_v6_validation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    write_report(summary, case_rows, legacy_rows)

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    mismatches = [row for row in case_rows if not row["matched_expected"]]
    if mismatches:
        raise SystemExit(f"validation mismatches: {mismatches}")


if __name__ == "__main__":
    main()
