#!/usr/bin/env python3

import unittest

from black_swan_v6_engine import (
    BlackSwanV6,
    EventEvidence,
    LifecycleEvidence,
    Observation,
)


class BlackSwanV6Tests(unittest.TestCase):
    def setUp(self):
        self.engine = BlackSwanV6()

    @staticmethod
    def observations(values, start=2016):
        return [Observation(start + index, value) for index, value in enumerate(values)]

    def test_not_published_is_not_zero(self):
        data = self.observations([100, 102, 101, 103])
        data.append(Observation(2020, None, "not_published"))
        result = self.engine.evaluate(data, 2020)
        self.assertEqual(result.classification, "TARGET_NOT_PUBLISHED_REVIEW")
        self.assertEqual(result.forecasts, [])

    def test_retirement_routes_before_forecast(self):
        data = self.observations([100, 102, 101, 103])
        data.append(Observation(2020, None, "not_published"))
        lifecycle = LifecycleEvidence("retired", "retirement", 2020, 1.0, "https://example.gov")
        result = self.engine.evaluate(data, 2020, lifecycle=lifecycle)
        self.assertEqual(result.classification, "CODE_RETIREMENT_STRUCTURAL_BREAK")
        self.assertEqual(result.anomaly_consensus, 0.0)

    def test_new_code_routes_before_forecast(self):
        data = [
            Observation(2016, None, "not_published"),
            Observation(2017, None, "not_published"),
            Observation(2018, None, "not_published"),
            Observation(2019, None, "not_published"),
            Observation(2020, 50000),
        ]
        lifecycle = LifecycleEvidence("new", "new_code", 2020, 1.0, "https://example.gov")
        result = self.engine.evaluate(data, 2020, lifecycle=lifecycle)
        self.assertEqual(result.classification, "NEW_CODE_STRUCTURAL_BREAK")
        self.assertEqual(result.forecasts, [])

    def test_context_does_not_create_anomaly(self):
        data = self.observations([100, 101, 102, 103, 104])
        event = EventEvidence(
            "strong event", "up", 1, 1, 1, 1, 1, 1, "https://example.gov"
        )
        result = self.engine.evaluate(data, 2020, event=event)
        self.assertEqual(result.classification, "NORMAL_WITH_CONTEXT")
        self.assertEqual(result.anomaly_consensus, 0.0)

    def test_known_large_break_is_explained_only_after_detection(self):
        data = self.observations([100, 101, 102, 103, 40])
        event = EventEvidence(
            "strong event", "down", 1, 1, 1, 1, 1, 1, "https://example.gov"
        )
        result = self.engine.evaluate(data, 2020, event=event)
        self.assertEqual(result.classification, "EXPLAINED_STRUCTURAL_BREAK")
        self.assertGreaterEqual(result.anomaly_consensus, 2 / 3)

    def test_unexplained_large_break_only_becomes_review_candidate(self):
        data = self.observations([100, 101, 102, 103, 300])
        result = self.engine.evaluate(data, 2020)
        self.assertIn(
            result.classification,
            {"BLACK_SWAN_REVIEW_CANDIDATE", "UNEXPLAINED_ANOMALY_REVIEW"},
        )
        self.assertNotEqual(result.classification, "BLACK_SWAN")

    def test_failed_source_forces_hold(self):
        data = self.observations([100, 101, 102, 103])
        data.append(Observation(2020, None, "failed"))
        result = self.engine.evaluate(data, 2020)
        self.assertEqual(result.classification, "DATA_SOURCE_FAILURE")
        self.assertEqual(result.recommended_action, "HOLD")

    def test_gap_breaks_continuous_history(self):
        data = [
            Observation(2014, 100),
            Observation(2015, 101),
            Observation(2016, 102),
            Observation(2017, None, "not_published"),
            Observation(2018, 104),
            Observation(2019, 105),
            Observation(2020, 106),
        ]
        result = self.engine.evaluate(data, 2020)
        self.assertEqual(result.classification, "INSUFFICIENT_CONTINUOUS_HISTORY")


if __name__ == "__main__":
    unittest.main()
