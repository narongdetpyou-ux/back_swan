#!/usr/bin/env python3
"""Fetch a bounded multi-case Medicare Part B validation panel.

The script uses CMS annual API dataset versions resolved from the official
catalog.  It first attempts the official API directly and, when the execution
environment is rejected by the CMS edge, retries the same public URL through
the Jina Reader transport.  The recorded source URL always remains the exact
CMS query.

Only thirteen explicitly selected public HCPCS/CPT codes are requested.  National
facility and office rows are summed; state rows are never mixed into totals.
"""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


DATASET_VERSIONS = {
    2013: "3c2a4756-0a8c-4e4d-845a-6ad169cb13d3",
    2014: "28181bd2-b377-4003-b73a-4bd92d1db4a9",
    2015: "dbee9609-2c90-43ca-b1b8-161bd9cfcdb2",
    2016: "c7d3f18c-2f00-4553-8cd1-871b727d5cdd",
    2017: "8e96a9f2-ce6e-46fd-b30d-8c695c756bfd",
    2018: "05a85700-052f-4509-af43-7042b9b35868",
    2019: "673030ae-ceed-4561-8fca-b1275395a86a",
    2020: "31eb3018-43e0-4259-a0d8-e7a1112ffd08",
    2021: "f00f462f-bb61-48b1-a321-1c50d78ce175",
    2022: "87304f15-9ed0-41dc-a141-6141a0327453",
    2023: "ddee9e22-7889-4bef-975a-7853e4cd0fbb",
    2024: "6fea9d79-0129-4e4c-b1b8-23cd86a4f435",
}

# Cases were chosen before looking at their returned values.
TARGETS = {
    "0001A": "new-code / cold-start control",
    "36415": "high-volume comparison control",
    "45378": "mature procedure comparison control",
    "66984": "2020 elective-procedure candidate pool",
    "77067": "2020 screening candidate pool",
    "90739": "previous negative case",
    "94010": "2020 respiratory-procedure candidate pool",
    "97110": "2020 rehabilitation candidate pool",
    "99201": "retired-code lifecycle case",
    "99213": "mature high-volume E/M control",
    "99441": "known 2020 policy/PHE shock case",
    "G0121": "2020 screening candidate pool",
    "G2211": "known 2024 implementation case",
}

CATALOG_URL = (
    "https://catalog.data.gov/dataset/"
    "medicare-physician-other-practitioners-by-geography-and-service"
)


def build_cms_url(year: int) -> str:
    base = (
        "http://data.cms.gov/data-api/v1/dataset/"
        f"{DATASET_VERSIONS[year]}/data"
    )
    params: list[tuple[str, str]] = [
        ("filter[condition][path]", "HCPCS_Cd"),
        ("filter[condition][operator]", "IN"),
    ]
    params.extend(("filter[condition][value][]", code) for code in TARGETS)
    params.append(("size", "5000"))
    return f"{base}?{urlencode(params)}"


def _request(url: str, timeout: int = 90) -> bytes:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 BlackSwanValidation/6"})
    with urlopen(req, timeout=timeout) as response:
        return response.read()


def fetch_year(year: int, *, force_proxy: bool) -> tuple[list[dict[str, Any]], str, str, str]:
    source_url = build_cms_url(year)
    transport = "direct_cms"
    body: bytes
    if not force_proxy:
        try:
            body = _request(source_url)
        except (HTTPError, URLError, TimeoutError):
            force_proxy = True
    if force_proxy:
        transport = "jina_reader"
        body = _request(f"https://r.jina.ai/{source_url}")
        text = body.decode("utf-8", "replace")
        marker = "Markdown Content:\n"
        if marker not in text:
            raise ValueError(f"{year}: proxy response lacks JSON marker")
        payload = text.split(marker, 1)[1].strip()
    else:
        payload = body.decode("utf-8", "replace")

    rows = json.loads(payload)
    if not isinstance(rows, list):
        raise TypeError(f"{year}: API response is not a list")
    unexpected = sorted({str(row.get("HCPCS_Cd")) for row in rows} - set(TARGETS))
    if unexpected:
        raise ValueError(f"{year}: unexpected codes returned: {unexpected}")
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return rows, source_url, transport, digest


def aggregate_year(
    year: int,
    rows: list[dict[str, Any]],
    source_url: str,
    transport: str,
    digest: str,
) -> list[dict[str, Any]]:
    national = [row for row in rows if row.get("Rndrng_Prvdr_Geo_Lvl") == "National"]
    output: list[dict[str, Any]] = []
    for code, case_role in TARGETS.items():
        selected = [row for row in national if row.get("HCPCS_Cd") == code]
        pos = sorted({str(row.get("Place_Of_Srvc", "")) for row in selected})
        descriptions = sorted({str(row.get("HCPCS_Desc", "")).strip() for row in selected})
        total = sum(float(row["Tot_Srvcs"]) for row in selected) if selected else None
        output.append({
            "reporting_year": year,
            "hcpcs_code": code,
            "case_role": case_role,
            "observation_status": "complete" if selected else "not_published",
            "total_services": "" if total is None else f"{total:.10g}",
            "place_of_service_rows": len(selected),
            "place_of_service_codes": "|".join(pos),
            "hcpcs_descriptions": "|".join(descriptions),
            "dataset_version": DATASET_VERSIONS[year],
            "cms_source_url": source_url,
            "retrieval_transport": transport,
            "response_sha256": digest,
            "catalog_url": CATALOG_URL,
        })
    return output


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    root = Path(__file__).resolve().parent
    raw_dir = root / "raw_cms_multicase"
    raw_dir.mkdir(exist_ok=True)
    panel: list[dict[str, Any]] = []

    # One direct probe only.  A rejected probe switches the whole run to the
    # transport fallback so we do not repeat slow known failures twelve times.
    force_proxy = False
    for index, year in enumerate(DATASET_VERSIONS):
        rows, source_url, transport, digest = fetch_year(year, force_proxy=force_proxy)
        if transport == "jina_reader":
            force_proxy = True
        (raw_dir / f"cms_geography_selected_{year}.json").write_text(
            json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        panel.extend(aggregate_year(year, rows, source_url, transport, digest))
        print(f"{year}: {len(rows)} rows via {transport} sha256={digest[:12]}", flush=True)
        if index + 1 < len(DATASET_VERSIONS):
            time.sleep(0.25)

    output = root / "medicare_multicase_2013_2024.csv"
    write_csv(output, panel)
    print(f"wrote {len(panel)} observations to {output}")


if __name__ == "__main__":
    main()
