#!/usr/bin/env python3
"""Black Swan Logic v6: lifecycle-aware anomaly reasoning.

v6 keeps the fixed v5 anomaly thresholds but corrects a category error found
with real Medicare data: an unpublished row is not automatically a numeric
zero.  New codes, coverage starts, code retirements, suppression, and upstream
failure are handled before forecasting.

The engine detects deviations first and scores external events second.  Event
evidence cannot make a normal numeric observation anomalous.  A Black Swan label
is never asserted; only high-impact unexplained cases can become review
candidates.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import statistics
from typing import Iterable, Optional


EPS = 1e-9
VALID_STATUSES = {"complete", "not_published", "suppressed", "failed"}


def median(values: Iterable[float]) -> float:
    return statistics.median(list(values))


def mad(values: list[float]) -> float:
    if not values:
        return 0.0
    center = median(values)
    return median(abs(value - center) for value in values)


def robust_sigma(values: list[float], floor: float = 0.0) -> float:
    return max(1.4826 * mad(values) if values else 0.0, floor, EPS)


@dataclass(frozen=True)
class Observation:
    year: int
    value: Optional[float]
    status: str = "complete"

    def __post_init__(self) -> None:
        if self.status not in VALID_STATUSES:
            raise ValueError(f"unsupported observation status: {self.status}")
        if self.status == "complete" and self.value is None:
            raise ValueError("complete observation requires a numeric value")
        if self.value is not None and (not math.isfinite(self.value) or self.value < 0):
            raise ValueError("observation values must be finite and non-negative")


@dataclass(frozen=True)
class LifecycleEvidence:
    name: str
    kind: str  # new_code, coverage_start, retirement, coverage_end
    effective_year: int
    confidence: float
    source_url: str

    def applies(self, target_year: int, allowed: set[str]) -> bool:
        return (
            self.kind in allowed
            and self.effective_year <= target_year
            and self.confidence >= 0.70
        )


@dataclass(frozen=True)
class EventEvidence:
    name: str
    expected_direction: str = "either"  # up, down, either
    temporal_overlap: float = 0.0
    domain_relevance: float = 0.0
    direct_mechanism: float = 0.0
    magnitude_alignment: float = 0.0
    direction_alignment: float = 0.0
    evidence_quality: float = 0.0
    source_url: str = ""

    def score(self) -> float:
        score = (
            0.15 * self.temporal_overlap
            + 0.15 * self.domain_relevance
            + 0.25 * self.direct_mechanism
            + 0.10 * self.magnitude_alignment
            + 0.20 * self.direction_alignment
            + 0.15 * self.evidence_quality
        )
        return max(0.0, min(1.0, score))


@dataclass(frozen=True)
class Forecast:
    model: str
    expected: float
    scale: float
    z: float
    relative_error: float
    anomaly_vote: bool


@dataclass
class V6Result:
    target_year: int
    actual: Optional[float]
    target_status: str
    history_n: int
    continuous_history_n: int
    quality_ok: bool
    quality_notes: list[str]
    forecasts: list[Forecast]
    anomaly_consensus: float
    model_spread_ratio: float
    uncertainty_score: float
    causal_score: float
    causal_event: Optional[str]
    lifecycle_event: Optional[str]
    median_relative_deviation: float
    surprise_direction: Optional[str]
    black_swan_review_score: float
    classification: str
    recommended_action: str

    def to_dict(self) -> dict:
        return asdict(self)


class BlackSwanV6:
    def __init__(
        self,
        z_threshold: float = 3.0,
        min_relative_deviation: float = 0.25,
        consensus_threshold: float = 2 / 3,
        min_history: int = 4,
        black_swan_min_impact: float = 0.50,
        black_swan_score_threshold: float = 0.35,
    ) -> None:
        self.z_threshold = z_threshold
        self.min_relative_deviation = min_relative_deviation
        self.consensus_threshold = consensus_threshold
        self.min_history = min_history
        self.black_swan_min_impact = black_swan_min_impact
        self.black_swan_score_threshold = black_swan_score_threshold

    @staticmethod
    def _base_result(
        target: Observation,
        *,
        history_n: int,
        continuous_history_n: int,
        notes: list[str],
        classification: str,
        action: str,
        event: Optional[EventEvidence],
        lifecycle: Optional[LifecycleEvidence],
        quality_ok: bool,
    ) -> V6Result:
        return V6Result(
            target_year=target.year,
            actual=target.value,
            target_status=target.status,
            history_n=history_n,
            continuous_history_n=continuous_history_n,
            quality_ok=quality_ok,
            quality_notes=notes,
            forecasts=[],
            anomaly_consensus=0.0,
            model_spread_ratio=1.0,
            uncertainty_score=1.0,
            causal_score=event.score() if event else 0.0,
            causal_event=event.name if event else None,
            lifecycle_event=lifecycle.name if lifecycle else None,
            median_relative_deviation=0.0,
            surprise_direction=None,
            black_swan_review_score=0.0,
            classification=classification,
            recommended_action=action,
        )

    @staticmethod
    def _continuous_tail(history: list[Observation], target_year: int) -> list[Observation]:
        by_year = {item.year: item for item in history}
        tail: list[Observation] = []
        year = target_year - 1
        while year in by_year and by_year[year].status == "complete":
            tail.append(by_year[year])
            year -= 1
        return list(reversed(tail))

    def _forecast_naive(self, values: list[float], actual: float) -> Forecast:
        expected = values[-1]
        diffs = [right - left for left, right in zip(values[:-1], values[1:])]
        scale = robust_sigma(diffs, floor=max(abs(expected) * 0.10, 1.0))
        return self._make_forecast("naive_last", expected, scale, actual)

    def _forecast_theil_sen(
        self,
        years: list[int],
        values: list[float],
        target_year: int,
        actual: float,
    ) -> Forecast:
        slopes = [
            (values[j] - values[i]) / (years[j] - years[i])
            for i in range(len(years))
            for j in range(i + 1, len(years))
            if years[j] != years[i]
        ]
        slope = median(slopes) if slopes else 0.0
        intercept = median(value - slope * year for year, value in zip(years, values))
        expected = max(0.0, intercept + slope * target_year)
        residuals = [
            value - (intercept + slope * year)
            for year, value in zip(years, values)
        ]
        scale = robust_sigma(residuals, floor=max(abs(expected) * 0.10, 1.0))
        return self._make_forecast("theil_sen_trend", expected, scale, actual)

    def _forecast_median_growth(self, values: list[float], actual: float) -> Forecast:
        growth = [right / left - 1.0 for left, right in zip(values[:-1], values[1:]) if left > EPS]
        rate = median(growth) if growth else 0.0
        expected = max(0.0, values[-1] * (1.0 + rate))
        growth_scale = robust_sigma(growth, floor=0.10)
        scale = max(abs(expected) * growth_scale, abs(expected) * 0.10, 1.0)
        return self._make_forecast("median_growth", expected, scale, actual)

    def _make_forecast(self, model: str, expected: float, scale: float, actual: float) -> Forecast:
        z = (actual - expected) / max(scale, EPS)
        relative = (actual - expected) / max(abs(expected), 1.0)
        vote = abs(z) >= self.z_threshold and abs(relative) >= self.min_relative_deviation
        return Forecast(model, expected, scale, z, relative, vote)

    @staticmethod
    def _history_penalty(size: int) -> float:
        if size < 5:
            return 1.0
        if size < 8:
            return 0.65
        if size < 12:
            return 0.35
        return 0.10

    def evaluate(
        self,
        observations: list[Observation],
        target_year: int,
        *,
        event: Optional[EventEvidence] = None,
        lifecycle: Optional[LifecycleEvidence] = None,
    ) -> V6Result:
        ordered = sorted(observations, key=lambda item: item.year)
        years = [item.year for item in ordered]
        if len(years) != len(set(years)):
            raise ValueError("duplicate observation years")
        targets = [item for item in ordered if item.year == target_year]
        if len(targets) != 1:
            raise ValueError("exactly one target-year observation is required")
        target = targets[0]
        history = [item for item in ordered if item.year < target_year]
        observed_history = [item for item in history if item.status == "complete"]
        tail = self._continuous_tail(history, target_year)
        notes: list[str] = []

        failed = [item.year for item in ordered if item.year <= target_year and item.status == "failed"]
        if failed:
            notes.append(f"upstream failure years: {failed}")
            return self._base_result(
                target, history_n=len(observed_history), continuous_history_n=len(tail), notes=notes,
                classification="DATA_SOURCE_FAILURE", action="HOLD", event=event,
                lifecycle=lifecycle, quality_ok=False,
            )

        if target.status == "suppressed":
            notes.append("target value suppressed; absence is not zero")
            return self._base_result(
                target, history_n=len(observed_history), continuous_history_n=len(tail), notes=notes,
                classification="TARGET_SUPPRESSED_HOLD", action="HOLD", event=event,
                lifecycle=lifecycle, quality_ok=False,
            )

        if target.status == "not_published":
            notes.append("target row not published; absence is not zero")
            if lifecycle and lifecycle.applies(target_year, {"retirement", "coverage_end"}):
                return self._base_result(
                    target, history_n=len(observed_history), continuous_history_n=len(tail), notes=notes,
                    classification="CODE_RETIREMENT_STRUCTURAL_BREAK", action="MONITOR_LIFECYCLE",
                    event=event, lifecycle=lifecycle, quality_ok=True,
                )
            return self._base_result(
                target, history_n=len(observed_history), continuous_history_n=len(tail), notes=notes,
                classification="TARGET_NOT_PUBLISHED_REVIEW", action="VERIFY_CODE_STATUS",
                event=event, lifecycle=lifecycle, quality_ok=False,
            )

        if not observed_history:
            notes.append("no published numeric history before target")
            if lifecycle and lifecycle.applies(target_year, {"new_code", "coverage_start"}):
                return self._base_result(
                    target, history_n=0, continuous_history_n=0, notes=notes,
                    classification="NEW_CODE_STRUCTURAL_BREAK", action="MONITOR_LIFECYCLE",
                    event=event, lifecycle=lifecycle, quality_ok=True,
                )
            return self._base_result(
                target, history_n=0, continuous_history_n=0, notes=notes,
                classification="NEW_SERIES_COLD_START_REVIEW", action="BUILD_BASELINE",
                event=event, lifecycle=lifecycle, quality_ok=False,
            )

        if len(tail) < self.min_history:
            notes.append(f"continuous history<{self.min_history}; missing years are not imputed")
            return self._base_result(
                target, history_n=len(observed_history), continuous_history_n=len(tail), notes=notes,
                classification="INSUFFICIENT_CONTINUOUS_HISTORY", action="HOLD",
                event=event, lifecycle=lifecycle, quality_ok=False,
            )

        if len(tail) < 8:
            notes.append("short annual baseline: uncertainty elevated")
        years_tail = [item.year for item in tail]
        values = [float(item.value) for item in tail if item.value is not None]
        actual = float(target.value)
        forecasts = [
            self._forecast_naive(values, actual),
            self._forecast_theil_sen(years_tail, values, target_year, actual),
            self._forecast_median_growth(values, actual),
        ]

        votes = sum(int(item.anomaly_vote) for item in forecasts)
        consensus = votes / len(forecasts)
        expected_values = [item.expected for item in forecasts]
        expected_center = median(expected_values)
        spread = (max(expected_values) - min(expected_values)) / max(abs(expected_center), 1.0)
        uncertainty = min(
            1.0,
            0.55 * self._history_penalty(len(tail))
            + 0.45 * min(1.0, spread / 0.50),
        )

        signed_relative = median(item.relative_error for item in forecasts)
        severity = median(abs(item.relative_error) for item in forecasts)
        direction = "up" if signed_relative > 0 else "down" if signed_relative < 0 else "flat"
        causal = event.score() if event else 0.0
        novelty = 1.0 - causal
        review_score = consensus * min(1.0, severity) * novelty * (1.0 - uncertainty)
        max_abs_z = max(abs(item.z) for item in forecasts)
        mixed_votes = 0 < votes < len(forecasts)

        if consensus >= self.consensus_threshold:
            if event and causal >= 0.70:
                classification = "EXPLAINED_STRUCTURAL_BREAK"
                action = "MONITOR_KNOWN_EVENT"
            elif event and causal >= 0.40:
                classification = "CONTEXTUAL_ANOMALY_REVIEW"
                action = "VERIFY_CAUSAL_LINK"
            elif (
                severity >= self.black_swan_min_impact
                and review_score >= self.black_swan_score_threshold
            ):
                classification = "BLACK_SWAN_REVIEW_CANDIDATE"
                action = "HUMAN_ESCALATION"
            else:
                classification = "UNEXPLAINED_ANOMALY_REVIEW"
                action = "HUMAN_ESCALATION"
        elif mixed_votes and (spread >= 0.50 or max_abs_z >= self.z_threshold):
            classification = "MODEL_DISAGREEMENT_REVIEW"
            action = "MODEL_REVIEW"
        else:
            classification = "NORMAL_WITH_CONTEXT" if event else "NORMAL"
            action = "NO_ALERT"

        return V6Result(
            target_year=target_year,
            actual=actual,
            target_status=target.status,
            history_n=len(observed_history),
            continuous_history_n=len(tail),
            quality_ok=True,
            quality_notes=notes,
            forecasts=forecasts,
            anomaly_consensus=consensus,
            model_spread_ratio=spread,
            uncertainty_score=uncertainty,
            causal_score=causal,
            causal_event=event.name if event else None,
            lifecycle_event=lifecycle.name if lifecycle else None,
            median_relative_deviation=severity,
            surprise_direction=direction,
            black_swan_review_score=review_score,
            classification=classification,
            recommended_action=action,
        )
