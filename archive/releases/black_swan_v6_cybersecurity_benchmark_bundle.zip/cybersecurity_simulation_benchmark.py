#!/usr/bin/env python3
"""Deterministic cybersecurity simulation benchmark for Black Swan Logic v6.

The benchmark deliberately keeps the v6 numeric thresholds unchanged.  It
tests whether the domain-neutral parts of the engine transfer from annual
Medicare utilization to hourly security telemetry, and exposes blind spots
instead of optimizing every synthetic scenario for a perfect score.

All observations are synthetic aggregates.  No real users, hosts, IP
addresses, credentials, payloads, or exploit instructions are included.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import csv
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import random
from typing import Optional

from black_swan_v6_engine import (
    BlackSwanV6,
    EventEvidence,
    LifecycleEvidence,
    Observation,
)


ROOT = Path(__file__).resolve().parent
SEED = 20260903
BASELINE_BUCKETS = 48
TARGET_BUCKET = BASELINE_BUCKETS
START_TIME = datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc)

SECURITY_ALERT_CLASSES = {
    "BLACK_SWAN_REVIEW_CANDIDATE",
    "UNEXPLAINED_ANOMALY_REVIEW",
    "CONTEXTUAL_ANOMALY_REVIEW",
}
HOLD_CLASSES = {
    "DATA_SOURCE_FAILURE",
    "TARGET_SUPPRESSED_HOLD",
    "TARGET_NOT_PUBLISHED_REVIEW",
    "INSUFFICIENT_CONTINUOUS_HISTORY",
    "NEW_SERIES_COLD_START_REVIEW",
}
LIFECYCLE_CLASSES = {
    "NEW_CODE_STRUCTURAL_BREAK",
    "CODE_RETIREMENT_STRUCTURAL_BREAK",
}


@dataclass(frozen=True)
class MetricSpec:
    name: str
    baseline: float
    relative_noise: float
    diurnal_amplitude: float
    integer: bool = True


METRICS = {
    item.name: item
    for item in [
        MetricSpec("auth_failures", 120.0, 0.10, 0.30),
        MetricSpec("unique_failed_accounts", 34.0, 0.09, 0.25),
        MetricSpec("unique_source_ips", 245.0, 0.08, 0.20),
        MetricSpec("successful_logins", 1500.0, 0.06, 0.40),
        MetricSpec("privileged_changes", 1.8, 0.22, 0.15),
        MetricSpec("outbound_mb", 850.0, 0.07, 0.35, integer=False),
        MetricSpec("api_5xx", 18.0, 0.18, 0.30),
        MetricSpec("endpoint_alerts", 4.5, 0.25, 0.10),
        MetricSpec("file_rename_events", 42.0, 0.12, 0.20),
        MetricSpec("inbound_requests", 50000.0, 0.05, 0.45),
    ]
}


@dataclass(frozen=True)
class ScenarioSpec:
    scenario_id: str
    scenario_group: str
    family: str
    attack_present: bool
    designed_evasive: bool
    desired_security_alert: bool
    expected_operational_route: str
    affected_metrics: tuple[str, ...] = ()
    multipliers: tuple[tuple[str, float], ...] = ()
    target_statuses: tuple[tuple[str, str], ...] = ()
    history_statuses: tuple[tuple[str, str], ...] = ()
    event_key: Optional[str] = None
    lifecycle_key: Optional[str] = None
    lifecycle_metric: Optional[str] = None
    description: str = ""

    def multiplier_map(self) -> dict[str, float]:
        return dict(self.multipliers)

    def target_status_map(self) -> dict[str, str]:
        return dict(self.target_statuses)

    def history_status_map(self) -> dict[str, str]:
        return dict(self.history_statuses)


BENIGN_EVENTS = {
    "approved_backup": EventEvidence(
        name="Approved full-backup window",
        expected_direction="up",
        temporal_overlap=1.0,
        domain_relevance=1.0,
        direct_mechanism=1.0,
        magnitude_alignment=0.95,
        direction_alignment=1.0,
        evidence_quality=1.0,
        source_url="synthetic://change-ticket/backup-window",
    ),
    "software_release": EventEvidence(
        name="Documented software release with transient errors",
        expected_direction="up",
        temporal_overlap=1.0,
        domain_relevance=1.0,
        direct_mechanism=0.95,
        magnitude_alignment=0.90,
        direction_alignment=1.0,
        evidence_quality=1.0,
        source_url="synthetic://change-ticket/software-release",
    ),
    "campaign": EventEvidence(
        name="Approved public campaign traffic surge",
        expected_direction="up",
        temporal_overlap=1.0,
        domain_relevance=0.95,
        direct_mechanism=0.90,
        magnitude_alignment=0.90,
        direction_alignment=1.0,
        evidence_quality=1.0,
        source_url="synthetic://change-ticket/campaign",
    ),
    "cloud_migration": EventEvidence(
        name="Planned cloud migration and baseline drift",
        expected_direction="up",
        temporal_overlap=1.0,
        domain_relevance=0.90,
        direct_mechanism=0.80,
        magnitude_alignment=0.75,
        direction_alignment=1.0,
        evidence_quality=1.0,
        source_url="synthetic://change-ticket/cloud-migration",
    ),
}

LIFECYCLES = {
    "new_sensor": LifecycleEvidence(
        name="New EDR telemetry series activated",
        kind="coverage_start",
        effective_year=TARGET_BUCKET,
        confidence=1.0,
        source_url="synthetic://telemetry-catalog/edr-v2-start",
    ),
    "retired_metric": LifecycleEvidence(
        name="Legacy proxy error metric retired",
        kind="coverage_end",
        effective_year=TARGET_BUCKET,
        confidence=1.0,
        source_url="synthetic://telemetry-catalog/proxy-v1-retirement",
    ),
}


# Pre-registered before detector execution.  The two evasive attacks retain a
# desired alert=True even though their per-metric changes are intentionally
# below v6's fixed 25% relative-deviation threshold.
SCENARIOS = [
    ScenarioSpec(
        "normal_control", "control", "normal_activity", False, False, False,
        "NO_ALERT", description="Ordinary hourly variation with diurnal seasonality.",
    ),
    ScenarioSpec(
        "planned_cloud_drift", "benign", "concept_drift", False, False, False,
        "NO_SECURITY_ALERT", affected_metrics=("outbound_mb", "inbound_requests"),
        multipliers=(("outbound_mb", 1.12), ("inbound_requests", 1.10)),
        event_key="cloud_migration",
        description="Small documented baseline shift below anomaly thresholds.",
    ),
    ScenarioSpec(
        "approved_backup", "benign", "backup_window", False, False, False,
        "BENIGN_EXPLAINED_BREAK", affected_metrics=("outbound_mb",),
        multipliers=(("outbound_mb", 4.0),), event_key="approved_backup",
        description="Large outbound transfer explained by an approved backup.",
    ),
    ScenarioSpec(
        "software_release", "benign", "release_error_burst", False, False, False,
        "BENIGN_EXPLAINED_BREAK", affected_metrics=("api_5xx",),
        multipliers=(("api_5xx", 8.0),), event_key="software_release",
        description="Documented release produces a transient 5xx burst.",
    ),
    ScenarioSpec(
        "campaign_traffic", "benign", "legitimate_traffic_surge", False, False, False,
        "BENIGN_EXPLAINED_BREAK",
        affected_metrics=("successful_logins", "inbound_requests"),
        multipliers=(("successful_logins", 2.4), ("inbound_requests", 3.0)),
        event_key="campaign",
        description="Legitimate campaign causes a large explained demand surge.",
    ),
    ScenarioSpec(
        "password_spray", "attack", "password_spray", True, False, True,
        "SECURITY_ANOMALY_REVIEW",
        affected_metrics=("auth_failures", "unique_failed_accounts", "unique_source_ips"),
        multipliers=(("auth_failures", 6.0), ("unique_failed_accounts", 4.0), ("unique_source_ips", 3.0)),
        description="Abrupt authentication failures distributed across accounts and sources.",
    ),
    ScenarioSpec(
        "credential_stuffing", "attack", "credential_stuffing", True, False, True,
        "SECURITY_ANOMALY_REVIEW",
        affected_metrics=("auth_failures", "successful_logins", "unique_source_ips"),
        multipliers=(("auth_failures", 10.0), ("successful_logins", 2.0), ("unique_source_ips", 5.0)),
        description="High-volume credential replay with some successful access.",
    ),
    ScenarioSpec(
        "ddos_burst", "attack", "denial_of_service", True, False, True,
        "SECURITY_ANOMALY_REVIEW", affected_metrics=("inbound_requests", "api_5xx"),
        multipliers=(("inbound_requests", 10.0), ("api_5xx", 12.0)),
        description="Abrupt request flood and service errors.",
    ),
    ScenarioSpec(
        "exfiltration_burst", "attack", "data_exfiltration", True, False, True,
        "SECURITY_ANOMALY_REVIEW", affected_metrics=("outbound_mb",),
        multipliers=(("outbound_mb", 7.0),),
        description="Large unexplained outbound transfer.",
    ),
    ScenarioSpec(
        "ransomware_burst", "attack", "ransomware", True, False, True,
        "SECURITY_ANOMALY_REVIEW",
        affected_metrics=("endpoint_alerts", "file_rename_events"),
        multipliers=(("endpoint_alerts", 12.0), ("file_rename_events", 20.0)),
        description="Abrupt endpoint detections and mass file rename activity.",
    ),
    ScenarioSpec(
        "privilege_escalation", "attack", "privilege_escalation", True, False, True,
        "SECURITY_ANOMALY_REVIEW", affected_metrics=("privileged_changes",),
        multipliers=(("privileged_changes", 15.0),),
        description="Unexplained burst of privileged role changes.",
    ),
    ScenarioSpec(
        "slow_exfiltration", "evasive_attack", "low_and_slow_exfiltration", True, True, True,
        "SECURITY_ANOMALY_REVIEW", affected_metrics=("outbound_mb",),
        multipliers=(("outbound_mb", 1.18),),
        description="Exfiltration remains below the fixed 25% per-metric threshold.",
    ),
    ScenarioSpec(
        "correlated_subthreshold", "evasive_attack", "correlated_low_signal_intrusion", True, True, True,
        "SECURITY_ANOMALY_REVIEW",
        affected_metrics=("auth_failures", "unique_failed_accounts", "outbound_mb", "endpoint_alerts"),
        multipliers=(("auth_failures", 1.18), ("unique_failed_accounts", 1.18),
                     ("outbound_mb", 1.18), ("endpoint_alerts", 1.18)),
        description="Four correlated weak signals; each remains below the univariate threshold.",
    ),
    ScenarioSpec(
        "collector_failure", "data_quality", "telemetry_failure", False, False, False,
        "TELEMETRY_HOLD", affected_metrics=("api_5xx",),
        target_statuses=(("api_5xx", "failed"),),
        description="Collector failure must be held, never converted to numeric zero.",
    ),
    ScenarioSpec(
        "log_suppression_attack", "evasive_attack", "telemetry_suppression", True, True, True,
        "TELEMETRY_HOLD", affected_metrics=("endpoint_alerts",),
        target_statuses=(("endpoint_alerts", "suppressed"),),
        description="Attack suppresses the target telemetry; system should hold and escalate quality risk.",
    ),
    ScenarioSpec(
        "new_edr_sensor", "lifecycle", "new_telemetry_series", False, False, False,
        "SERIES_LIFECYCLE_CHANGE", affected_metrics=("endpoint_alerts",),
        history_statuses=(("endpoint_alerts", "not_published"),),
        lifecycle_key="new_sensor", lifecycle_metric="endpoint_alerts",
        description="New EDR series starts; absence before activation is not zero.",
    ),
    ScenarioSpec(
        "retired_proxy_metric", "lifecycle", "retired_telemetry_series", False, False, False,
        "SERIES_LIFECYCLE_CHANGE", affected_metrics=("api_5xx",),
        target_statuses=(("api_5xx", "not_published"),),
        lifecycle_key="retired_metric", lifecycle_metric="api_5xx",
        description="Legacy metric is retired; target absence is not a zero-valued shock.",
    ),
]


def _stable_seed(*parts: object) -> int:
    digest = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _normal_value(spec: MetricSpec, bucket: int, rng: random.Random) -> float:
    hour = (START_TIME + timedelta(hours=bucket)).hour
    # Peak around 14:00 UTC in this synthetic environment.
    diurnal = 1.0 + spec.diurnal_amplitude * math.cos(2.0 * math.pi * (hour - 14) / 24.0)
    weekday_drift = 1.0 + 0.0008 * bucket
    value = spec.baseline * diurnal * weekday_drift
    value *= max(0.05, 1.0 + rng.gauss(0.0, spec.relative_noise))
    if spec.integer:
        return float(max(0, round(value)))
    return round(max(0.0, value), 3)


def generate_scenario(
    spec: ScenarioSpec,
    *,
    seed: int,
    multiplier_overrides: Optional[dict[str, float]] = None,
) -> list[dict]:
    rows: list[dict] = []
    multipliers = spec.multiplier_map()
    if multiplier_overrides:
        multipliers.update(multiplier_overrides)
    target_statuses = spec.target_status_map()
    history_statuses = spec.history_status_map()

    for metric_name, metric_spec in METRICS.items():
        rng = random.Random(_stable_seed(SEED, seed, spec.scenario_id, metric_name))
        for bucket in range(TARGET_BUCKET + 1):
            status = "complete"
            if bucket < TARGET_BUCKET and metric_name in history_statuses:
                status = history_statuses[metric_name]
            if bucket == TARGET_BUCKET and metric_name in target_statuses:
                status = target_statuses[metric_name]

            value: Optional[float]
            if status == "complete":
                value = _normal_value(metric_spec, bucket, rng)
                if bucket == TARGET_BUCKET:
                    value *= multipliers.get(metric_name, 1.0)
                    value = round(value) if metric_spec.integer else round(value, 3)
            else:
                value = None

            rows.append({
                "scenario_id": spec.scenario_id,
                "bucket": bucket,
                "timestamp_utc": (START_TIME + timedelta(hours=bucket)).isoformat().replace("+00:00", "Z"),
                "phase": "target" if bucket == TARGET_BUCKET else "baseline",
                "metric": metric_name,
                "value": value,
                "status": status,
                "synthetic": True,
                "generator_seed": seed,
            })
    return rows


def scenario_manifest_rows() -> list[dict]:
    rows = []
    for spec in SCENARIOS:
        row = asdict(spec)
        row["affected_metrics"] = "|".join(spec.affected_metrics)
        row["multipliers"] = "|".join(f"{name}:{value}" for name, value in spec.multipliers)
        row["target_statuses"] = "|".join(f"{name}:{value}" for name, value in spec.target_statuses)
        row["history_statuses"] = "|".join(f"{name}:{value}" for name, value in spec.history_statuses)
        rows.append(row)
    return rows


def _domain_classification(name: str) -> str:
    return {
        "NEW_CODE_STRUCTURAL_BREAK": "NEW_SERIES_STRUCTURAL_BREAK",
        "CODE_RETIREMENT_STRUCTURAL_BREAK": "SERIES_RETIREMENT_STRUCTURAL_BREAK",
    }.get(name, name)


def evaluate_rows(
    engine: BlackSwanV6,
    spec: ScenarioSpec,
    rows: list[dict],
) -> tuple[list[dict], dict]:
    by_metric: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_metric[row["metric"]].append(row)

    metric_results: list[dict] = []
    event = BENIGN_EVENTS.get(spec.event_key) if spec.event_key else None
    for metric_name in METRICS:
        lifecycle = None
        if spec.lifecycle_key and metric_name == spec.lifecycle_metric:
            lifecycle = LIFECYCLES[spec.lifecycle_key]
        observations = [
            Observation(int(row["bucket"]), row["value"], row["status"])
            for row in by_metric[metric_name]
        ]
        result = engine.evaluate(
            observations,
            TARGET_BUCKET,
            event=event,
            lifecycle=lifecycle,
        )
        forecasts = {forecast.model: forecast for forecast in result.forecasts}
        metric_results.append({
            "scenario_id": spec.scenario_id,
            "scenario_group": spec.scenario_group,
            "family": spec.family,
            "metric": metric_name,
            "is_affected_metric": metric_name in spec.affected_metrics,
            "attack_present": spec.attack_present,
            "designed_evasive": spec.designed_evasive,
            "desired_security_alert": spec.desired_security_alert,
            "target_value": result.actual,
            "target_status": result.target_status,
            "history_n": result.history_n,
            "continuous_history_n": result.continuous_history_n,
            "quality_ok": result.quality_ok,
            "engine_classification": result.classification,
            "domain_classification": _domain_classification(result.classification),
            "security_alert": result.classification in SECURITY_ALERT_CLASSES,
            "consensus": result.anomaly_consensus,
            "uncertainty": result.uncertainty_score,
            "median_relative_deviation": result.median_relative_deviation,
            "causal_score": result.causal_score,
            "black_swan_review_score": result.black_swan_review_score,
            "action": result.recommended_action,
            "naive_expected": forecasts.get("naive_last").expected if "naive_last" in forecasts else None,
            "trend_expected": forecasts.get("theil_sen_trend").expected if "theil_sen_trend" in forecasts else None,
            "growth_expected": forecasts.get("median_growth").expected if "median_growth" in forecasts else None,
        })

    classes = {row["engine_classification"] for row in metric_results}
    security_alert = any(bool(row["security_alert"]) for row in metric_results)
    if security_alert:
        route = "SECURITY_ANOMALY_REVIEW"
    elif classes & HOLD_CLASSES:
        route = "TELEMETRY_HOLD"
    elif "EXPLAINED_STRUCTURAL_BREAK" in classes:
        route = "BENIGN_EXPLAINED_BREAK"
    elif classes & LIFECYCLE_CLASSES:
        route = "SERIES_LIFECYCLE_CHANGE"
    elif "MODEL_DISAGREEMENT_REVIEW" in classes:
        route = "MODEL_REVIEW"
    else:
        route = "NO_ALERT" if spec.scenario_group == "control" else "NO_SECURITY_ALERT"

    operational_escalation = security_alert or route == "TELEMETRY_HOLD"
    summary = {
        "scenario_id": spec.scenario_id,
        "scenario_group": spec.scenario_group,
        "family": spec.family,
        "attack_present": spec.attack_present,
        "designed_evasive": spec.designed_evasive,
        "desired_security_alert": spec.desired_security_alert,
        "expected_operational_route": spec.expected_operational_route,
        "actual_operational_route": route,
        "route_matches_expectation": route == spec.expected_operational_route,
        "security_alert": security_alert,
        "operational_escalation": operational_escalation,
        "security_detection_correct": security_alert == spec.desired_security_alert,
        "alerted_metrics": "|".join(row["metric"] for row in metric_results if row["security_alert"]),
        "held_metrics": "|".join(
            row["metric"] for row in metric_results if row["engine_classification"] in HOLD_CLASSES
        ),
        "explained_metrics": "|".join(
            row["metric"] for row in metric_results if row["engine_classification"] == "EXPLAINED_STRUCTURAL_BREAK"
        ),
        "lifecycle_metrics": "|".join(
            row["metric"] for row in metric_results if row["engine_classification"] in LIFECYCLE_CLASSES
        ),
    }
    return metric_results, summary


def _monte_carlo_override(spec: ScenarioSpec, rng: random.Random) -> dict[str, float]:
    overrides: dict[str, float] = {}
    for metric, base in spec.multipliers:
        if spec.scenario_group == "evasive_attack" and spec.family != "telemetry_suppression":
            overrides[metric] = rng.uniform(1.05, 1.24)
        elif spec.scenario_group == "attack":
            overrides[metric] = rng.uniform(max(1.30, base * 0.55), base * 1.20)
        elif spec.scenario_group == "benign" and base >= 2.0:
            overrides[metric] = rng.uniform(max(1.35, base * 0.60), base * 1.15)
        else:
            overrides[metric] = max(0.05, rng.gauss(base, 0.03))
    return overrides


def run_monte_carlo(engine: BlackSwanV6, repeats: int = 60) -> list[dict]:
    rows: list[dict] = []
    eligible = [spec for spec in SCENARIOS if spec.scenario_group in {"control", "benign", "attack", "evasive_attack"}]
    for spec in eligible:
        for repeat in range(repeats):
            rng = random.Random(_stable_seed(SEED, "mc", spec.scenario_id, repeat))
            overrides = _monte_carlo_override(spec, rng)
            data = generate_scenario(spec, seed=10_000 + repeat, multiplier_overrides=overrides)
            _, result = evaluate_rows(engine, spec, data)
            rows.append({
                "scenario_id": spec.scenario_id,
                "repeat": repeat,
                "scenario_group": spec.scenario_group,
                "family": spec.family,
                "attack_present": spec.attack_present,
                "designed_evasive": spec.designed_evasive,
                "desired_security_alert": spec.desired_security_alert,
                "security_alert": result["security_alert"],
                "operational_escalation": result["operational_escalation"],
                "actual_operational_route": result["actual_operational_route"],
                "alerted_metrics": result["alerted_metrics"],
                "multiplier_overrides": json.dumps(overrides, sort_keys=True),
            })
    return rows


def _safe_rate(numerator: int, denominator: int) -> Optional[float]:
    return numerator / denominator if denominator else None


def build_summary(
    dataset_rows: list[dict],
    curated: list[dict],
    monte_carlo: list[dict],
) -> dict:
    benign = [row for row in monte_carlo if not row["attack_present"]]
    attacks = [row for row in monte_carlo if row["attack_present"]]
    strong_attacks = [row for row in attacks if not row["designed_evasive"]]
    evasive_attacks = [row for row in attacks if row["designed_evasive"]]
    family_rows: list[dict] = []
    for family in sorted({row["family"] for row in monte_carlo}):
        selected = [row for row in monte_carlo if row["family"] == family]
        family_rows.append({
            "family": family,
            "scenario_group": selected[0]["scenario_group"],
            "runs": len(selected),
            "security_alert_rate": _safe_rate(sum(bool(row["security_alert"]) for row in selected), len(selected)),
            "operational_escalation_rate": _safe_rate(sum(bool(row["operational_escalation"]) for row in selected), len(selected)),
        })

    return {
        "system": "Black Swan Logic v6 + cybersecurity domain adapter",
        "benchmark": {
            "synthetic_only": True,
            "seed": SEED,
            "granularity": "hourly aggregates",
            "baseline_buckets": BASELINE_BUCKETS,
            "target_bucket": TARGET_BUCKET,
            "metrics": list(METRICS),
            "curated_scenarios": len(SCENARIOS),
            "dataset_rows": len(dataset_rows),
            "ground_truth_separated_from_telemetry": True,
        },
        "fixed_v6_thresholds": {
            "z_threshold": 3.0,
            "min_relative_deviation": 0.25,
            "consensus_threshold": 2 / 3,
            "min_continuous_history": 4,
            "black_swan_min_impact": 0.50,
        },
        "curated_results": {
            "route_matches": sum(bool(row["route_matches_expectation"]) for row in curated),
            "routes_total": len(curated),
            "security_decisions_correct": sum(bool(row["security_detection_correct"]) for row in curated),
            "security_decisions_total": len(curated),
            "false_positives": sum(bool(row["security_alert"]) and not bool(row["attack_present"]) for row in curated),
            "false_negatives": sum((not bool(row["security_alert"])) and bool(row["desired_security_alert"]) for row in curated),
            "route_counts": dict(sorted(Counter(row["actual_operational_route"] for row in curated).items())),
        },
        "monte_carlo": {
            "runs": len(monte_carlo),
            "benign_false_alert_rate": _safe_rate(sum(bool(row["security_alert"]) for row in benign), len(benign)),
            "strong_attack_recall": _safe_rate(sum(bool(row["security_alert"]) for row in strong_attacks), len(strong_attacks)),
            "evasive_attack_recall": _safe_rate(sum(bool(row["security_alert"]) for row in evasive_attacks), len(evasive_attacks)),
            "evasive_operational_escalation_rate": _safe_rate(sum(bool(row["operational_escalation"]) for row in evasive_attacks), len(evasive_attacks)),
            "family_results": family_rows,
        },
        "known_design_limits_tested": [
            "Univariate 25% threshold can miss correlated sub-threshold signals.",
            "A low-and-slow attack can blend into ordinary hourly variance.",
            "Telemetry suppression is routed to HOLD, not proven as an attack.",
            "A high-quality benign change ticket can explain a numeric break, but this simulation does not test forged context.",
            "Hourly aggregates do not represent event ordering, entities, graph relationships, payloads, or host-to-host lateral movement.",
        ],
        "dataset_sha256": sha256_rows(dataset_rows),
    }


def sha256_rows(rows: list[dict]) -> str:
    canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def write_report(summary: dict, curated: list[dict]) -> None:
    mc = summary["monte_carlo"]
    curated_stats = summary["curated_results"]
    lines = [
        "# รายงานชุดทดสอบจำลอง Cybersecurity สำหรับ Black Swan Logic v6",
        "",
        "## ผลลัพธ์หลัก",
        "",
        f"- ข้อมูลจำลองแบบ hourly aggregate: {summary['benchmark']['dataset_rows']:,} แถว, "
        f"{summary['benchmark']['curated_scenarios']} สถานการณ์, {len(summary['benchmark']['metrics'])} metrics",
        f"- Monte Carlo: {mc['runs']:,} runs",
        f"- Benign false-alert rate: {mc['benign_false_alert_rate']:.2%}",
        f"- Recall ต่อการโจมตีแบบแรง/ฉับพลัน: {mc['strong_attack_recall']:.2%}",
        f"- Recall ต่อ evasive attacks: {mc['evasive_attack_recall']:.2%}",
        f"- Curated false positives: {curated_stats['false_positives']}",
        f"- Curated false negatives: {curated_stats['false_negatives']}",
        "",
        "## ผล curated scenarios",
        "",
        "| Scenario | Truth | Evasive | Desired alert | Actual route | Alerted metrics | Correct |",
        "|---|---|---:|---:|---|---|---:|",
    ]
    for row in curated:
        truth = "attack" if row["attack_present"] else row["scenario_group"]
        lines.append(
            f"| {row['scenario_id']} | {truth} | {str(row['designed_evasive']).lower()} | "
            f"{str(row['desired_security_alert']).lower()} | {row['actual_operational_route']} | "
            f"{row['alerted_metrics'] or '-'} | {str(row['security_detection_correct']).lower()} |"
        )
    lines.extend([
        "",
        "## สิ่งที่ชุดทดสอบนี้เปิดเผย",
        "",
        "v6 ยังคงเหมาะกับ shock ที่แรงและเกิดฉับพลัน และ causal layer ช่วยไม่ให้ planned backup, "
        "software release หรือ campaign traffic ถูกยกระดับเป็นภัยไซเบอร์โดยอัตโนมัติ",
        "",
        "แต่ cybersecurity มีรูปแบบที่ Medicare test ไม่ได้บังคับให้ระบบเผชิญ: หลายสัญญาณอ่อนที่สัมพันธ์กัน, "
        "low-and-slow behavior และ telemetry suppression ชุดนี้จึงจงใจเก็บ false negatives เหล่านั้นไว้ "
        "เพื่อใช้เป็นข้อกำหนดสำหรับรุ่นถัดไป ไม่ลบหรือปรับ threshold เพื่อให้คะแนนดูดี",
        "",
        "## ขอบเขต",
        "",
        "ข้อมูลทั้งหมดเป็น aggregate synthetic telemetry ไม่มีข้อมูลจริงของบุคคล องค์กร เครื่อง ผู้ใช้ IP "
        "credential payload หรือ exploit การทดสอบนี้วัดตรรกะ anomaly/quality/context เท่านั้น "
        "ไม่ใช่การประเมิน IDS/EDR production และไม่พิสูจน์ความสามารถตรวจจับภัยทุกชนิด",
        "",
        f"Dataset SHA-256: `{summary['dataset_sha256']}`",
    ])
    (ROOT / "black_swan_v6_cybersecurity_report_th.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    engine = BlackSwanV6()
    dataset_rows: list[dict] = []
    metric_results: list[dict] = []
    curated_results: list[dict] = []

    for index, spec in enumerate(SCENARIOS):
        rows = generate_scenario(spec, seed=SEED + index)
        dataset_rows.extend(rows)
        per_metric, scenario_result = evaluate_rows(engine, spec, rows)
        metric_results.extend(per_metric)
        curated_results.append(scenario_result)

    monte_carlo = run_monte_carlo(engine)
    summary = build_summary(dataset_rows, curated_results, monte_carlo)

    write_csv(ROOT / "cybersecurity_synthetic_timeseries.csv", dataset_rows)
    write_csv(ROOT / "cybersecurity_scenario_manifest.csv", scenario_manifest_rows())
    write_csv(ROOT / "cybersecurity_metric_results.csv", metric_results)
    write_csv(ROOT / "cybersecurity_curated_results.csv", curated_results)
    write_csv(ROOT / "cybersecurity_monte_carlo_results.csv", monte_carlo)
    (ROOT / "black_swan_v6_cybersecurity_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "cybersecurity_workbook_data.json").write_text(
        json.dumps({
            "summary": summary,
            "metric_specs": [asdict(item) for item in METRICS.values()],
            "scenario_manifest": scenario_manifest_rows(),
            "curated_results": curated_results,
            "metric_results": metric_results,
            "monte_carlo_results": monte_carlo,
            "timeseries": dataset_rows,
        }, ensure_ascii=False, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    write_report(summary, curated_results)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
