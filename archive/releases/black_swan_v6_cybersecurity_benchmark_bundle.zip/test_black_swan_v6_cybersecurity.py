#!/usr/bin/env python3

import unittest

from black_swan_v6_engine import BlackSwanV6
from cybersecurity_simulation_benchmark import (
    METRICS,
    SCENARIOS,
    TARGET_BUCKET,
    evaluate_rows,
    generate_scenario,
    sha256_rows,
)


class CybersecurityBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.engine = BlackSwanV6()
        self.by_id = {item.scenario_id: item for item in SCENARIOS}

    def run_scenario(self, scenario_id):
        spec = self.by_id[scenario_id]
        rows = generate_scenario(spec, seed=12345)
        metric, summary = evaluate_rows(self.engine, spec, rows)
        return rows, metric, summary

    def test_dataset_shape_and_separate_truth(self):
        rows, _, _ = self.run_scenario("normal_control")
        self.assertEqual(len(rows), len(METRICS) * (TARGET_BUCKET + 1))
        self.assertNotIn("attack_present", rows[0])
        self.assertNotIn("desired_security_alert", rows[0])

    def test_generator_is_deterministic(self):
        spec = self.by_id["password_spray"]
        first = generate_scenario(spec, seed=77)
        second = generate_scenario(spec, seed=77)
        self.assertEqual(sha256_rows(first), sha256_rows(second))

    def test_normal_control_does_not_alert(self):
        _, _, summary = self.run_scenario("normal_control")
        self.assertFalse(summary["security_alert"])

    def test_strong_attack_families_alert(self):
        for scenario_id in [
            "password_spray", "credential_stuffing", "ddos_burst",
            "exfiltration_burst", "ransomware_burst", "privilege_escalation",
        ]:
            with self.subTest(scenario_id=scenario_id):
                _, _, summary = self.run_scenario(scenario_id)
                self.assertTrue(summary["security_alert"])

    def test_benign_breaks_are_explained_not_security_alerts(self):
        for scenario_id in ["approved_backup", "software_release", "campaign_traffic"]:
            with self.subTest(scenario_id=scenario_id):
                _, _, summary = self.run_scenario(scenario_id)
                self.assertFalse(summary["security_alert"])
                self.assertEqual(summary["actual_operational_route"], "BENIGN_EXPLAINED_BREAK")

    def test_failed_collector_routes_to_hold(self):
        _, _, summary = self.run_scenario("collector_failure")
        self.assertEqual(summary["actual_operational_route"], "TELEMETRY_HOLD")

    def test_suppression_attack_routes_to_hold_not_numeric_zero(self):
        _, metric, summary = self.run_scenario("log_suppression_attack")
        endpoint = next(row for row in metric if row["metric"] == "endpoint_alerts")
        self.assertEqual(endpoint["engine_classification"], "TARGET_SUPPRESSED_HOLD")
        self.assertEqual(summary["actual_operational_route"], "TELEMETRY_HOLD")

    def test_lifecycle_is_not_anomaly(self):
        for scenario_id in ["new_edr_sensor", "retired_proxy_metric"]:
            with self.subTest(scenario_id=scenario_id):
                _, _, summary = self.run_scenario(scenario_id)
                self.assertEqual(summary["actual_operational_route"], "SERIES_LIFECYCLE_CHANGE")
                self.assertFalse(summary["security_alert"])

    def test_fixed_v6_thresholds_are_unchanged(self):
        self.assertEqual(self.engine.z_threshold, 3.0)
        self.assertEqual(self.engine.min_relative_deviation, 0.25)
        self.assertEqual(self.engine.consensus_threshold, 2 / 3)
        self.assertEqual(self.engine.min_history, 4)


if __name__ == "__main__":
    unittest.main()
