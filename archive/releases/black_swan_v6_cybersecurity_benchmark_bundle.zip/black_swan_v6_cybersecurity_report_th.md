# รายงานชุดทดสอบจำลอง Cybersecurity สำหรับ Black Swan Logic v6

## ผลลัพธ์หลัก

- ข้อมูลจำลองแบบ hourly aggregate: 8,330 แถว, 17 สถานการณ์, 10 metrics
- Monte Carlo: 840 runs
- Benign false-alert rate: 0.00%
- Recall ต่อการโจมตีแบบแรง/ฉับพลัน: 100.00%
- Recall ต่อ evasive attacks: 1.11%
- Curated false positives: 0
- Curated false negatives: 3

## ผล curated scenarios

| Scenario | Truth | Evasive | Desired alert | Actual route | Alerted metrics | Correct |
|---|---|---:|---:|---|---|---:|
| normal_control | control | false | false | NO_ALERT | - | true |
| planned_cloud_drift | benign | false | false | NO_SECURITY_ALERT | - | true |
| approved_backup | benign | false | false | BENIGN_EXPLAINED_BREAK | - | true |
| software_release | benign | false | false | BENIGN_EXPLAINED_BREAK | - | true |
| campaign_traffic | benign | false | false | BENIGN_EXPLAINED_BREAK | - | true |
| password_spray | attack | false | true | SECURITY_ANOMALY_REVIEW | auth_failures|unique_failed_accounts|unique_source_ips | true |
| credential_stuffing | attack | false | true | SECURITY_ANOMALY_REVIEW | auth_failures|unique_source_ips|successful_logins | true |
| ddos_burst | attack | false | true | SECURITY_ANOMALY_REVIEW | api_5xx|inbound_requests | true |
| exfiltration_burst | attack | false | true | SECURITY_ANOMALY_REVIEW | outbound_mb | true |
| ransomware_burst | attack | false | true | SECURITY_ANOMALY_REVIEW | endpoint_alerts|file_rename_events | true |
| privilege_escalation | attack | false | true | SECURITY_ANOMALY_REVIEW | privileged_changes | true |
| slow_exfiltration | attack | true | true | NO_SECURITY_ALERT | - | false |
| correlated_subthreshold | attack | true | true | MODEL_REVIEW | - | false |
| collector_failure | data_quality | false | false | TELEMETRY_HOLD | - | true |
| log_suppression_attack | attack | true | true | TELEMETRY_HOLD | - | false |
| new_edr_sensor | lifecycle | false | false | SERIES_LIFECYCLE_CHANGE | - | true |
| retired_proxy_metric | lifecycle | false | false | SERIES_LIFECYCLE_CHANGE | - | true |

## สิ่งที่ชุดทดสอบนี้เปิดเผย

v6 ยังคงเหมาะกับ shock ที่แรงและเกิดฉับพลัน และ causal layer ช่วยไม่ให้ planned backup, software release หรือ campaign traffic ถูกยกระดับเป็นภัยไซเบอร์โดยอัตโนมัติ

แต่ cybersecurity มีรูปแบบที่ Medicare test ไม่ได้บังคับให้ระบบเผชิญ: หลายสัญญาณอ่อนที่สัมพันธ์กัน, low-and-slow behavior และ telemetry suppression ชุดนี้จึงจงใจเก็บ false negatives เหล่านั้นไว้ เพื่อใช้เป็นข้อกำหนดสำหรับรุ่นถัดไป ไม่ลบหรือปรับ threshold เพื่อให้คะแนนดูดี

## ขอบเขต

ข้อมูลทั้งหมดเป็น aggregate synthetic telemetry ไม่มีข้อมูลจริงของบุคคล องค์กร เครื่อง ผู้ใช้ IP credential payload หรือ exploit การทดสอบนี้วัดตรรกะ anomaly/quality/context เท่านั้น ไม่ใช่การประเมิน IDS/EDR production และไม่พิสูจน์ความสามารถตรวจจับภัยทุกชนิด

Dataset SHA-256: `1df67809d5b5dd8453291bb50cca6063ed1636c3f568d7bab211d441f07cf20d`
