#!/usr/bin/env python3
"""Reproducible offline learning experiment. Every invocation writes a new run."""
from pathlib import Path
import argparse,hashlib,json,platform,sys
from datetime import datetime,timezone
from dataclasses import asdict
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from black_swan_general import BlackSwanGeneralEngine,EngineConfig,OutcomeMemory
from black_swan_general.evaluation import collect_verified_outcomes,evaluate_engine
from black_swan_general.generators import generate_known_cases,generate_novel_holdout,input_record,label_record
from black_swan_general.benchmark_cases import additional_holdout
from black_swan_general.learning_gate import LearningGate
from black_swan_general.memory import stable_problem_hash


def write_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')


def write_jsonl(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w') as f:
        for row in rows: f.write(json.dumps(row,ensure_ascii=False,sort_keys=True,allow_nan=False)+'\n')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def without_rows(report): return {k:v for k,v in report.items() if k!='rows'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=args.output or ROOT/'runs'/stamp
    if out.exists(): raise SystemExit('Output already exists; use a new path to preserve evidence.')
    out.mkdir(parents=True)
    lock=json.loads((ROOT/'configs/experiment.lock.json').read_text())
    write_json(out/'protocol.json',lock)
    config=EngineConfig(max_attempts=lock['max_attempts'],time_budget_ms=lock['time_budget_ms'])
    learning=generate_known_cases('learning',per_family=lock['learning_per_family'],seed=lock['learning_seed'])
    validation=generate_known_cases('validation',per_family=lock['validation_per_family'],seed=lock['validation_seed'])
    holdout=(generate_known_cases('holdout',per_family=lock['holdout_per_family'],seed=lock['holdout_seed'])
             +generate_novel_holdout(seed=lock['holdout_seed']+100)
             +additional_holdout(lock['extra_holdout_seed']))
    splits=dict(learning=learning,validation=validation,holdout=holdout)
    identities={name:{stable_problem_hash(input_record(c)) for c in cases} for name,cases in splits.items()}
    for a,b in [('learning','validation'),('learning','holdout'),('validation','holdout')]:
        if identities[a]&identities[b]: raise RuntimeError(f'cross-split identical requests: {a}/{b}')
    for name,cases in splits.items():
        write_jsonl(out/'datasets'/f'{name}_inputs.jsonl',map(input_record,cases))
        write_jsonl(out/'datasets'/f'{name}_labels.jsonl',map(label_record,cases))
    input_manifest={str(p.relative_to(out)):sha(p) for p in sorted((out/'datasets').glob('*.jsonl'))}
    write_json(out/'dataset_manifest.json',dict(provenance='deterministic synthetic fixtures',
              counts={k:len(v) for k,v in splits.items()},hashes=input_manifest,
              exact_cross_split_overlap=0,unique_requests={k:len(v) for k,v in identities.items()},related_template_families=True))
    base_validation=evaluate_engine(BlackSwanGeneralEngine(config=config),validation)
    memory=OutcomeMemory()
    training=collect_verified_outcomes(BlackSwanGeneralEngine(config=config),learning,memory)
    memory.write_jsonl(out/'candidate_memory.jsonl')
    write_jsonl(out/'training_outcomes.jsonl',training)
    candidate_validation=evaluate_engine(BlackSwanGeneralEngine(memory=memory,config=config),validation)
    gate=LearningGate().evaluate(base_validation['metrics'],candidate_validation['metrics'],
        label_sources=[r.label_source for r in memory.all()],
        baseline_families=base_validation['by_family'],candidate_families=candidate_validation['by_family'])
    write_json(out/'learning_gate.json',asdict(gate))
    active=OutcomeMemory(memory.all()) if gate.passed else OutcomeMemory()
    active.write_jsonl(out/'active_memory.jsonl')
    write_json(out/'memory_release.json',dict(gate_passed=gate.passed,
               memory_file='active_memory.jsonl',sha256=sha(out/'active_memory.jsonl'),
               gate_sha256=sha(out/'learning_gate.json'),protocol_sha256=sha(out/'protocol.json')))
    # Memory is frozen before held-out evaluation; labels never enter decide().
    digest_before=sha(out/'active_memory.jsonl')
    base=evaluate_engine(BlackSwanGeneralEngine(config=config),holdout)
    learned=evaluate_engine(BlackSwanGeneralEngine(memory=active,config=config),holdout)
    for name,result in [('validation_baseline',base_validation),('validation_candidate',candidate_validation),
                        ('holdout_baseline',base),('holdout_learned',learned)]:
        write_jsonl(out/f'{name}_decisions.jsonl',result['rows'])
    if sha(out/'active_memory.jsonl')!=digest_before: raise RuntimeError('holdout mutated persisted memory')
    final_memory=out/'memory_after_holdout.jsonl';active.write_jsonl(final_memory)
    if sha(final_memory)!=digest_before: raise RuntimeError('holdout mutated in-memory records')
    code_paths=sorted((ROOT/'src').rglob('*.py'))+[ROOT/'run_experiment.py',ROOT/'configs/experiment.lock.json']
    code_hashes={str(p.relative_to(ROOT)):sha(p) for p in code_paths}
    summary=dict(name='Black Swan General Decision Lab',build='2026-09-14',run_id=stamp,
        config=asdict(config),environment=dict(python=sys.version,platform=platform.platform(),dependencies='standard library'),
        source_hashes=code_hashes,protocol_sha256=sha(ROOT/'configs/experiment.lock.json'),
        counts={k:len(v) for k,v in splits.items()},candidate_records=len(memory),active_records=len(active),
        learning_gate=asdict(gate),holdout_memory_unchanged=True,
        validation=dict(baseline=without_rows(base_validation),learned=without_rows(candidate_validation)),
        holdout=dict(baseline=without_rows(base),learned=without_rows(learned)),
        claim_boundary='Offline deterministic strategy selection, not neural training or automatic algorithm invention.')
    write_json(out/'summary.json',summary)
    failures=[dict(problem_id=r['problem_id'],family=r['family'],route=r['route'],answer=r.get('answer'),
                   reason_code=r.get('reason_code')) for r in learned['rows'] if not r['correct']]
    write_json(out/'unresolved_failures.json',failures)
    write_json(ROOT/'latest_run.json',dict(path=str(out.resolve()),relative_path=str(out.relative_to(ROOT)) if out.is_relative_to(ROOT) else None))
    print(json.dumps(dict(run=str(out),gate_passed=gate.passed,baseline=base['metrics'],learned=learned['metrics'],failure_count=len(failures)),indent=2))
    return 0 if gate.passed else 2

if __name__=='__main__': raise SystemExit(main())
