"""Read local JSON/JSONL and gate-approved memory. No network or implicit labels."""
from pathlib import Path
import hashlib,json
from .contracts import ProblemRequest, EvaluationCase
from .memory import OutcomeMemory


def request_from_dict(row):
    allowed={'problem_id','objective','payload','constraints','risk_level'}
    if not isinstance(row,dict) or set(row)-allowed:
        raise ValueError('input has unknown fields; keep labels/family/split in the label file')
    return ProblemRequest(**row)


def read_requests(path):
    path=Path(path)
    if path.stat().st_size>20_000_000:
        raise ValueError('input file exceeds 20 MB; split the batch')
    if path.suffix=='.jsonl':
        rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    else:
        value=json.loads(path.read_text())
        rows=value if isinstance(value,list) else [value]
    requests=[request_from_dict(row) for row in rows]
    ids=[r.problem_id for r in requests]
    if len(ids)!=len(set(ids)): raise ValueError('duplicate problem_id')
    return requests


def read_cases(inputs,labels,split):
    requests=read_requests(inputs)
    rows=[json.loads(line) for line in Path(labels).read_text().splitlines() if line.strip()]
    by_id={r['problem_id']:r for r in rows}
    if len(by_id)!=len(rows): raise ValueError('duplicate label problem_id')
    if set(by_id)!={r.problem_id for r in requests}: raise ValueError('input/label IDs must match exactly')
    cases=[]
    for request in requests:
        row=by_id[request.problem_id]
        if row.get('split',split)!=split: raise ValueError('split mismatch')
        if 'expected_answer' not in row and not row.get('expected_route'):
            raise ValueError('label requires expected_answer or expected_route')
        tolerance=row.get('numeric_tolerance',1e-9)
        import math
        if type(tolerance) not in (int,float) or not math.isfinite(tolerance) or tolerance<0:
            raise ValueError('invalid tolerance')
        cases.append(EvaluationCase(request,row.get('family','custom'),split,
                      row.get('expected_answer'),row.get('expected_route'),tolerance))
    return cases


def load_release(directory):
    directory=Path(directory)
    release=json.loads((directory/'memory_release.json').read_text())
    gate_path=directory/'learning_gate.json'
    memory_path=directory/'active_memory.jsonl'
    if not release.get('gate_passed') or release.get('memory_file')!='active_memory.jsonl':
        raise ValueError('memory release did not pass its gate')
    for path,key in ((memory_path,'sha256'),(gate_path,'gate_sha256')):
        if hashlib.sha256(path.read_bytes()).hexdigest()!=release[key]:
            raise ValueError('memory release checksum mismatch')
    if not json.loads(gate_path.read_text()).get('passed'):
        raise ValueError('gate rejected this memory')
    return OutcomeMemory.from_jsonl(memory_path)
