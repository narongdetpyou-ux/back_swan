"""Additional held-out representations and stress cases, fixed before final run."""
import random
from .contracts import ProblemRequest, EvaluationCase


def additional_holdout(seed):
    rng=random.Random(seed)
    cases=[]
    for i in range(30):
        base=rng.randint(-90,90)+i/100
        policy=('robust','unknown','zero')[i%3]
        values=[base,base+2,base+4,None,base+100]
        expected=base+3 if policy=='robust' else base+26.5 if policy=='unknown' else (4*base+106)/5
        req=ProblemRequest(f'transfer-{i}','column_summary',{'columns':{'reading':values}},
                           {'column':'reading','missing_semantics':policy})
        cases.append(EvaluationCase(req,'transfer_columnar_'+policy,'holdout',expected))
    for i in range(15):
        n=5+i%5
        nodes=[f'node-{i}-{j}' for j in range(n)]
        edges=[[a,b] for a in nodes for b in nodes if a!=b and rng.random()<.15]
        source,target=nodes[-1],nodes[0]
        # Harness uses recursive path search, distinct from BFS and verifier closure.
        def reaches(node,seen):
            if node==target: return True
            return any(reaches(b,seen|{b}) for a,b in edges if a==node and b not in seen)
        expected=reaches(source,{source})
        req=ProblemRequest(f'graph-shift-{i}','reachable',dict(nodes=nodes,edges=edges,source=source,target=target,directed=True))
        cases.append(EvaluationCase(req,'challenge_graph_topology','holdout',expected))
    # Deliberately out-of-template semantics. This is a capability probe, not
    # a success gate tuned to the existing lexical solver.
    for i in range(10):
        prefix=['The start was not good.','The draft was bad.'][i%2]
        text=prefix+' However, the final result is excellent.'
        req=ProblemRequest(f'text-shift-{i}','sentiment',text)
        cases.append(EvaluationCase(req,'challenge_text_contrast','holdout','positive'))
    for i in range(5):
        req=ProblemRequest(f'invalid-row-{i}','column_summary',[{'value':i},{'value':'invalid'}],{'missing_semantics':'unknown'})
        cases.append(EvaluationCase(req,'challenge_invalid_numeric','holdout',evaluator_expected_route='CANNOT_SOLVE'))
    for i in range(5):
        req=ProblemRequest(f'unknown-format-{i}','interpret_image',{'pixels_encoded':f'new-format-{i}'})
        cases.append(EvaluationCase(req,'challenge_unknown_format','holdout',evaluator_expected_route='CANNOT_SOLVE'))
    for i in range(5):
        req=ProblemRequest(f'needs-column-rule-{i}','column_summary',[{'value':i},{'value':None}])
        cases.append(EvaluationCase(req,'challenge_missing_contract','holdout',evaluator_expected_route='NEED_MORE_DATA'))
    return cases
