"""Two bounded solvers for the user's numerical-stability experiment.

This is an explicit new task contract, not an automatically invented algorithm.
The verifier evaluates a closed form separately from these recurrence loops.
"""
from fractions import Fraction
from .contracts import CandidateAnswer


def parameters(payload):
    if not isinstance(payload, dict) or payload.get('recurrence') != 'muller_5_6':
        raise ValueError('unsupported recurrence')
    if set(payload) != {'recurrence', 'steps', 'weights'}:
        raise ValueError('recurrence requires exactly recurrence, steps, weights')
    n, weights = payload['steps'], payload['weights']
    if type(n) is not int or not 0 <= n <= 200:
        raise ValueError('steps must be an integer from 0 to 200')
    if not isinstance(weights, list) or len(weights) != 2:
        raise ValueError('weights must contain two positive integers')
    if any(type(w) is not int or not 1 <= w <= 10000 for w in weights):
        raise ValueError('weights must be positive integers at most 10000')
    return n, weights[0], weights[1]


def recurrence_float(request, profile):
    n, a, b = parameters(request.payload)
    previous = (5*a + 6*b) / (a+b)
    current = (25*a + 36*b) / (5*a + 6*b)
    if n == 0:
        answer = previous
    else:
        for _ in range(2, n+1):
            previous, current = current, 111.0 - (1130.0 - 3000.0 / previous) / current
        answer = current
    return CandidateAnswer('recurrence_float', answer,
                           {'arithmetic':'binary64', 'steps':n},
                           'Evaluate the recurrence using ordinary floating point.')


def recurrence_fraction(request, profile):
    n, a, b = parameters(request.payload)
    previous = Fraction(5*a + 6*b, a+b)
    current = Fraction(25*a + 36*b, 5*a + 6*b)
    if n == 0:
        answer = previous
    else:
        for _ in range(2, n+1):
            previous, current = current, 111 - (1130 - 3000 / previous) / current
        answer = current
    return CandidateAnswer('recurrence_fraction', float(answer),
                           {'arithmetic':'exact_rational_then_float', 'steps':n,
                            'numerator':str(answer.numerator), 'denominator':str(answer.denominator)},
                           'Use exact rational arithmetic; round once for the returned float.')
