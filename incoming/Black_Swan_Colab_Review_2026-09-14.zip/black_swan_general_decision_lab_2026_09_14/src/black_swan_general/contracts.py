"""Shared, label-free contracts for the General Decision Lab."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass(frozen=True)
class ProblemRequest:
    """The only object visible to the decision engine.

    Evaluator answers, family names, and success labels deliberately live in a
    separate ``EvaluationCase`` and cannot be accessed through this interface.
    """

    problem_id: str
    objective: str
    payload: Any
    constraints: Dict[str, Any] = field(default_factory=dict)
    risk_level: str = "low"


@dataclass(frozen=True)
class EvaluationCase:
    """Harness-only wrapper containing hidden synthetic ground truth."""

    request: ProblemRequest
    family: str
    split: str
    evaluator_expected_answer: Any = None
    evaluator_expected_route: Optional[str] = None
    numeric_tolerance: float = 1e-9


@dataclass(frozen=True)
class DataProfile:
    data_type: str
    objective: str
    item_count: int
    missing_fraction: float
    flags: Tuple[str, ...]
    signature: str
    critical_missing: bool = False
    notes: Tuple[str, ...] = ()


@dataclass(frozen=True)
class CandidateAnswer:
    strategy: str
    answer: Any
    evidence: Dict[str, Any]
    explanation: str


@dataclass(frozen=True)
class VerificationResult:
    accepted: bool
    score: float
    hard_failure: bool
    reason_code: str
    issues: Tuple[str, ...] = ()


@dataclass(frozen=True)
class RankedStrategy:
    strategy: str
    score: float
    base_score: float
    heuristic_bonus: float
    memory_bonus: float
    memory_examples: int
    memory_success_rate: Optional[float]


@dataclass
class AttemptRecord:
    attempt_index: int
    ranked_strategy: RankedStrategy
    candidate: Optional[CandidateAnswer]
    verification: VerificationResult
    error: str = ""


@dataclass
class Decision:
    problem_id: str
    route: str
    answer: Any
    selected_strategy: str
    confidence: float
    reason_code: str
    data_profile: DataProfile
    attempts: List[AttemptRecord]
    memory_used: bool
    review_required: bool
    adapter: str = "identity"
    terminal_reason: str = ""
    information_needed: Tuple[str, ...] = ()


@dataclass(frozen=True)
class OutcomeRecord:
    outcome_id: str
    profile_signature: str
    data_type: str
    objective: str
    strategy: str
    success: bool
    reward: float
    verifier_score: float
    issue_codes: Tuple[str, ...]
    label_source: str
    source_problem_hash: str
    evidence_hash: str


@dataclass(frozen=True)
class GateDecision:
    passed: bool
    reason_codes: Tuple[str, ...]
    baseline_metrics: Dict[str, float]
    candidate_metrics: Dict[str, float]
    provisional_limits: Dict[str, float]
