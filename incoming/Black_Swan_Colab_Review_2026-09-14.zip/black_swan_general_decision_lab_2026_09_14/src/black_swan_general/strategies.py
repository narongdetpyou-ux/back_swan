"""3. Solver: deterministic strategy registry for heterogeneous problems."""

from __future__ import annotations

from dataclasses import dataclass
import math
import re
import statistics
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

from .contracts import CandidateAnswer, DataProfile, ProblemRequest
from .numerics import recurrence_float, recurrence_fraction


class SolverError(ValueError):
    pass


SolverFunction = Callable[[ProblemRequest, DataProfile], CandidateAnswer]


@dataclass(frozen=True)
class Strategy:
    name: str
    data_type: str
    objectives: Tuple[str, ...]
    solve: SolverFunction


def _complete_numbers(values: Iterable) -> List[float]:
    result = [
        float(value)
        for value in values
        if value is not None
        and isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    ]
    if not result:
        raise SolverError("no complete numeric values")
    return result


def ts_last(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    values = _complete_numbers(request.payload["values"])
    return CandidateAnswer(
        "ts_last",
        values[-1],
        {"method": "last_observation", "points_used": 1},
        "Use the last complete observation as the next value.",
    )


def ts_mean(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    values = _complete_numbers(request.payload["values"])
    return CandidateAnswer(
        "ts_mean",
        statistics.fmean(values),
        {"method": "global_mean", "points_used": len(values)},
        "Use the mean of all complete observations.",
    )


def ts_linear(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    raw = request.payload["values"]
    pairs = [
        (index, float(value))
        for index, value in enumerate(raw)
        if value is not None
        and isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    ]
    if len(pairs) < 2:
        raise SolverError("linear extrapolation requires two complete points")
    xs = [item[0] for item in pairs]
    ys = [item[1] for item in pairs]
    x_mean = statistics.fmean(xs)
    y_mean = statistics.fmean(ys)
    denominator = sum((x - x_mean) ** 2 for x in xs)
    if denominator <= 1e-12:
        raise SolverError("degenerate time coordinates")
    slope = sum((x - x_mean) * (y - y_mean) for x, y in pairs) / denominator
    answer = y_mean + slope * (len(raw) - x_mean)
    return CandidateAnswer(
        "ts_linear",
        answer,
        {"method": "least_squares_linear", "slope": slope, "points_used": len(pairs)},
        "Fit a line to complete observations and extrapolate one step.",
    )


def ts_seasonal(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    raw = request.payload["values"]
    period = int(request.constraints.get("period", 0) or 0)
    if period < 2 or len(raw) < period:
        raise SolverError("seasonal strategy requires a valid period")
    answer = raw[-period]
    if answer is None or not isinstance(answer, (int, float)):
        raise SolverError("seasonal reference point is missing")
    return CandidateAnswer(
        "ts_seasonal",
        float(answer),
        {"method": "seasonal_lag", "period": period},
        "Reuse the observation from the same phase in the previous cycle.",
    )


def _table_values(request: ProblemRequest) -> Tuple[List[float], int]:
    column = str(request.constraints.get("column", "value"))
    raw = [row.get(column) for row in request.payload]
    complete = _complete_numbers(raw)
    return complete, len(raw) - len(complete)


def table_zero_fill_mean(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    column = str(request.constraints.get("column", "value"))
    raw = [row.get(column) for row in request.payload]
    numbers = [0.0 if value is None else float(value) for value in raw]
    if not numbers:
        raise SolverError("table is empty")
    return CandidateAnswer(
        "table_zero_fill_mean",
        statistics.fmean(numbers),
        {"method": "mean", "missing_policy": "zero", "column": column},
        "Replace missing values with zero, then calculate the mean.",
    )


def table_drop_missing_mean(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    values, missing = _table_values(request)
    return CandidateAnswer(
        "table_drop_missing_mean",
        statistics.fmean(values),
        {"method": "mean", "missing_policy": "unknown", "missing_count": missing},
        "Exclude unknown values, then calculate the mean.",
    )


def table_median(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    values, missing = _table_values(request)
    return CandidateAnswer(
        "table_median",
        float(statistics.median(values)),
        {"method": "median", "missing_policy": "robust", "missing_count": missing},
        "Use the median of complete values for a robust estimate.",
    )


POSITIVE = {"good", "excellent", "improved", "safe", "approved", "success", "stable"}
NEGATIVE = {"bad", "failed", "unsafe", "denied", "risk", "declined", "unstable"}
NEGATIONS = {"not", "no", "never"}


def _tokens(text: str) -> List[str]:
    return re.findall(r"[a-z']+", text.lower())


def _label(score: int) -> str:
    return "positive" if score > 0 else "negative" if score < 0 else "neutral"


def text_keyword(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    tokens = _tokens(request.payload)
    score = sum(token in POSITIVE for token in tokens) - sum(token in NEGATIVE for token in tokens)
    return CandidateAnswer(
        "text_keyword",
        _label(score),
        {"method": "keyword_count", "score": score},
        "Count positive and negative words without interpreting negation.",
    )


def text_last_sentiment(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    tokens = _tokens(request.payload)
    sentiment = [token for token in tokens if token in POSITIVE or token in NEGATIVE]
    if not sentiment:
        answer = "neutral"
    else:
        answer = "positive" if sentiment[-1] in POSITIVE else "negative"
    return CandidateAnswer(
        "text_last_sentiment",
        answer,
        {"method": "last_sentiment_word", "word": sentiment[-1] if sentiment else ""},
        "Use the last sentiment-bearing word.",
    )


def text_negation_aware(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    tokens = _tokens(request.payload)
    score = 0
    negate = False
    for token in tokens:
        if token in NEGATIONS:
            negate = not negate
            continue
        value = 1 if token in POSITIVE else -1 if token in NEGATIVE else 0
        if value:
            score += -value if negate else value
            negate = False
    return CandidateAnswer(
        "text_negation_aware",
        _label(score),
        {"method": "negation_window", "score": score},
        "Invert the next sentiment-bearing word after a negation.",
    )


def _matching_rules(request: ProblemRequest) -> List[dict]:
    facts = request.payload["facts"]
    matches = []
    for index, rule in enumerate(request.payload["rules"]):
        conditions = rule.get("when", {})
        if all(key in facts and type(facts[key]) is type(value) and facts[key] == value for key, value in conditions.items()):
            matches.append({**rule, "_index": index})
    if not matches:
        raise SolverError("no rule matched the supplied facts")
    return matches


def _rule_candidate(name: str, rule: dict, precedence: str) -> CandidateAnswer:
    return CandidateAnswer(
        name,
        rule["result"],
        {
            "method": "rule_evaluation",
            "precedence": precedence,
            "rule_index": rule["_index"],
            "condition_count": len(rule.get("when", {})),
            "priority": int(rule.get("priority", 0)),
        },
        f"Select a matching rule using {precedence} precedence.",
    )


def rules_first(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    return _rule_candidate("rules_first", _matching_rules(request)[0], "first")


def rules_specificity(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    selected = max(
        _matching_rules(request),
        key=lambda rule: (len(rule.get("when", {})), -rule["_index"]),
    )
    return _rule_candidate("rules_specificity", selected, "specificity")


def rules_priority(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    selected = max(
        _matching_rules(request),
        key=lambda rule: (int(rule.get("priority", 0)), -rule["_index"]),
    )
    return _rule_candidate("rules_priority", selected, "priority")


def _adjacency(edges: Sequence, directed: bool) -> Dict[str, List[Tuple[str, float]]]:
    graph: Dict[str, List[Tuple[str, float]]] = {}
    for edge in edges:
        if len(edge) < 2:
            continue
        left, right = str(edge[0]), str(edge[1])
        weight = float(edge[2]) if len(edge) >= 3 else 1.0
        graph.setdefault(left, []).append((right, weight))
        graph.setdefault(right, [])
        if not directed:
            graph[right].append((left, weight))
    return graph


def _bfs_path(graph: Dict[str, List[Tuple[str, float]]], source: str, target: str):
    queue = [(source, [source])]
    visited = {source}
    while queue:
        node, path = queue.pop(0)
        if node == target:
            return path
        for neighbor, _ in graph.get(node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
    return []


def _graph_candidate(request: ProblemRequest, directed: bool, name: str) -> CandidateAnswer:
    source = str(request.payload["source"])
    target = str(request.payload["target"])
    path = _bfs_path(_adjacency(request.payload["edges"], directed), source, target)
    return CandidateAnswer(
        name,
        bool(path),
        {"method": "breadth_first_search", "directed": directed, "path": path},
        f"Check reachability using {'directed' if directed else 'undirected'} edges.",
    )


def graph_directed(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    return _graph_candidate(request, True, "graph_directed")


def graph_undirected(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    return _graph_candidate(request, False, "graph_undirected")


def mixed_majority(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    votes = [bool(item["vote"]) for item in request.payload["components"]]
    answer = sum(votes) > len(votes) / 2
    return CandidateAnswer(
        "mixed_majority",
        "accept" if answer else "reject",
        {"method": "majority", "positive_votes": sum(votes), "votes": len(votes)},
        "Treat each evidence source as an equal vote.",
    )


def mixed_trust_weighted(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    components = request.payload["components"]
    signed = sum(
        float(request.constraints.get("source_weights", {}).get(item["source"], 0.0)) * (1.0 if item["vote"] else -1.0)
        for item in components
    )
    return CandidateAnswer(
        "mixed_trust_weighted",
        "accept" if signed > 0 else "reject",
        {"method": "trust_weighted", "signed_support": signed},
        "Weight each vote by the independently supplied trust value.",
    )


def mixed_unanimous(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    votes = [bool(item["vote"]) for item in request.payload["components"]]
    return CandidateAnswer(
        "mixed_unanimous",
        "accept" if all(votes) else "reject",
        {"method": "unanimous", "votes": len(votes)},
        "Accept only when every evidence source agrees.",
    )


def matrix_trace(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    matrix = request.payload
    if not matrix or any(len(row) != len(matrix) for row in matrix):
        raise SolverError("matrix has no complete diagonal")
    answer = sum(float(row[index]) for index, row in enumerate(matrix))
    return CandidateAnswer(
        "matrix_trace",
        answer,
        {"method": "matrix_trace", "size": len(matrix)},
        "Sum values on the main diagonal.",
    )


def matrix_total(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    answer = sum(float(value) for row in request.payload for value in row)
    return CandidateAnswer(
        "matrix_total",
        answer,
        {"method": "matrix_total", "rows": len(request.payload)},
        "Sum every value in the matrix.",
    )


def sequence_count(request: ProblemRequest, _: DataProfile) -> CandidateAnswer:
    return CandidateAnswer(
        "sequence_count",
        len(request.payload),
        {"method": "sequence_count"},
        "Count items in the supplied sequence.",
    )


DEFAULT_STRATEGIES: Tuple[Strategy, ...] = (
    Strategy("ts_last", "time_series", ("forecast_next",), ts_last),
    Strategy("ts_mean", "time_series", ("forecast_next",), ts_mean),
    Strategy("ts_linear", "time_series", ("forecast_next",), ts_linear),
    Strategy("ts_seasonal", "time_series", ("forecast_next",), ts_seasonal),
    Strategy("table_zero_fill_mean", "table", ("column_summary",), table_zero_fill_mean),
    Strategy("table_drop_missing_mean", "table", ("column_summary",), table_drop_missing_mean),
    Strategy("table_median", "table", ("column_summary",), table_median),
    Strategy("text_keyword", "text", ("sentiment",), text_keyword),
    Strategy("text_last_sentiment", "text", ("sentiment",), text_last_sentiment),
    Strategy("text_negation_aware", "text", ("sentiment",), text_negation_aware),
    Strategy("rules_first", "rules", ("rule_decision",), rules_first),
    Strategy("rules_specificity", "rules", ("rule_decision",), rules_specificity),
    Strategy("rules_priority", "rules", ("rule_decision",), rules_priority),
    Strategy("graph_directed", "graph", ("reachable",), graph_directed),
    Strategy("graph_undirected", "graph", ("reachable",), graph_undirected),
    Strategy("mixed_majority", "mixed", ("evidence_decision",), mixed_majority),
    Strategy("mixed_unanimous", "mixed", ("evidence_decision",), mixed_unanimous),
    Strategy("mixed_trust_weighted", "mixed", ("evidence_decision",), mixed_trust_weighted),
    Strategy("matrix_trace", "matrix", ("matrix_trace",), matrix_trace),
    Strategy("matrix_total", "matrix", ("matrix_total",), matrix_total),
    Strategy("sequence_count", "sequence", ("count_items",), sequence_count),
    Strategy('recurrence_float', 'recurrence', ('recurrence_value',), recurrence_float),
    Strategy('recurrence_fraction', 'recurrence', ('recurrence_value',), recurrence_fraction),
)


class StrategyRegistry:
    def __init__(self, strategies: Sequence[Strategy] = DEFAULT_STRATEGIES):
        self._strategies = {strategy.name: strategy for strategy in strategies}
        if len(self._strategies) != len(strategies):
            raise ValueError("duplicate strategy name")

    def applicable(self, profile: DataProfile) -> Tuple[Strategy, ...]:
        return tuple(
            strategy
            for strategy in self._strategies.values()
            if strategy.data_type == profile.data_type
            and profile.objective in strategy.objectives
        )

    def get(self, name: str) -> Strategy:
        return self._strategies[name]

    def all(self) -> Tuple[Strategy, ...]:
        return tuple(self._strategies[name] for name in sorted(self._strategies))
