"""7. Gate candidate memory on fixed validation, including family regressions."""
import math
from .contracts import GateDecision
from .memory import TRUSTED_LABEL_SOURCES


class LearningGate:
    def __init__(self, *, max_review_rate=.05, max_error_rate=0.0, minimum_success_delta=0.0):
        values = (max_review_rate, max_error_rate, minimum_success_delta)
        if any(not math.isfinite(x) or not 0 <= x <= 1 for x in values):
            raise ValueError("invalid gate limits")
        self.limits = dict(max_review_rate=max_review_rate, max_error_rate=max_error_rate,
                           minimum_success_delta=minimum_success_delta)

    def evaluate(self, baseline_metrics, candidate_metrics, *, label_sources,
                 baseline_families=None, candidate_families=None):
        b,c = baseline_metrics,candidate_metrics
        reasons = []
        sources = set(label_sources)
        if not sources or not sources <= TRUSTED_LABEL_SOURCES:
            reasons.append("UNTRUSTED_OR_MISSING_LABEL_SOURCE")
        required = ("cases", "task_success_rate", "false_confidence_rate", "review_rate", "error_rate")
        for m in (b,c):
            if any(k not in m or not isinstance(m[k], (float,int)) or not math.isfinite(m[k]) for k in required):
                reasons.append("MISSING_OR_NONFINITE_METRICS")
                break
            if m["cases"] <= 0:
                reasons.append("EMPTY_VALIDATION")
            for key,value in m.items():
                if value is not None and isinstance(value,(int,float)) and not math.isfinite(value):
                    reasons.append("NONFINITE_METRIC:"+key)
            if any(not 0 <= m[k] <= 1 for k in required if k != "cases"):
                reasons.append("INVALID_METRIC_RANGE")
        if not reasons:
            if b["cases"] != c["cases"]:
                reasons.append("POPULATION_MISMATCH")
            if c["task_success_rate"] < b["task_success_rate"] + self.limits["minimum_success_delta"]:
                reasons.append("TASK_SUCCESS_REGRESSION")
            if c["false_confidence_rate"] > b["false_confidence_rate"]:
                reasons.append("FALSE_CONFIDENCE_REGRESSION")
            if c.get("automatic_error_rate",0) > b.get("automatic_error_rate",0):
                reasons.append("AUTOMATIC_ERROR_REGRESSION")
            if c.get("automated_coverage",1) < b.get("automated_coverage",1):
                reasons.append("COVERAGE_REGRESSION")
            if c["review_rate"] > self.limits["max_review_rate"]:
                reasons.append("REVIEW_RATE_LIMIT_EXCEEDED")
            if c["error_rate"] > self.limits["max_error_rate"]:
                reasons.append("ERROR_RATE_LIMIT_EXCEEDED")
        if baseline_families is not None or candidate_families is not None:
            bf,cf = baseline_families or {}, candidate_families or {}
            if not bf or bf.keys() != cf.keys():
                reasons.append("FAMILY_POPULATION_MISMATCH")
            else:
                for family in bf:
                    if bf[family]["cases"] != cf[family]["cases"]:
                        reasons.append("FAMILY_POPULATION_MISMATCH:"+family)
                    elif cf[family]["success_rate"] < bf[family]["success_rate"]:
                        reasons.append("FAMILY_REGRESSION:"+family)
        return GateDecision(not reasons, tuple(reasons) or ("VALIDATION_GATES_PASSED",),
                            dict(b), dict(c), dict(self.limits))
