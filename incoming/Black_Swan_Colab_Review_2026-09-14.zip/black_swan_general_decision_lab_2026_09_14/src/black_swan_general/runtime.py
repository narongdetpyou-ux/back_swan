"""Disposable process boundary for local, trusted Python extensions.

This bounds a blocking solver/verifier; it is not a security sandbox for hostile
code. No evaluator labels are passed to the child. Linux fork is tested.
"""
from __future__ import annotations
import multiprocessing as mp
import time
from .contracts import VerificationResult


def _work(pipe, strategy, verifier, request, profile):
    import copy
    original = copy.deepcopy(request)
    try:
        candidate = strategy.solve(request, profile)
        if candidate.strategy != strategy.name:
            raise ValueError("candidate strategy identity mismatch")
        result = verifier.verify(original, profile, candidate)
        pipe.send((candidate, result, ""))
    except BaseException as exc:
        try:
            pipe.send((None, VerificationResult(False, 0.0, True,
                       "ATTEMPT_ERROR", (type(exc).__name__,)), type(exc).__name__))
        except (BrokenPipeError, OSError):
            pass
    finally:
        pipe.close()


def isolated_attempt(strategy, verifier, request, profile, deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return None, VerificationResult(False, 0.0, True, "TIME_BUDGET_EXHAUSTED"), ""
    method = "fork" if "fork" in mp.get_all_start_methods() else "spawn"
    ctx = mp.get_context(method)
    reader, writer = ctx.Pipe(duplex=False)
    child = ctx.Process(target=_work, args=(writer, strategy, verifier, request, profile), daemon=True)
    try:
        child.start()
        writer.close()
        if reader.poll(max(0.0, deadline - time.monotonic())):
            try:
                result = reader.recv()
            except EOFError:
                return None, VerificationResult(False, 0.0, True, "WORKER_EXITED"), "WorkerExited"
            if time.monotonic() <= deadline:
                return result
        return None, VerificationResult(False, 0.0, True, "TIME_BUDGET_EXHAUSTED"), "Timeout"
    finally:
        reader.close()
        writer.close()
        if child.pid is not None:
            if child.is_alive():
                child.terminate()
            child.join(timeout=0.05)
            if child.is_alive():
                child.kill()
                child.join(timeout=0.05)
            child.close()
