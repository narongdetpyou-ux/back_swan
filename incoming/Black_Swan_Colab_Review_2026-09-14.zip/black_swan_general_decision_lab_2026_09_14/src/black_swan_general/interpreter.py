"""1. Data Interpreter: infer structure without seeing evaluator labels."""

from __future__ import annotations

import json
import math
import re
from statistics import fmean
from typing import Any, Iterable, Tuple

from .contracts import DataProfile, ProblemRequest


def _walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from _walk(child)


def _size(value: Any) -> int:
    if isinstance(value, dict):
        return len(value)
    if isinstance(value, (list, tuple, str)):
        return len(value)
    return 1


def _missing_fraction(value: Any) -> float:
    leaves = [item for item in _walk(value) if not isinstance(item, (dict, list, tuple))]
    if not leaves:
        return 1.0
    missing = sum(
        item is None or (isinstance(item, float) and not math.isfinite(item))
        for item in leaves
    )
    return missing / len(leaves)


def _numeric_sequence(value: Any) -> bool:
    return isinstance(value, (list, tuple)) and bool(value) and all(
        item is None or isinstance(item, (int, float)) and not isinstance(item, bool)
        for item in value
    )


def _detect_type(request: ProblemRequest) -> str:
    payload = request.payload
    if isinstance(payload, str):
        return "text"
    if isinstance(payload, dict):
        keys = set(payload)
        if payload.get('recurrence') == 'muller_5_6':
            return 'recurrence'
        if {"rules", "facts"} <= keys:
            return "rules"
        if {"nodes", "edges", "source", "target"} <= keys:
            return "graph"
        if "components" in keys:
            return "mixed"
        if "values" in keys and _numeric_sequence(payload["values"]):
            return "time_series"
        return "opaque"
    if isinstance(payload, (list, tuple)):
        if payload and all(isinstance(row, dict) for row in payload):
            return "table"
        if payload and all(isinstance(row, (list, tuple)) for row in payload):
            return "matrix"
        return "sequence"
    return "opaque"


def _time_flags(values: list, constraints: dict) -> Tuple[str, ...]:
    if any(value is None for value in values):
        return ()
    complete = [float(value) for value in values]
    flags = []
    period = int(constraints.get("period", 0) or 0)
    if period >= 2 and len(complete) >= period * 2:
        left = complete[-period * 2 : -period]
        right = complete[-period:]
        if max(abs(a - b) for a, b in zip(left, right)) <= 1e-9:
            flags.append("seasonal")
    if len(complete) >= 4:
        diffs = [b - a for a, b in zip(complete, complete[1:])]
        mean_diff = fmean(diffs)
        tolerance = max(1e-9, abs(mean_diff) * 0.05)
        if abs(mean_diff) > 1e-9 and max(abs(item - mean_diff) for item in diffs) <= tolerance:
            flags.append("linear_trend")
    return tuple(flags)


class DataInterpreter:
    """Classify supported structures and extract decision-relevant flags."""

    def interpret(self, request: ProblemRequest) -> DataProfile:
        data_type = _detect_type(request)
        flags = []
        notes = []
        payload = request.payload
        missing_fraction = _missing_fraction(payload)
        if missing_fraction > 0:
            flags.append("has_missing")

        if data_type == "time_series":
            flags.extend(_time_flags(payload["values"], request.constraints))
        elif data_type == "table":
            semantics = str(request.constraints.get("missing_semantics", "unspecified"))
            flags.append(f"missing_semantics:{semantics}")
            if payload and len({key for row in payload for key in row}) > len(payload[0]):
                flags.append("schema_variation")
        elif data_type == "text":
            tokens = re.findall(r"[A-Za-z']+|[\u0E00-\u0E7F]+", payload.lower())
            if any(token in {"not", "no", "never", "ไม่", "ไม่ได้"} for token in tokens):
                flags.append("negation")
            if any(token in {"but", "however", "แต่"} for token in tokens):
                flags.append("contrast")
        elif data_type == "rules":
            rules = payload.get("rules", [])
            if len(rules) > 1:
                flags.append("overlapping_rules")
            precedence = str(request.constraints.get("precedence", "first"))
            flags.append(f"precedence:{precedence}")
        elif data_type == "graph":
            flags.append("directed" if payload.get("directed", True) else "undirected")
            if any(len(edge) >= 3 for edge in payload.get("edges", [])):
                flags.append("weighted")
        elif data_type == "mixed":
            components = payload.get("components", [])
            if any("trust" in item for item in components if isinstance(item, dict)):
                flags.append("trust_scores")
            votes = {
                bool(item.get("vote"))
                for item in components
                if isinstance(item, dict) and "vote" in item
            }
            if len(votes) > 1:
                flags.append("conflicting_evidence")
        elif data_type == "matrix":
            lengths = {len(row) for row in payload}
            flags.append("rectangular" if len(lengths) == 1 else "ragged")
        elif data_type == "opaque":
            notes.append("No registered structural adapter matched the payload.")

        critical_missing = payload is None or payload == {} or payload == "" or (payload == [] and request.objective != "count_items")
        signature_payload = {
            "data_type": data_type,
            "objective": request.objective,
            "flags": sorted(set(flags)),
        }
        signature = json.dumps(
            signature_payload,
            sort_keys=True,
            separators=(",", ":"),
        )
        return DataProfile(
            data_type=data_type,
            objective=request.objective,
            item_count=_size(payload),
            missing_fraction=missing_fraction,
            flags=tuple(sorted(set(flags))),
            signature=signature,
            critical_missing=critical_missing,
            notes=tuple(notes),
        )
