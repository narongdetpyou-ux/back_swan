"""8. Decision Policy: useful automatic routes with narrow REVIEW use."""

from __future__ import annotations

from typing import List, Optional

from .contracts import AttemptRecord, DataProfile, Decision, ProblemRequest


class DecisionPolicy:
    def __init__(self, *, solved_score: float = 0.85, best_effort_score: float = 0.55):
        self.solved_score = solved_score
        self.best_effort_score = best_effort_score

    def decide(
        self,
        request: ProblemRequest,
        profile: DataProfile,
        attempts: List[AttemptRecord],
        best: Optional[AttemptRecord],
        *,
        remaining_strategies: int,
        terminal_reason: str,
        memory_used: bool,
    ) -> Decision:
        route = "CANNOT_SOLVE"
        answer = None
        selected_strategy = ""
        confidence = 0.0
        reason = terminal_reason

        missing_reasons = {"MISSING_SEMANTICS_UNSPECIFIED", "NO_OBSERVED_VALUES", "MISSING_SOURCE_WEIGHTS"}
        required = tuple(sorted({a.verification.reason_code for a in attempts} & missing_reasons))
        if profile.critical_missing or (best is None and required):
            route = "NEED_MORE_DATA"
            reason = "CRITICAL_INPUT_MISSING"
        elif best is not None and best.candidate is not None:
            answer = best.candidate.answer
            selected_strategy = best.candidate.strategy
            confidence = best.verification.score
            if confidence >= self.solved_score:
                route = "SOLVED"
                reason = (
                    "ALTERNATIVE_VERIFIED"
                    if best.attempt_index > 1
                    else "PRIMARY_STRATEGY_VERIFIED"
                )
            elif request.risk_level == "high":
                route = "REVIEW"
                reason = "HIGH_RISK_WEAK_VERIFICATION"
            elif confidence >= self.best_effort_score:
                route = "BEST_EFFORT"
                reason = "PLAUSIBLE_NOT_FULLY_VERIFIED"
        elif request.risk_level == "high":
            route = "REVIEW"
            reason = "HIGH_RISK_UNRESOLVED"
        elif remaining_strategies > 0:
            route = "RETRY_WITH_ALTERNATIVE"
            reason = "MORE_STRATEGIES_AVAILABLE"
        elif profile.data_type == "opaque":
            route = "CANNOT_SOLVE"
            reason = "UNSUPPORTED_STRUCTURE_OR_OBJECTIVE"

        return Decision(
            problem_id=request.problem_id,
            route=route,
            answer=answer,
            selected_strategy=selected_strategy,
            confidence=confidence,
            reason_code=reason,
            data_profile=profile,
            attempts=attempts,
            memory_used=memory_used,
            review_required=route == "REVIEW",
            information_needed=required or (("payload",) if profile.critical_missing else ()),
        )

