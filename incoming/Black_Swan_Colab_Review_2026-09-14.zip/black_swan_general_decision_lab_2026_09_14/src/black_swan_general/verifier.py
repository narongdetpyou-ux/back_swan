"""Independent contract calculations; no imports from solvers or evaluator labels.

Exact tasks are recomputed using separate implementations. Forecasts and limited
English sentiment remain plausibility checks and cannot become SOLVED.
"""
from __future__ import annotations
from fractions import Fraction
import math
from .contracts import CandidateAnswer, DataProfile, ProblemRequest, VerificationResult


def _number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("expected finite number")
    return Fraction(str(value))


def _equal(expected, actual):
    if type(expected) is bool:
        return type(actual) is bool and expected == actual
    if isinstance(expected, (int, float, Fraction)):
        return type(actual) in (int, float) and math.isclose(float(expected), actual, rel_tol=1e-9, abs_tol=1e-9)
    return type(expected) is type(actual) and expected == actual


def _finite_tree(value):
    if value is None or type(value) in (bool, str):
        return True
    if type(value) in (int, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(_finite_tree(x) for x in value.values())
    if isinstance(value, (list, tuple)):
        return all(_finite_tree(x) for x in value)
    return False


def _fail(reason):
    return VerificationResult(False, 0.0, True, reason)


class Verifier:
    def verify(self, request: ProblemRequest, profile: DataProfile, candidate: CandidateAnswer):
        try:
            return self._verify(request, profile, candidate)
        except (TypeError, ValueError, KeyError, IndexError, OverflowError, ZeroDivisionError, RecursionError):
            return _fail("INVALID_DATA_OR_CONTRACT")

    def _verify(self, request, profile, candidate):
        if not _finite_tree(candidate.answer) or not _finite_tree(candidate.evidence):
            return _fail("NON_FINITE_OR_UNSUPPORTED_OUTPUT")
        payload, c = request.payload, request.constraints
        kind = profile.data_type
        if kind == "time_series":
            _number(candidate.answer)
            if c.get("min_answer") is not None and candidate.answer < _number(c["min_answer"]):
                return _fail("FORECAST_BELOW_BOUND")
            if c.get("max_answer") is not None and candidate.answer > _number(c["max_answer"]):
                return _fail("FORECAST_ABOVE_BOUND")
            if any(x is None for x in payload["values"]):
                return VerificationResult(True, .60, False, "FORECAST_WITH_MISSING_TIMESTEPS")
            aligned = ((candidate.strategy == "ts_linear" and "linear_trend" in profile.flags)
                       or (candidate.strategy == "ts_seasonal" and "seasonal" in profile.flags))
            return VerificationResult(True, .78 if aligned else .62, False, "FORECAST_PLAUSIBLE_ONLY")
        if kind == "text":
            if type(candidate.answer) is not str or candidate.answer not in {"positive", "negative", "neutral"}:
                return _fail("INVALID_SENTIMENT_LABEL")
            # Recognized grammar, not a claim of general language understanding.
            import re
            if not re.search(r"\b(good|bad|excellent|improved|safe|approved|success|stable|failed|unsafe|denied|risk|declined|unstable)\b", payload.lower()):
                return _fail("UNSUPPORTED_TEXT_VOCABULARY")
            aligned = candidate.strategy == "text_negation_aware" and "negation" in profile.flags
            return VerificationResult(True, .78 if aligned else .62, False, "LIMITED_ENGLISH_HEURISTIC")
        if kind == "table":
            mode = c.get("missing_semantics")
            if mode not in {"zero", "unknown", "robust"}:
                return _fail("MISSING_SEMANTICS_UNSPECIFIED")
            raw = [row.get(c.get("column", "value")) for row in payload]
            values = [_number(x) for x in raw if x is not None]
            if mode == "zero":
                expected = sum(values, Fraction(0)) / len(raw)
            elif not values:
                return _fail("NO_OBSERVED_VALUES")
            elif mode == "unknown":
                expected = sum(values, Fraction(0)) / len(values)
            else:
                ordered = sorted(values)
                mid = len(ordered) // 2
                expected = ordered[mid] if len(ordered) % 2 else (ordered[mid-1] + ordered[mid]) / 2
            if candidate.evidence.get("missing_policy") != mode:
                return _fail("MISSING_POLICY_MISMATCH")
        elif kind == "rules":
            facts = payload["facts"]
            rules = payload["rules"]
            mode = c.get("precedence", "first")
            if mode not in {"first", "priority", "specificity"}:
                return _fail("INVALID_RULE_PRECEDENCE")
            matches = []
            for index, rule in enumerate(rules):
                if all(k in facts and type(facts[k]) is type(v) and facts[k] == v for k,v in rule.get("when", {}).items()):
                    matches.append(index)
            if not matches:
                return _fail("NO_RULE_MATCHED")
            if mode == "priority":
                matches.sort(key=lambda i: (-_number(rules[i].get("priority", 0)), i))
            elif mode == "specificity":
                matches.sort(key=lambda i: (-len(rules[i].get("when", {})), i))
            expected = rules[matches[0]]["result"]
            if candidate.evidence.get("precedence") != mode:
                return _fail("RULE_PRECEDENCE_MISMATCH")
        elif kind == "graph":
            nodes = payload["nodes"]
            if not all(type(n) is str for n in nodes) or len(set(nodes)) != len(nodes):
                return _fail("INVALID_GRAPH_NODES")
            if payload["source"] not in nodes or payload["target"] not in nodes:
                return _fail("UNKNOWN_GRAPH_ENDPOINT")
            directed = payload.get("directed", True)
            if type(directed) is not bool:
                return _fail("INVALID_GRAPH_DIRECTION")
            edges = payload["edges"]
            for e in edges:
                if not isinstance(e, (list, tuple)) or len(e) not in (2,3) or e[0] not in nodes or e[1] not in nodes:
                    return _fail("INVALID_GRAPH_EDGE")
                if len(e) == 3:
                    _number(e[2])
            # Set closure, independently of the solver's BFS and claimed path.
            seen = {payload["source"]}
            for _ in range(len(nodes)):
                before = len(seen)
                for edge in edges:
                    a,b = edge[:2]
                    if a in seen:
                        seen.add(b)
                    if not directed and b in seen:
                        seen.add(a)
                if len(seen) == before:
                    break
            expected = payload["target"] in seen
            if candidate.evidence.get("directed") is not directed:
                return _fail("GRAPH_DIRECTION_MISMATCH")
        elif kind == "mixed":
            items = payload["components"]
            if not items or any(type(i.get("vote")) is not bool for i in items):
                return _fail("INVALID_VOTES")
            mode = c.get("aggregation", "majority")
            if mode == "trust_weighted":
                weights = c.get("source_weights")
                if not isinstance(weights, dict) or any(i.get("source") not in weights for i in items):
                    return _fail("MISSING_SOURCE_WEIGHTS")
                names = [i["source"] for i in items]
                if len(set(names)) != len(names):
                    return _fail("DUPLICATE_EVIDENCE_SOURCE")
                total = Fraction(0)
                for item in items:
                    w = _number(weights[item["source"]])
                    if not 0 <= w <= 1:
                        return _fail("INVALID_SOURCE_WEIGHT")
                    total += w if item["vote"] else -w
                accepted = total > 0
            elif mode == "majority":
                accepted = sum(i["vote"] for i in items) * 2 > len(items)
            elif mode == "unanimous":
                accepted = all(i["vote"] for i in items)
            else:
                return _fail("INVALID_AGGREGATION")
            expected = "accept" if accepted else "reject"
            if candidate.evidence.get("method") != mode:
                return _fail("AGGREGATION_POLICY_MISMATCH")
        elif kind == "matrix":
            widths = {len(row) for row in payload}
            if len(widths) != 1 or not payload or 0 in widths:
                return _fail("NON_RECTANGULAR_MATRIX")
            if profile.objective == "matrix_trace":
                if widths != {len(payload)}:
                    return _fail("TRACE_REQUIRES_SQUARE_MATRIX")
                expected = sum((_number(payload[i][i]) for i in range(len(payload))), Fraction(0))
            elif profile.objective == "matrix_total":
                expected = sum((_number(x) for row in payload for x in row), Fraction(0))
            else:
                return _fail("UNSUPPORTED_MATRIX_OBJECTIVE")
        elif kind == "sequence" and profile.objective == "count_items":
            expected = len(payload)
        elif kind == 'recurrence' and profile.objective == 'recurrence_value':
            # Independent of numerics.py: closed form instead of recurrence.
            if set(payload) != {'recurrence', 'steps', 'weights'} or c:
                return _fail('INVALID_RECURRENCE_CONTRACT')
            n, weights = payload['steps'], payload['weights']
            if type(n) is not int or not 0 <= n <= 200:
                return _fail('INVALID_RECURRENCE_STEPS')
            if not isinstance(weights, list) or len(weights) != 2 or any(
                    type(w) is not int or not 1 <= w <= 10000 for w in weights):
                return _fail('INVALID_RECURRENCE_WEIGHTS')
            a, b = weights
            expected = Fraction(a*5**(n+1) + b*6**(n+1), a*5**n + b*6**n)
        else:
            return _fail("NO_VERIFIER_FOR_STRUCTURE")
        if not _equal(expected, candidate.answer):
            return _fail("ANSWER_RECOMPUTATION_MISMATCH")
        return VerificationResult(True, .97, False, "ANSWER_RECOMPUTED_FROM_INPUT")
