"""6. Outcome Memory: immutable storage of externally verified outcomes."""

from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

from .contracts import OutcomeRecord


TRUSTED_LABEL_SOURCES = {"synthetic_oracle", "analyst_verified"}


def _canonical_outcome_payload(
    *,
    profile_signature: str,
    data_type: str,
    objective: str,
    strategy: str,
    success: bool,
    reward: float,
    verifier_score: float,
    issue_codes: Tuple[str, ...],
    label_source: str,
    source_problem_hash: str,
) -> bytes:
    return json.dumps(
        {
            "profile_signature": profile_signature,
            "data_type": data_type,
            "objective": objective,
            "strategy": strategy,
            "success": success,
            "reward": reward,
            "verifier_score": verifier_score,
            "issue_codes": list(issue_codes),
            "label_source": label_source,
            "source_problem_hash": source_problem_hash,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


class OutcomeMemory:
    def __init__(self, records: Iterable[OutcomeRecord] = ()):
        self._records: Dict[str, OutcomeRecord] = {}
        for record in records:
            self._insert(record)

    def _insert(self, record: OutcomeRecord) -> None:
        if type(record.success) is not bool or not isinstance(record.reward, (int, float)) or not math.isfinite(record.reward) or not -1 <= record.reward <= 1:
            raise ValueError("invalid verified outcome")
        if not math.isfinite(record.verifier_score) or not 0 <= record.verifier_score <= 1:
            raise ValueError("invalid verifier score")
        if any(r.source_problem_hash == record.source_problem_hash and r.strategy == record.strategy and r != record for r in self._records.values()):
            raise ValueError("conflicting outcome for the same problem and strategy")
        if record.label_source not in TRUSTED_LABEL_SOURCES:
            raise ValueError("untrusted outcome label source")
        canonical = _canonical_outcome_payload(
            profile_signature=record.profile_signature,
            data_type=record.data_type,
            objective=record.objective,
            strategy=record.strategy,
            success=record.success,
            reward=record.reward,
            verifier_score=record.verifier_score,
            issue_codes=record.issue_codes,
            label_source=record.label_source,
            source_problem_hash=record.source_problem_hash,
        )
        evidence_hash = hashlib.sha256(canonical).hexdigest()
        if evidence_hash != record.evidence_hash:
            raise ValueError("outcome evidence hash mismatch")
        if record.outcome_id != f"outcome-{evidence_hash[:24]}":
            raise ValueError("outcome id/hash mismatch")
        existing = self._records.get(record.outcome_id)
        if existing is not None and existing != record:
            raise ValueError("immutable outcome collision")
        self._records[record.outcome_id] = record

    def add_verified(
        self,
        *,
        profile_signature: str,
        data_type: str,
        objective: str,
        strategy: str,
        success: bool,
        reward: float,
        verifier_score: float,
        issue_codes: Tuple[str, ...],
        label_source: str,
        source_problem_hash: str,
    ) -> OutcomeRecord:
        if type(success) is not bool:
            raise ValueError("success must be boolean")
        if label_source not in TRUSTED_LABEL_SOURCES:
            raise ValueError("untrusted outcome label source")
        reward = float(reward)
        verifier_score = float(verifier_score)
        canonical = _canonical_outcome_payload(
            profile_signature=profile_signature,
            data_type=data_type,
            objective=objective,
            strategy=strategy,
            success=success,
            reward=reward,
            verifier_score=verifier_score,
            issue_codes=issue_codes,
            label_source=label_source,
            source_problem_hash=source_problem_hash,
        )
        evidence_hash = hashlib.sha256(canonical).hexdigest()
        record = OutcomeRecord(
            outcome_id=f"outcome-{evidence_hash[:24]}",
            profile_signature=profile_signature,
            data_type=data_type,
            objective=objective,
            strategy=strategy,
            success=bool(success),
            reward=float(reward),
            verifier_score=float(verifier_score),
            issue_codes=tuple(issue_codes),
            label_source=label_source,
            source_problem_hash=source_problem_hash,
            evidence_hash=evidence_hash,
        )
        self._insert(record)
        return record

    def strategy_stats(self, profile_signature: str, strategy: str) -> dict:
        selected = [
            record
            for record in self._records.values()
            if record.profile_signature == profile_signature
            and record.strategy == strategy
        ]
        if not selected:
            return {"examples": 0, "success_rate": None, "mean_reward": None}
        return {
            "examples": len(selected),
            "success_rate": sum(record.success for record in selected) / len(selected),
            "mean_reward": sum(record.reward for record in selected) / len(selected),
        }

    def all(self) -> Tuple[OutcomeRecord, ...]:
        return tuple(self._records[key] for key in sorted(self._records))

    def __len__(self) -> int:
        return len(self._records)

    def write_jsonl(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            for record in self.all():
                handle.write(json.dumps(asdict(record), sort_keys=True) + "\n")

    @classmethod
    def from_jsonl(cls, path: Path) -> "OutcomeMemory":
        records = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            row["issue_codes"] = tuple(row["issue_codes"])
            records.append(OutcomeRecord(**row))
        return cls(records)


def stable_problem_hash(problem_payload: Any) -> str:
    if isinstance(problem_payload, dict):
        problem_payload = {k: v for k, v in problem_payload.items() if k != "problem_id"}
    canonical = json.dumps(
        problem_payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()

