"""Evaluation harness kept outside the label-free decision engine."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict
import math
import time
from typing import Any, Dict, Iterable, List

from .contracts import Decision, EvaluationCase
from .engine import BlackSwanGeneralEngine
from .memory import OutcomeMemory, stable_problem_hash


AUTOMATIC_ROUTES = {"SOLVED", "BEST_EFFORT"}


def answers_match(expected: Any, actual: Any, tolerance: float) -> bool:
    if isinstance(expected, bool) or isinstance(actual, bool):
        return type(expected) is type(actual) and expected == actual
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        return math.isclose(float(expected), float(actual), rel_tol=tolerance, abs_tol=tolerance)
    return expected == actual


def decision_is_correct(case: EvaluationCase, decision: Decision) -> bool:
    if case.evaluator_expected_route is not None:
        return decision.route == case.evaluator_expected_route
    return (
        decision.route in AUTOMATIC_ROUTES
        and answers_match(
            case.evaluator_expected_answer,
            decision.answer,
            case.numeric_tolerance,
        )
    )


def _percentile(samples: List[float], fraction: float) -> float:
    if not samples:
        return 0.0
    ordered = sorted(samples)
    index = max(0, math.ceil(fraction * len(ordered)) - 1)
    return ordered[index]


def evaluate_engine(
    engine: BlackSwanGeneralEngine,
    cases: Iterable[EvaluationCase],
) -> Dict[str, Any]:
    cases = tuple(cases)
    rows = []
    latency_ms = []
    routes = Counter()
    family_counts = defaultdict(lambda: {"cases": 0, "correct": 0, "review": 0})
    errors = 0

    for case in cases:
        started = time.perf_counter_ns()
        try:
            decision = engine.decide(case.request)
            error = ""
        except Exception as exc:  # defensive harness boundary
            decision = None
            error = f"{type(exc).__name__}: {exc}"
            errors += 1
        elapsed = (time.perf_counter_ns() - started) / 1_000_000.0
        latency_ms.append(elapsed)
        if decision is None:
            correct = False
            route = "ERROR"
            row = {
                "problem_id": case.request.problem_id,
                "family": case.family,
                "correct": False,
                "route": route,
                "latency_ms": elapsed,
                "error": error,
            }
        else:
            correct = decision_is_correct(case, decision)
            route = decision.route
            row = {
                "problem_id": case.request.problem_id,
                "family": case.family,
                "correct": correct,
                "route": route,
                "answer": decision.answer,
                "selected_strategy": decision.selected_strategy,
                "confidence": decision.confidence,
                "reason_code": decision.reason_code,
                "attempts": len(decision.attempts),
                "memory_used": decision.memory_used,
                "latency_ms": elapsed,
                "error": error,
                "decision": asdict(decision),
            }
        row["answerable"] = case.evaluator_expected_route is None
        row["first_attempt_correct"] = bool(decision and decision.attempts and decision.attempts[0].candidate
            and decision.attempts[0].verification.accepted and case.evaluator_expected_route is None
            and answers_match(case.evaluator_expected_answer, decision.attempts[0].candidate.answer, case.numeric_tolerance))
        row["corrected_after_failure"] = bool(correct and decision and len(decision.attempts) > 1
            and not row["first_attempt_correct"] and case.evaluator_expected_route is None)
        rows.append(row)
        routes[route] += 1
        family_counts[case.family]["cases"] += 1
        family_counts[case.family]["correct"] += int(correct)
        family_counts[case.family]["review"] += int(route == "REVIEW")

    count = len(rows)
    correct_count = sum(row["correct"] for row in rows)
    auto_count = sum(routes[item] for item in AUTOMATIC_ROUTES)
    solved_wrong = sum(
        row["route"] == "SOLVED" and not row["correct"] for row in rows
    )
    solved_count = routes["SOLVED"]
    answerable = sum(row["answerable"] for row in rows)
    correct_answers = sum(row["correct"] and row["answerable"] for row in rows)
    auto_wrong = sum(row["route"] in AUTOMATIC_ROUTES and not row["correct"] for row in rows)
    metrics = {
        "cases": count,
        "correct": correct_count,
        "contract_accuracy": correct_count / count if count else 0.0,
        "task_success_rate": correct_answers / answerable if answerable else 0.0,
        "answerable_cases": answerable,
        "correct_answers": correct_answers,
        "correct_automatic_rate_all_cases": correct_answers / count if count else 0.0,
        "automatic_answer_accuracy": (auto_count-auto_wrong) / auto_count if auto_count else None,
        "automatic_wrong_count": auto_wrong,
        "automatic_error_rate": auto_wrong / count if count else 0.0,
        "first_attempt_success_rate": sum(row["first_attempt_correct"] for row in rows) / answerable if answerable else 0.0,
        "successful_corrections": sum(row["corrected_after_failure"] for row in rows),
        "false_confidence_given_solved": solved_wrong / solved_count if solved_count else None,
        "unresolved_rate": (count-auto_count) / count if count else 0.0,
        "automatic_answers": auto_count,
        "automated_coverage": auto_count / count if count else 0.0,
        "review_count": routes["REVIEW"],
        "review_rate": routes["REVIEW"] / count if count else 0.0,
        "retry_count": routes["RETRY_WITH_ALTERNATIVE"],
        "cannot_solve_count": routes["CANNOT_SOLVE"],
        "need_more_data_count": routes["NEED_MORE_DATA"],
        "false_confident_count": solved_wrong,
        "false_confidence_rate": solved_wrong / count if count else 0.0,
        "error_count": errors,
        "error_rate": errors / count if count else 0.0,
        "mean_attempts": (
            sum(row.get("attempts", 0) for row in rows) / count if count else 0.0
        ),
        "latency_p50_ms": _percentile(latency_ms, 0.50),
        "latency_p95_ms": _percentile(latency_ms, 0.95),
        "latency_p99_ms": _percentile(latency_ms, 0.99),
        "latency_max_ms": max(latency_ms, default=0.0),
    }
    by_family = {
        family: {
            **values,
            "success_rate": values["correct"] / values["cases"],
            "review_rate": values["review"] / values["cases"],
        }
        for family, values in sorted(family_counts.items())
    }
    return {
        "metrics": metrics,
        "routes": dict(sorted(routes.items())),
        "by_family": by_family,
        "rows": rows,
        "latency_method": "nearest-rank over per-call perf_counter_ns end-to-end samples",
    }


def collect_verified_outcomes(
    engine: BlackSwanGeneralEngine,
    cases: Iterable[EvaluationCase],
    memory: OutcomeMemory,
    *,
    label_source: str = "synthetic_oracle",
) -> List[dict]:
    """Explore strategies, then let the external oracle label each outcome."""

    rows = []
    for case in cases:
        if case.split != "learning":
            raise ValueError("only learning split may teach memory")
        if case.evaluator_expected_route is not None:
            continue
        decision = engine.decide(case.request, exploration=True)
        source_hash = stable_problem_hash(asdict(case.request))
        for attempt in decision.attempts:
            success = bool(attempt.candidate is not None and attempt.verification.accepted and answers_match(
                case.evaluator_expected_answer,
                attempt.candidate.answer,
                case.numeric_tolerance,
            ))
            issue_codes = (
                "ORACLE_CORRECT" if success else "ORACLE_WRONG",
                attempt.verification.reason_code,
                *attempt.verification.issues,
            )
            record = memory.add_verified(
                profile_signature=decision.data_profile.signature,
                data_type=decision.data_profile.data_type,
                objective=decision.data_profile.objective,
                strategy=attempt.ranked_strategy.strategy,
                success=success,
                reward=1.0 if success else -1.0,
                verifier_score=attempt.verification.score,
                issue_codes=issue_codes,
                label_source=label_source,
                source_problem_hash=source_hash,
            )
            rows.append(
                {
                    "problem_id": case.request.problem_id,
                    "family": case.family,
                    "strategy": attempt.ranked_strategy.strategy,
                    "candidate_answer": attempt.candidate.answer if attempt.candidate else None,
                    "success": success,
                    "outcome_id": record.outcome_id,
                }
            )
    return rows

