"""5. Correction Loop: bounded alternate-strategy attempts."""

from __future__ import annotations

import json
import time
from typing import Iterable, List, Optional, Tuple

from .contracts import AttemptRecord, DataProfile, ProblemRequest, RankedStrategy
from .strategies import SolverError, StrategyRegistry
from .verifier import Verifier
from .runtime import isolated_attempt


def _state_key(strategy: str, answer) -> str:
    try:
        encoded = json.dumps(answer, ensure_ascii=False, sort_keys=True, default=repr)
    except (TypeError, ValueError):
        encoded = repr(answer)
    return f"{strategy}:{encoded}"


class CorrectionLoop:
    def __init__(self, registry: StrategyRegistry, verifier: Verifier):
        self.registry = registry
        self.verifier = verifier

    def run(
        self,
        request: ProblemRequest,
        profile: DataProfile,
        ranked: Iterable[RankedStrategy],
        *,
        max_attempts: int,
        time_budget_ms: float,
        stop_score: float,
        exploration: bool = False,
    ) -> Tuple[List[AttemptRecord], Optional[AttemptRecord], int, str]:
        ranked = tuple(ranked)
        limit = min(len(ranked), max_attempts)
        deadline = time.monotonic() + time_budget_ms / 1000.0
        attempts: List[AttemptRecord] = []
        seen_states = set()
        terminal_reason = "NO_APPLICABLE_STRATEGY" if not ranked else "ATTEMPT_BUDGET_EXHAUSTED"

        for ranked_strategy in ranked[:limit]:
            if time.monotonic() >= deadline:
                terminal_reason = "TIME_BUDGET_EXHAUSTED"
                break
            candidate = None
            error = ""
            try:
                strategy = self.registry.get(ranked_strategy.strategy)
                candidate, verification, error = isolated_attempt(
                    strategy, self.verifier, request, profile, deadline)
                state = _state_key(ranked_strategy.strategy, candidate.answer if candidate else None)
                if state in seen_states:
                    verification = type(verification)(
                        False,
                        min(verification.score, 0.1),
                        True,
                        "REPEATED_STATE",
                        verification.issues + ("duplicate strategy/output state",),
                    )
                else:
                    seen_states.add(state)
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                from .contracts import VerificationResult

                verification = VerificationResult(
                    False,
                    0.0,
                    True,
                    "SOLVER_ERROR",
                    (type(exc).__name__,),
                )
            attempt = AttemptRecord(
                attempt_index=len(attempts) + 1,
                ranked_strategy=ranked_strategy,
                candidate=candidate,
                verification=verification,
                error=error,
            )
            attempts.append(attempt)
            if verification.reason_code == "TIME_BUDGET_EXHAUSTED":
                terminal_reason = "TIME_BUDGET_EXHAUSTED"
                break
            if not exploration and verification.accepted and verification.score >= stop_score:
                terminal_reason = "VERIFIED_STOP"
                break

        accepted = [item for item in attempts if item.verification.accepted and item.candidate is not None]
        best = max(
            accepted,
            key=lambda item: (item.verification.score, item.ranked_strategy.score, -item.attempt_index),
            default=None,
        )
        remaining = max(0, len(ranked) - len(attempts))
        if attempts and len(attempts) == len(ranked) and terminal_reason != "TIME_BUDGET_EXHAUSTED":
            terminal_reason = "ALL_STRATEGIES_TRIED"
        return attempts, best, remaining, terminal_reason
