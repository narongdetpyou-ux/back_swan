"""Black Swan General Decision Engine: orchestration of components 1-8."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from .adapters import normalize
from typing import Any

from .contracts import DataProfile, Decision, ProblemRequest
from .correction import CorrectionLoop
from .interpreter import DataInterpreter
from .memory import OutcomeMemory
from .policy import DecisionPolicy
from .selector import StrategySelector
from .strategies import StrategyRegistry
from .verifier import Verifier


@dataclass(frozen=True)
class EngineConfig:
    max_attempts: int = 4
    exploration_max_attempts: int = 16
    time_budget_ms: float = 500.0
    stop_score: float = 0.90
    solved_score: float = 0.85
    best_effort_score: float = 0.55
    minimum_memory_examples: int = 3
    memory_weight: float = 2.4
    max_payload_bytes: int = 100_000
    max_items: int = 10_000
    max_depth: int = 32


class BlackSwanGeneralEngine:
    """A deterministic, standalone experiment—not a replacement for v8."""

    def __init__(
        self,
        *,
        memory: OutcomeMemory | None = None,
        config: EngineConfig = EngineConfig(),
        registry: StrategyRegistry | None = None,
    ):
        self.config = config
        self.memory = memory if memory is not None else OutcomeMemory()
        self.registry = registry if registry is not None else StrategyRegistry()
        self.interpreter = DataInterpreter()
        self.selector = StrategySelector(
            self.memory,
            minimum_examples=config.minimum_memory_examples,
            memory_weight=config.memory_weight,
        )
        self.verifier = Verifier()
        self.correction = CorrectionLoop(self.registry, self.verifier)
        self.policy = DecisionPolicy(
            solved_score=config.solved_score,
            best_effort_score=config.best_effort_score,
        )
        self._validate_config()

    def _validate_config(self) -> None:
        if any(not isinstance(v, (int, float)) or not math.isfinite(v)
               for v in vars(self.config).values()):
            raise ValueError("configuration must be finite numeric values")
        for name in ("max_attempts", "exploration_max_attempts", "max_payload_bytes", "max_items", "max_depth", "minimum_memory_examples"):
            if type(getattr(self.config, name)) is not int or getattr(self.config, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.config.max_attempts < 1 or self.config.exploration_max_attempts < 1:
            raise ValueError("attempt limits must be positive")
        if self.config.time_budget_ms <= 0:
            raise ValueError("time_budget_ms must be positive")
        if not 0 <= self.config.best_effort_score <= self.config.solved_score <= 1:
            raise ValueError("decision score thresholds are invalid")
        if self.config.stop_score < self.config.solved_score or self.config.stop_score > 1:
            raise ValueError("stop_score must be between solved_score and 1")

    def _input_issue(self, request: ProblemRequest) -> str:
        if not isinstance(request, ProblemRequest):
            return "INVALID_REQUEST_TYPE"
        if not isinstance(request.problem_id, str) or not request.problem_id.strip():
            return "INVALID_PROBLEM_ID"
        if not isinstance(request.objective, str) or not request.objective.strip():
            return "INVALID_OBJECTIVE"
        if not isinstance(request.risk_level, str) or request.risk_level not in {"low", "medium", "high"}:
            return "INVALID_RISK_LEVEL"
        if not isinstance(request.constraints, dict):
            return "INVALID_CONSTRAINTS"
        # Bound nested work before recursion/serialization/interpreter execution.
        stack = [(request.payload, 0), (request.constraints, 0)]
        visited = set()
        count = 0
        while stack:
            value, depth = stack.pop()
            count += 1
            if count > self.config.max_items:
                return "TOO_MANY_ITEMS"
            if depth > self.config.max_depth:
                return "MAX_DEPTH_EXCEEDED"
            if isinstance(value, (list, tuple, dict)):
                if id(value) in visited:
                    # Repeated containers, including cycles, are rejected explicitly.
                    return "REPEATED_CONTAINER"
                visited.add(id(value))
                children = value.values() if isinstance(value, dict) else value
                if isinstance(value, dict) and any(not isinstance(k, str) for k in value):
                    return "NON_STRING_OBJECT_KEY"
                stack.extend((child, depth + 1) for child in children)
        try:
            encoded = json.dumps(
                [request.payload, request.constraints],
                ensure_ascii=False,
                sort_keys=True,
                allow_nan=False,
            ).encode("utf-8")
        except (TypeError, ValueError, RecursionError, OverflowError):
            return "PAYLOAD_NOT_SAFE_JSON"
        if len(encoded) > self.config.max_payload_bytes:
            return "PAYLOAD_TOO_LARGE"
        return ""

    def decide(self, request: ProblemRequest, *, exploration: bool = False) -> Decision:
        issue = self._input_issue(request)
        adapter = "identity"
        profile = DataProfile("opaque", str(getattr(request, "objective", "")), 0, 1.0, (), "invalid")
        if not issue:
            try:
                request, adapter = normalize(request)
                profile = self.interpreter.interpret(request)
            except Exception as exc:
                issue = "INVALID_STRUCTURE_OR_CONSTRAINT:" + type(exc).__name__
        if issue:
            risk_route = "REVIEW" if getattr(request, "risk_level", "") == "high" else "CANNOT_SOLVE"
            return Decision(
                problem_id=str(getattr(request, "problem_id", "invalid")),
                route=risk_route,
                answer=None,
                selected_strategy="",
                confidence=0.0,
                reason_code=issue,
                data_profile=profile,
                attempts=[],
                memory_used=False,
                review_required=risk_route == "REVIEW",
            )

        strategies = self.registry.applicable(profile)
        ranked = self.selector.rank(profile, strategies)
        memory_used = any(
            item.memory_examples >= self.config.minimum_memory_examples for item in ranked
        )
        max_attempts = (
            self.config.exploration_max_attempts if exploration else self.config.max_attempts
        )
        attempts, best, remaining, terminal = self.correction.run(
            request,
            profile,
            ranked,
            max_attempts=max_attempts,
            time_budget_ms=self.config.time_budget_ms,
            stop_score=self.config.stop_score,
            exploration=exploration,
        )
        decision = self.policy.decide(
            request,
            profile,
            attempts,
            best,
            remaining_strategies=remaining,
            terminal_reason=terminal,
            memory_used=memory_used,
        )
        decision.adapter = adapter
        decision.terminal_reason = terminal
        return decision
