"""2. Strategy Selector: rank applicable solvers using verified memory."""

from __future__ import annotations

from typing import Iterable, Tuple

from .contracts import DataProfile, RankedStrategy
from .memory import OutcomeMemory
from .strategies import Strategy


class StrategySelector:
    """Rank strategies without access to evaluator answers.

    The base order is deliberately simple.  Verified outcome memory may change
    that order only after enough examples exist for the same label-free data
    profile.  Heuristics are intentionally small so they help with ties but do
    not masquerade as learned evidence.
    """

    def __init__(
        self,
        memory: OutcomeMemory,
        *,
        minimum_examples: int = 3,
        memory_weight: float = 2.4,
    ):
        if minimum_examples < 1:
            raise ValueError("minimum_examples must be positive")
        if memory_weight < 0:
            raise ValueError("memory_weight must be non-negative")
        self.memory = memory
        self.minimum_examples = minimum_examples
        self.memory_weight = memory_weight

    @staticmethod
    def _heuristic_bonus(profile: DataProfile, strategy: str) -> float:
        flags = set(profile.flags)
        bonus = 0.0
        matches = {
            "ts_linear": "linear_trend",
            "ts_seasonal": "seasonal",
            "text_negation_aware": "negation",
            "table_zero_fill_mean": "missing_semantics:zero",
            "table_drop_missing_mean": "missing_semantics:unknown",
            "table_median": "missing_semantics:robust",
            "rules_first": "precedence:first",
            "rules_specificity": "precedence:specificity",
            "rules_priority": "precedence:priority",
            "graph_directed": "directed",
            "graph_undirected": "undirected",
            "mixed_trust_weighted": "trust_scores",
        }
        flag = matches.get(strategy)
        if flag and flag in flags:
            bonus += 0.08
        if strategy == "mixed_trust_weighted" and "conflicting_evidence" in flags:
            bonus += 0.04
        return bonus

    def rank(
        self,
        profile: DataProfile,
        strategies: Iterable[Strategy],
    ) -> Tuple[RankedStrategy, ...]:
        ranked = []
        for index, strategy in enumerate(strategies):
            base_score = 1.0 - 0.20 * index
            heuristic_bonus = self._heuristic_bonus(profile, strategy.name)
            stats = self.memory.strategy_stats(profile.signature, strategy.name)
            memory_bonus = 0.0
            if stats["examples"] >= self.minimum_examples:
                # success_rate=1 -> +1.2; success_rate=0 -> -1.2
                memory_bonus = self.memory_weight * (stats["success_rate"] - 0.5)
                # Reward is retained separately so future graded outcomes can
                # refine ranking without changing the immutable record format.
                memory_bonus += 0.20 * float(stats["mean_reward"] or 0.0)
            ranked.append(
                RankedStrategy(
                    strategy=strategy.name,
                    score=base_score + heuristic_bonus + memory_bonus,
                    base_score=base_score,
                    heuristic_bonus=heuristic_bonus,
                    memory_bonus=memory_bonus,
                    memory_examples=int(stats["examples"]),
                    memory_success_rate=stats["success_rate"],
                )
            )
        return tuple(
            sorted(ranked, key=lambda item: (-item.score, item.strategy))
        )

