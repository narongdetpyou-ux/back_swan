"""Deterministic synthetic fixtures for heterogeneous decision experiments."""

from __future__ import annotations

from dataclasses import asdict
import random
from typing import Iterable, List

from .contracts import EvaluationCase, ProblemRequest


KNOWN_FAMILIES = (
    "ts_linear",
    "ts_seasonal",
    "table_missing_unknown",
    "table_missing_zero",
    "table_robust",
    "text_negated_positive",
    "text_negated_negative",
    "rules_specificity",
    "rules_priority",
    "graph_directed",
    "graph_undirected",
    "mixed_trust",
)


def _case(
    problem_id: str,
    split: str,
    family: str,
    objective: str,
    payload,
    *,
    constraints=None,
    risk_level: str = "low",
    expected_answer=None,
    expected_route=None,
    tolerance: float = 1e-9,
) -> EvaluationCase:
    return EvaluationCase(
        request=ProblemRequest(
            problem_id=problem_id,
            objective=objective,
            payload=payload,
            constraints=constraints or {},
            risk_level=risk_level,
        ),
        family=family,
        split=split,
        evaluator_expected_answer=expected_answer,
        evaluator_expected_route=expected_route,
        numeric_tolerance=tolerance,
    )


def generate_known_cases(split: str, *, per_family: int, seed: int) -> List[EvaluationCase]:
    """Create independently seeded cases for profiles that can be learned."""

    rng = random.Random(seed)
    cases: List[EvaluationCase] = []
    counter = 0

    def next_id() -> str:
        nonlocal counter
        value = f"{split}-{counter:04d}"
        counter += 1
        return value

    for sample in range(per_family):
        intercept = rng.uniform(-30, 30) + sample / 10
        slope = rng.choice([1.5, 2.0, 2.5, 3.0])
        values = [intercept + slope * index for index in range(6)]
        cases.append(
            _case(
                next_id(), split, "ts_linear", "forecast_next",
                {"values": values}, expected_answer=intercept + slope * 6,
                tolerance=1e-8,
            )
        )

        base = rng.uniform(-20, 20) + sample / 20
        pattern = [base, base + 3, base - 2, base + 5]
        cases.append(
            _case(
                next_id(), split, "ts_seasonal", "forecast_next",
                {"values": pattern * 3}, constraints={"period": 4},
                expected_answer=pattern[0], tolerance=1e-8,
            )
        )

        start = rng.uniform(1, 40) + sample / 10
        unknown_values = [start, None, start + 2, start + 4, None]
        cases.append(
            _case(
                next_id(), split, "table_missing_unknown", "column_summary",
                [{"value": value} for value in unknown_values],
                constraints={"column": "value", "missing_semantics": "unknown"},
                expected_answer=(start + start + 2 + start + 4) / 3,
            )
        )

        zero_values = [start, None, start + 2, start + 4, None]
        cases.append(
            _case(
                next_id(), split, "table_missing_zero", "column_summary",
                [{"value": value} for value in zero_values],
                constraints={"column": "value", "missing_semantics": "zero"},
                expected_answer=(start + start + 2 + start + 4) / 5,
            )
        )

        robust_values = [start, start + 1, start + 2, None, start + 100 + sample]
        cases.append(
            _case(
                next_id(), split, "table_robust", "column_summary",
                [{"value": value} for value in robust_values],
                constraints={"column": "value", "missing_semantics": "robust"},
                expected_answer=start + 1.5,
            )
        )

        cases.append(
            _case(
                next_id(), split, "text_negated_positive", "sentiment",
                f"The result is not bad and remains stable. Case {seed}-{sample}.",
                expected_answer="positive",
            )
        )
        cases.append(
            _case(
                next_id(), split, "text_negated_negative", "sentiment",
                f"The result is not good and remains unstable. Case {seed}-{sample}.",
                expected_answer="negative",
            )
        )

        token = f"T{seed}-{sample}"
        facts = {"tier": "gold", "region": "east", "token": token}
        specificity_rules = [
            {"when": {"tier": "gold"}, "result": "generic", "priority": 1},
            {"when": {"tier": "gold", "region": "east"}, "result": "specific", "priority": 2},
        ]
        cases.append(
            _case(
                next_id(), split, "rules_specificity", "rule_decision",
                {"facts": facts, "rules": specificity_rules},
                constraints={"precedence": "specificity"}, expected_answer="specific",
            )
        )

        priority_rules = [
            {"when": {"tier": "gold"}, "result": "first", "priority": 1},
            {"when": {"tier": "gold", "region": "east"}, "result": "specific", "priority": 2},
            {"when": {"region": "east"}, "result": "priority", "priority": 10},
        ]
        cases.append(
            _case(
                next_id(), split, "rules_priority", "rule_decision",
                {"facts": facts, "rules": priority_rules},
                constraints={"precedence": "priority"}, expected_answer="priority",
            )
        )

        left, right = f"n{seed}_{sample}_a", f"n{seed}_{sample}_b"
        graph_payload = {
            "nodes": [left, right], "edges": [(right, left)],
            "source": left, "target": right, "directed": True,
        }
        cases.append(
            _case(
                next_id(), split, "graph_directed", "reachable",
                graph_payload, expected_answer=False,
            )
        )
        undirected_payload = {**graph_payload, "directed": False}
        cases.append(
            _case(
                next_id(), split, "graph_undirected", "reachable",
                undirected_payload, expected_answer=True,
            )
        )

        components = [
            {"source": f"weak-a-{sample}", "vote": True, "trust": 0.10},
            {"source": f"weak-b-{sample}", "vote": True, "trust": 0.10},
            {"source": f"strong-{seed}", "vote": False, "trust": 0.90},
        ]
        cases.append(
            _case(
                next_id(), split, "mixed_trust", "evidence_decision",
                {"components": components},
                constraints={"aggregation": "trust_weighted", "source_weights": {item["source"]: item["trust"] for item in components}}, expected_answer="reject",
            )
        )

    return cases


def generate_novel_holdout(*, seed: int) -> List[EvaluationCase]:
    """Create structures and routes absent from outcome-memory training."""

    rng = random.Random(seed)
    split = "holdout"
    cases: List[EvaluationCase] = []
    counter = 10_000

    def next_id() -> str:
        nonlocal counter
        value = f"{split}-{counter:05d}"
        counter += 1
        return value

    for sample in range(20):
        a = rng.randint(-10, 20) + sample
        matrix = [[a, 2, 3], [4, a + 1, 6], [7, 8, a + 2]]
        cases.append(
            _case(
                next_id(), split, "novel_matrix_trace", "matrix_trace",
                matrix, expected_answer=3 * a + 3,
            )
        )
    for sample in range(20):
        a = rng.randint(-5, 15) + sample
        matrix = [[a, 1], [2, a + 3]]
        cases.append(
            _case(
                next_id(), split, "novel_matrix_total", "matrix_total",
                matrix, expected_answer=2 * a + 6,
            )
        )
    for sample in range(20):
        values = [f"item-{sample}-{index}" for index in range(3 + sample % 7)]
        cases.append(
            _case(
                next_id(), split, "novel_sequence_count", "count_items",
                values, expected_answer=len(values),
            )
        )
    for sample in range(10):
        cases.append(
            _case(
                next_id(), split, "unsupported_low_risk", "infer_intent",
                {"unseen_object": {"token": sample, "kind": "new"}},
                expected_route="CANNOT_SOLVE",
            )
        )
    for sample in range(5):
        cases.append(
            _case(
                next_id(), split, "missing_input", "count_items", None,
                expected_route="NEED_MORE_DATA",
            )
        )
    for sample in range(5):
        cases.append(
            _case(
                next_id(), split, "unsupported_high_risk", "infer_intent",
                {"unseen_object": {"token": sample, "kind": "high-risk-new"}},
                risk_level="high", expected_route="REVIEW",
            )
        )
    return cases


def input_record(case: EvaluationCase) -> dict:
    """Public engine input; deliberately excludes family and evaluator labels."""

    return asdict(case.request)


def label_record(case: EvaluationCase) -> dict:
    """Evaluator-only record stored separately from the engine input."""

    return {
        "problem_id": case.request.problem_id,
        "family": case.family,
        "split": case.split,
        "expected_answer": case.evaluator_expected_answer,
        "expected_route": case.evaluator_expected_route,
        "numeric_tolerance": case.numeric_tolerance,
    }

