"""Explicit representation adapters. They do not invent algorithms or facts."""
from dataclasses import replace
from .contracts import ProblemRequest


def normalize(request: ProblemRequest):
    payload = request.payload
    if isinstance(payload, dict) and "columns" in payload:
        columns = payload["columns"]
        if not isinstance(columns, dict) or not columns:
            raise ValueError("columns must be a nonempty object")
        if not all(isinstance(v, list) for v in columns.values()):
            raise ValueError("column values must be lists")
        if len({len(v) for v in columns.values()}) != 1:
            raise ValueError("column lengths differ")
        count = len(next(iter(columns.values())))
        rows = [{key: values[i] for key, values in columns.items()} for i in range(count)]
        return replace(request, payload=rows), "columnar_to_table"
    return request, "identity"
