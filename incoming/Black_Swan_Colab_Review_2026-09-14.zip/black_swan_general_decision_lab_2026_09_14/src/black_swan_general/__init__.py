"""Black Swan General Decision Lab.

A standalone research framework for interpreting heterogeneous data, selecting
and correcting solution strategies, verifying outputs, and learning only from
externally verified outcomes.
"""

from .contracts import Decision, EvaluationCase, ProblemRequest
from .engine import BlackSwanGeneralEngine, EngineConfig
from .memory import OutcomeMemory

__all__ = [
    "BlackSwanGeneralEngine",
    "Decision",
    "EngineConfig",
    "EvaluationCase",
    "OutcomeMemory",
    "ProblemRequest",
]

