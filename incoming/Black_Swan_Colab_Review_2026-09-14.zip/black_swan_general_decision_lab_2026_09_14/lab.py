#!/usr/bin/env python3
"""CLI for new local experiments; no API keys or paid calls."""
from pathlib import Path
from dataclasses import asdict
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from black_swan_general import BlackSwanGeneralEngine,EngineConfig,OutcomeMemory
from black_swan_general.io import read_requests,read_cases,load_release
from black_swan_general.evaluation import collect_verified_outcomes,evaluate_engine
from black_swan_general.learning_gate import LearningGate
from black_swan_general.memory import stable_problem_hash
from run_experiment import write_json,write_jsonl,sha


def main():
    parser=argparse.ArgumentParser(description='Black Swan offline decision experiments')
    sub=parser.add_subparsers(dest='command',required=True)
    solve=sub.add_parser('solve');solve.add_argument('inputs',type=Path)
    solve.add_argument('--memory-dir',type=Path);solve.add_argument('--max-attempts',type=int,default=4)
    solve.add_argument('--output',type=Path)
    evaluate=sub.add_parser('evaluate');evaluate.add_argument('inputs',type=Path);evaluate.add_argument('labels',type=Path)
    evaluate.add_argument('--split',default='holdout');evaluate.add_argument('--memory-dir',type=Path)
    evaluate.add_argument('--output',type=Path,required=True)
    learn=sub.add_parser('learn')
    for name in ('learning_inputs','learning_labels','validation_inputs','validation_labels'): learn.add_argument(name,type=Path)
    learn.add_argument('--base-memory-dir',type=Path)
    learn.add_argument('--label-source',choices=['synthetic_oracle','analyst_verified'],required=True)
    learn.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output and args.output.exists(): parser.error('output exists; choose a fresh path')
    if args.command=='learn':
        training=read_cases(args.learning_inputs,args.learning_labels,'learning')
        validation=read_cases(args.validation_inputs,args.validation_labels,'validation')
        if not training or not validation: parser.error('training and validation must be nonempty')
        a={stable_problem_hash(asdict(c.request)) for c in training}
        b={stable_problem_hash(asdict(c.request)) for c in validation}
        if a&b: parser.error('training and validation contain identical inputs')
        previous=load_release(args.base_memory_dir) if args.base_memory_dir else OutcomeMemory()
        memory=OutcomeMemory(previous.all())
        baseline=evaluate_engine(BlackSwanGeneralEngine(memory=previous),validation)
        rows=collect_verified_outcomes(BlackSwanGeneralEngine(),training,memory,label_source=args.label_source)
        candidate=evaluate_engine(BlackSwanGeneralEngine(memory=memory),validation)
        gate=LearningGate().evaluate(baseline['metrics'],candidate['metrics'],
             label_sources=[r.label_source for r in memory.all()],baseline_families=baseline['by_family'],candidate_families=candidate['by_family'])
        args.output.mkdir(parents=True)
        memory.write_jsonl(args.output/'candidate_memory.jsonl')
        active=OutcomeMemory(memory.all()) if gate.passed else OutcomeMemory()
        active.write_jsonl(args.output/'active_memory.jsonl')
        write_json(args.output/'learning_gate.json',asdict(gate))
        write_jsonl(args.output/'training_outcomes.jsonl',rows)
        write_json(args.output/'validation_results.json',dict(baseline=baseline,candidate=candidate))
        write_json(args.output/'memory_release.json',dict(gate_passed=gate.passed,memory_file='active_memory.jsonl',
                   sha256=sha(args.output/'active_memory.jsonl'),gate_sha256=sha(args.output/'learning_gate.json')))
        write_json(args.output/'input_provenance.json',{str(p):sha(p) for p in [args.learning_inputs,args.learning_labels,args.validation_inputs,args.validation_labels]})
        print(json.dumps(dict(gate_passed=gate.passed,reason_codes=gate.reason_codes,active_records=len(active))))
        return 0 if gate.passed else 2
    memory=load_release(args.memory_dir) if args.memory_dir else OutcomeMemory()
    engine=BlackSwanGeneralEngine(memory=memory,config=EngineConfig(max_attempts=getattr(args,'max_attempts',4)))
    if args.command=='solve':
        decisions=[asdict(engine.decide(r)) for r in read_requests(args.inputs)]
        if args.output: write_jsonl(args.output,decisions)
        else:
            for row in decisions: print(json.dumps(row,ensure_ascii=False))
    else:
        result=evaluate_engine(engine,read_cases(args.inputs,args.labels,args.split))
        write_json(args.output,result)
        print(json.dumps(result['metrics'],indent=2))
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print('Input error: '+str(exc),file=sys.stderr)
        raise SystemExit(2)
