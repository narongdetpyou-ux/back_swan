# Contracts and extension points

`ProblemRequest` has `problem_id`, `objective`, `payload`, optional `constraints` and `risk_level`. Inputs are data, not instructions to change policy. Fields containing family, expected answers, split, or label-source are rejected by the JSON/JSONL loader. Contracts are logical boundaries in this local Python application, not an operating-system security boundary against a developer with filesystem access.

| Input / objective | Payload / required contract | Verification |
|---|---|---|
| Time series / `forecast_next` | `{"values":[...]}`; optional `period`, bounds | Pattern plausibility; future outcome is not known |
| Table / `column_summary` | Array of rows; `column`, `missing_semantics` = `zero`, `unknown`, `robust` | Separate Fraction-based mean/median recomputation |
| Text / `sentiment` | String; limited English vocabulary | Heuristic; never certifies general text meaning |
| Rules / `rule_decision` | `facts` and `rules`; `precedence` = `first`, `priority`, `specificity` | Independently evaluate matching rules; ties use earlier rule |
| Graph / `reachable` | String `nodes`, valid `edges`, `source`, `target`, boolean `directed` | Set closure; solver uses BFS |
| Mixed evidence / `evidence_decision` | Components with source and boolean vote; `aggregation`; `source_weights` for weighted votes | Independent aggregation; payload cannot assign its own weight |
| Matrix / `matrix_total`, `matrix_trace` | Rectangular numeric array; square for trace | Independently recompute operation |
| Sequence / `count_items` | Array; an empty array is a known count of zero | Independently count items |
| Numerical recurrence / `recurrence_value` | `{"recurrence":"muller_5_6","steps":35,"weights":[1,1]}`; steps 0–200, two integer weights 1–10000, empty constraints | Independent closed form; numeric tolerance relative/absolute 1e-9 |
| Columnar / `column_summary` | `{"columns":{"reading":[...]}}`; all columns equal length | Normalize to table, reuse table contract and memory |

`robust` selects the median, `unknown` excludes missing observations, and `zero` explicitly treats missing as zero. Unspecified missing semantics returns `NEED_MORE_DATA`. Non-numeric non-null values are invalid, not silently treated as missing. Row order is immaterial for aggregates. Rules distinguish absent facts from present nulls and booleans from numbers. Graph edge weights are validated but reachability does not use weighted distance. This build has no shortest-path or causal-inference claim. Mixed evidence weights are supplied by the trusted experiment configuration; external authentication of those weights is not implemented.

## Eight components

| Component | File | Extension boundary |
|---|---|---|
| Data Interpreter | `interpreter.py`, `adapters.py` | Normalize a documented shape and extract a label-free profile |
| Strategy Selector | `selector.py` | Rank registered strategies using prior, small hints and verified historical outcomes |
| Solver | `strategies.py` | A `Strategy` function returns a `CandidateAnswer`; register new strategies explicitly |
| Verifier | `verifier.py` | Independently validate output; do not import a solver's answer function or use its claimed method as proof |
| Correction Loop | `correction.py`, `runtime.py` | Attempt alternatives once; disposable workers bound hangs and crashes |
| Outcome Memory | `memory.py` | Append verified successes and failures; identical evidence deduplicates; conflicting labels are rejected |
| Learning Gate | `learning_gate.py` | Compare fixed validation populations and families; refuse regression, invalid metrics and empty validation |
| Decision Policy | `policy.py` | Choose terminal route, evidence-strength score and missing-information reasons |

## Routes

| Route | Meaning |
|---|---|
| `SOLVED` | Exact supported task passed independent recomputation |
| `BEST_EFFORT` | Plausible answer; semantic/future truth not proven |
| `NEED_MORE_DATA` | Missing payload or required contract, reported in `information_needed` |
| `CANNOT_SOLVE` | Unsupported or invalid task, or exhausted supported methods |
| `RETRY_WITH_ALTERNATIVE` | Caller chose a step budget smaller than remaining methods; status is unfinished, not success |
| `REVIEW` | High-risk unresolved or weakly verified request |

Default runtime: four attempts, 500 ms for the solver/verifier loop, 100,000 encoded payload/constraint bytes, 10,000 nested items, depth 32. Worker termination/join adds at most two 50 ms cleanup waits; scheduling and preprocessing are outside the solver budget. Timeouts are explicit in `terminal_reason`. Linux fork was tested. Other operating systems, arbitrary hostile plugin code, plugin-created external processes, network services and load/queue behavior were not evaluated. Process isolation is cancellation, not a security sandbox. Extensions must be trusted local Python.

The field `confidence` retains the historical name for compatibility. It measures verifier evidence strength, not a calibrated probability. Scores below 0.85 cannot create SOLVED. Forecast and sentiment scores stay below that threshold.

## Memory and gate boundaries

Only trusted offline evaluator callers write memory. A string such as `analyst_verified` is a provenance declaration, not authentication. Hashes detect altered stored records; a file owner can forge a new dataset or recompute hashes. Do not import untrusted memory files as proof of truth. Runtime inputs cannot call the memory writer. No prediction is used as its own ground-truth label.

`lab.py learn` writes a candidate and a gate report into a new directory. Only a successful release can be loaded with `--memory-dir`. It never overwrites the old release. Add `--base-memory-dir` to start from prior accepted memory; include old and new task families in validation. Roll back by selecting the old release directory. No active production policy changes automatically.

Learning adjusts ranking of registered strategies. It does not train neural weights, write a new algorithm, or add an adapter. Columnar transfer uses a hand-written normalization so equivalent profiles can reuse learned ranking. This is representation transfer, not discovery of an unseen data format.

## Numerical recurrence extension (0.2.1)

`x_0=(5a+6b)/(a+b)`, `x_1=(25a+36b)/(5a+6b)`,
`x_n=111-(1130-3000/x_(n-2))/x_(n-1)`.
The two solvers iterate this recurrence with binary floating point or exact rational arithmetic.
The verifier uses `x_n=(a*5^(n+1)+b*6^(n+1))/(a*5^n+b*6^n)` directly; the
evaluator generates labels with a separate integer linear recurrence for the numerator sequence.
For positive weights the finite value is between 5 and 6. Approaching 6 does not mean equality at a finite step.
All three implement the same specified mathematics through different arithmetic paths; this is
independent implementation checking, not independent empirical evidence for the task definition.

To derive the identity, let `y_n=a*5^n+b*6^n`. Both roots satisfy
`t^3-111*t^2+1130*t-3000=(t-5)(t-6)(t-100)=0`; hence
`y_(n+1)=111*y_n-1130*y_(n-1)+3000*y_(n-2)`. Divide by `y_n`
and substitute `x_n=y_(n+1)/y_n` to obtain the solver recurrence.
The final API answer is rounded to a float; SOLVED certifies the configured tolerance.
This manually registered family expands the task contract. Memory only changes which solver starts first.
