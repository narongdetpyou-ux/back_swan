# Next experiment: improve semantic selection without memorizing the current failures

Objective: reduce errors on text with contrasts, clause boundaries and negation, while preserving exact-task accuracy and low review use.

The existing `challenge_text_contrast` holdout has now been inspected and must be treated as a development set. Keep its 10 failures, including five cases where a correct first candidate was replaced by a wrong final choice. They reveal that the current verifier's syntactic plausibility cannot reliably choose between semantic answers.

1. Define a narrow text task with explicit language, clause and scope semantics. Register a stronger solver and an independent verifier, or use verified external annotations for BEST_EFFORT evaluation. Do not boost evidence strength merely because two heuristics agree.
2. Use new training examples and a separate regression validation set covering tables, graphs, rules, forecasts and text. Include hard negatives and cases with no adequate verifier.
3. Fix source code and acceptance criteria before generating a new final holdout. Use task templates and combinations absent from training, not only different IDs or numeric seeds.
4. Compare cold/warm ranking, final answer accuracy, harmful correction, attempts, unresolved rate, wrong automatic answers, and REVIEW. Report each family and denominator.
5. Accept a new release only if validation passes. Never teach from final holdout labels. If the candidate fails, continue using the previous release.

The provisional review target is at most 5% on a defined workload. It is evaluated together with correct automatic answers and total unresolved cases, so returning CANNOT_SOLVE or lowering confidence cannot masquerade as solving more problems.
