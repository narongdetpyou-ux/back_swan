# Connected sources and artifact tools used for this build

| Capability | Observed use / boundary |
|---|---|
| GitHub | Read `narongdetpyou-ux/back_swan` README; repository is private and its default branch documents Logic v8. No main-branch source was overwritten. |
| GitLab | Located the private `black-swan-group/black-swan-project`; no code from it was used. |
| Dropbox | Search for `black_swan` returned no matches in the connected account. |
| Notion | Checked available access; standard Black Swan search returned no matching pages. No project pages were invented or changed. |
| Data | Used analysis-validation guidance for populations, denominators, separate failure types, leakage and raw-result reconciliation. |
| Acumen by Talarion | Exploratory evaluation-research lookup; no retrieved news claims were used as benchmark labels or acceptance evidence. |
| CMS | Reused an existing transformed historical snapshot; preserved source URLs and hashes; did not validate upstream responses again. |
| OpenAI Platform / Developers | Consulted official evaluation guidance; runtime needs no API key and makes no API calls. No callable Platform connector was exposed. |
| Figma | Generated an editable FigJam flow of the actual decision and learning components. Durable Mermaid source is in `architecture.mmd`. |
| Visualize | Prepared a mobile-friendly replay of selected actual attempts in the conversation. It displays recorded decisions, not a live Python runtime. |
| Template Creator | Inspected its scope; it creates artifact-template skills from supported visual/document references. This programming task instead includes `EXPERIMENT_TEMPLATE.json`; it is not an installed template skill. |
| app_block | No callable tool with this name was exposed; the available native Visualize reference is used for the inline replay. |

These assistant-side tools are not installed as autonomous connectors inside the Python lab. Adding a live source requires an explicit input adapter, provenance handling, budgets and evaluation. This artifact contains local input ingestion and offline experiments.

Editable diagram (claim link expires 2026-09-21; the Mermaid source remains in this bundle): [Black Swan — วงจรแก้ปัญหาและเรียนรู้](https://www.figma.com/online-whiteboard/create-diagram/25db7588-f36d-4efa-a8cd-c1bf3a567ec2?utm_source=chatgpt&utm_content=edit_in_figjam&oai_id=v1%2FtBZgLVhDSn2EngJ92f4F0mhsCMegtQgPiLxFCVUdbEQdSqOXYYFTIz&request_id=78755ad6-45dd-49e9-9b30-dbf97debd466)
