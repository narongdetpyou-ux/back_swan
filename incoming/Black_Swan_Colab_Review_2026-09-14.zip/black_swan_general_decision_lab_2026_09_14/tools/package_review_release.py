"""Bundle the reviewed project and verify every compressed member."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'Black_Swan_Colab_Review_2026-09-14.zip'
excluded={'__pycache__','.git','.pytest_cache'}
files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and not any(x in excluded for x in p.relative_to(ROOT).parts)
       and p.name not in {'CHECKSUMS.sha256','REVIEW_CHECKSUMS.sha256'} and p.suffix not in {'.pyc','.zip'}]
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
(ROOT/'REVIEW_CHECKSUMS.sha256').write_text(manifest)
files.append(ROOT/'REVIEW_CHECKSUMS.sha256')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for p in files:
        assert z.read(ROOT.name+'/'+p.relative_to(ROOT).as_posix()) == p.read_bytes()
checksum=hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(checksum+'  '+OUT.name+'\n')
print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'files':len(files),'sha256':checksum,'verified_every_member':True}))
