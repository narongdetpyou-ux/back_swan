"""Write the review from measured source audit and executed experiment evidence."""
from pathlib import Path
import json
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
status=json.loads((ROOT/'reports/user-review/notebook_execution.json').read_text())
run=Path(status['run_dir'])
s=json.loads((run/'summary.json').read_text())
a=json.loads((run/'source_audit.json').read_text())
oldb,olda=[s['old_regression'][x]['metrics'] for x in ('before','after')]
newb,newa=[s['numerical'][x]['metrics'] for x in ('before','after')]
probes=s['core_probes']['metrics']
log=(run/'tests.log').read_text()
match=re.search(r'Ran (\d+) tests in ([\d.]+)s',log)
assert match and '\nOK\n' in log and s['all_checks_passed']
count,seconds=int(match[1]),float(match[2])
relative=run.relative_to(ROOT).as_posix()

text=f'''# Black Swan — ตรวจและจัดระเบียบการทดลอง Colab

ฉบับ 0.2.1 • 14 กันยายน 2026 • ต่อจาก `สำเนาของ_untitled7.py`

**ตรวจไฟล์จริงแล้ว จัดชุดทดลองใหม่ และรันตรวจครบตามขอบเขตนี้** องค์ประกอบทั้ง 8 เชื่อมกันได้
เพิ่มโจทย์ความคลาดเคลื่อนของตัวเลขเข้ากับ Core พร้อมเรียนรู้การเลือกวิธีจากผลยืนยัน
จุดที่ดีขึ้นคือเลือกวิธีที่เหมาะตั้งแต่ครั้งแรก; คะแนนคำตอบสุดท้ายของชุดเดิมยังเท่าเดิม

## เปิดทดลองบนมือถือ

1. ดาวน์โหลด `Black_Swan_Colab_Reviewed.ipynb` และ `Black_Swan_Colab_Review_2026-09-14.zip`
2. เปิด Colab แล้วอัปโหลดไฟล์ `.ipynb` เลือก Run all
3. หากสมุดขอไฟล์ ZIP ให้อัปโหลด ZIP ของฉบับนี้
4. ดูผลสรุปก่อน–หลัง เซลล์แสดงการแก้คำตอบ และแก้ `USER_REQUEST` เพื่อทดลองเอง
5. เซลล์ท้ายรวมผลรอบนั้นเป็น ZIP ให้ดาวน์โหลดจากแถบ Files

ไฟล์ Python เดิมที่ชื่อ `สำเนาของ_untitled7.py` ปรับเป็นตัวเริ่มรันที่ใช้ Python ปกติได้
สูตรและการทดลองแยกเป็นโมดูลภายใน ZIP; ต้นฉบับก่อนปรับเก็บครบที่
`provenance/user_colab_original_2026_09_14.py` รวมคำสั่งและรายงานเดิมเพื่อเปรียบเทียบย้อนหลัง

## สิ่งที่ตรวจพบและแก้

| จุดจากต้นฉบับ | ผลที่ยืนยันได้ | การแก้ |
|---|---|---|
| คำสั่ง `!python`, `!unzip` และ `%cd` ที่ถูกคอมเมนต์ | ไฟล์ export รันเป็น Python ปกติไม่ได้ตั้งแต่บรรทัด 13 | ใช้ pathlib, zipfile และ subprocess; ค้นโฟลเดอร์อย่างชัดเจน |
| `my_test.json` ใช้ data_type/values | ไม่ตรง ProblemRequest ซึ่งต้องมี problem_id/objective/payload | เพิ่มตัวอย่างที่ถูกต้องและเซลล์ USER_REQUEST |
| ใช้ group หา family ใน inputs และสุ่มหยิบแถวที่ 50 | family แยกอยู่ในไฟล์ labels; ไม่รับรองว่าแถวสำรองเป็นกราฟ | ใช้ชุด probe ระบุชนิด/เป้าหมายตรง และแยก labels จาก inputs |
| `null` ใน Python บรรทัด 1003 | ชื่อนี้ไม่มีนิยาม แม้มีเซลล์แก้ None อยู่ภายหลัง | รุ่นจัดระเบียบใช้ None และไม่มีเซลล์ผิดซ้ำ |
| ตัวเลข baseline/learned เขียนเป็นค่าคงที่ | อาจเป็นตัวเลขที่คัดจากการรัน แต่ไฟล์ `.py` ไม่ได้เก็บ cell outputs ให้ตรวจย้อน | ตารางใหม่โหลด JSON จากรอบที่เพิ่งรัน |
| ตรวจ subset ด้วยผลรวมอย่างเดียว | ตัวตรวจเดิมยอมรับ `[999]` สำหรับเป้าหมาย 999 โดยไม่รู้ว่ามาจากชุดใด | ตรวจดัชนี สมาชิกซ้ำ และผลรวม; รองรับชุดว่างและจำกัดจำนวนค้นหา |
| ระบุว่าผล Muller “เท่ากับ 6 สำเร็จ 100%” | ค่าเมื่อจำนวนขั้นจำกัดเข้าใกล้ 6 แต่ยังไม่เท่ากับ 6 | ตรวจด้วยสูตรปิดและเกณฑ์คลาดเคลื่อน 1e-9 |
| สคริปต์นักสืบสรุป Charlie ไว้ตายตัว | ลบหลักฐานสคริปต์ผิดออกแล้ว ยังพิมพ์ว่า Charlie เป็นผู้ก่อการ | แสดงสิ่งสังเกต ความขัดแย้ง และหลักฐานตัวบุคคลที่ยังขาด |
| Protocol รับ mode=evolved พร้อมรหัส | ผู้รับใช้ mode และคืนค่าเป้าหมายที่เขียนไว้; สลับลำดับรหัสหรือเปลี่ยน token บางตัวก็ยังผ่าน | ผู้รับเห็นเฉพาะ bytes; ทดสอบหลายเป้าหมายและ negative controls |
| เรียกข้อมูลชื่อ A→B→A ว่า object วนลูป | เป็นโครงสร้างจำกัดที่ซ้ำชื่อ ไม่ใช่วัตถุ Python อ้างตัวเอง | ทดสอบ object cycle แยกจากกราฟที่เชื่อมผ่าน edges |
| กราฟเดิมถูกปฏิเสธเป็น opaque แล้วสรุปว่าตัดวงจรสำเร็จ | กรณีเหล่านั้นมี attempts=0 จึงไม่ได้เดินกราฟ | เพิ่มวงแหวน 1,000 โหนด, clique 30 โหนด และวงจรที่ปลายทางไปไม่ถึง |
| “APPROVED FOR PRODUCTION” และ memory stability 100% | ไม่มีการวัด memory leak, โหลดต่อเนื่อง หรือโปรดักชันรองรับ | เปลี่ยนเป็นขอบเขตห้องทดลอง พร้อมระบุสิ่งที่วัดจริง |

ข้อค้นพบเหล่านี้ตรวจการออกแบบการทดลองและคำสรุปในไฟล์ ไม่ได้ปฏิเสธว่าคุณเคยรันใน Colab
เวลาที่อยู่ในรายงานเดิมยืนยันจาก export นี้อย่างเดียวไม่ได้ ตารางเวลาด้านล่างเป็นการวัดใหม่ที่นี่

## องค์ประกอบ 1–8 ที่ใช้จริง

| ส่วน | หน้าที่ในโจทย์ตัวเลขใหม่ | โค้ด |
|---|---|---|
| 1 Data Interpreter | รู้จักข้อมูล recurrence และสร้าง profile ที่ไม่มีเฉลย | interpreter.py |
| 2 Strategy Selector | เลือก float หรือ fraction โดยใช้ผลที่ยืนยันจากชุดเรียน | selector.py |
| 3 Solver | คำนวณสูตรวนซ้ำด้วยเลขทศนิยมหรือเศษส่วน | numerics.py, strategies.py |
| 4 Verifier | คำนวณสูตรปิดแยกจาก Solver แล้วเทียบคำตอบจริง | verifier.py |
| 5 Correction Loop | ถ้าวิธีแรกไม่ผ่าน ให้ลองอีกวิธีภายในงบเดิม | correction.py, runtime.py |
| 6 Outcome Memory | เก็บทั้งวิธีที่ผิดและถูกจาก oracle ภายนอก | memory.py |
| 7 Learning Gate | ตรวจโจทย์ใหม่และโจทย์เก่ารวม 68 เคสก่อนใช้ memory | learning_gate.py |
| 8 Decision Policy | ตอบ SOLVED เมื่อผ่านเกณฑ์; ไม่ใช้ REVIEW เพราะเพียงไม่คุ้นเคย | policy.py |

เพิ่มวิธีคำนวณที่ลงทะเบียนจาก 21 เป็น 23 วิธี รองรับโจทย์ recurrence อีกชนิด
ตัวแปลงและวิธีคำนวณใหม่นี้เขียนเพิ่มโดยผู้พัฒนา ส่วนที่ Black Swan เรียนคือการจัดลำดับวิธี
ไม่ได้สร้างอัลกอริทึมใหม่หรือฝึกน้ำหนักโมเดลภาษา

## ผลที่วัดใหม่

| ตัววัด | ก่อนใช้บทเรียน | หลังใช้บทเรียน |
|---|---:|---:|
| ชุดเดิม: คำตอบสุดท้ายถูก / โจทย์มีคำตอบ | {oldb['correct_answers']}/{oldb['answerable_cases']} | {olda['correct_answers']}/{olda['answerable_cases']} |
| ชุดเดิม: เลือกครั้งแรกถูก | {oldb['first_attempt_success_rate']:.2%} | {olda['first_attempt_success_rate']:.2%} |
| ชุดเดิม: จำนวนวิธีเฉลี่ยต่อเคสทั้งหมด | {oldb['mean_attempts']:.2f} | {olda['mean_attempts']:.2f} |
| ชุดเดิม: REVIEW / ทั้งหมด | {oldb['review_count']}/{oldb['cases']} | {olda['review_count']}/{olda['cases']} |
| ตัวเลขใหม่: คำตอบสุดท้ายถูก | {newb['correct_answers']}/{newb['answerable_cases']} | {newa['correct_answers']}/{newa['answerable_cases']} |
| ตัวเลขใหม่: เลือกครั้งแรกถูก | {newb['first_attempt_success_rate']:.2%} | {newa['first_attempt_success_rate']:.2%} |
| ตัวเลขใหม่: จำนวนวิธีเฉลี่ย | {newb['mean_attempts']:.2f} | {newa['mean_attempts']:.2f} |
| ตัวเลขใหม่: REVIEW | {newb['review_count']} | {newa['review_count']} |

การเรียนใหม่ใช้ 12 เคส เก็บผลที่ยืนยัน 24 รายการ เพิ่ม memory จาก 540 เป็น 564 รายการ
ตรวจประตูด้วยโจทย์ตัวเลข 8 เคสและโจทย์เก่า 60 เคส ก่อนประเมินชุดตัวเลขอีก 12 เคส
ไม่มี input ซ้ำตรงกันข้ามชุด แต่ยังเป็นสูตรคณิตศาสตร์ตระกูลเดียวที่เปลี่ยนพารามิเตอร์
ผลนี้จึงแสดงการเรียนเลือกวิธีในโจทย์ที่กำหนด ไม่ได้พิสูจน์ว่าถ่ายโอนไปได้ทุกปัญหา
ทั้งสามชุดกำหนดไว้ก่อนรอบพัฒนาแรก รอบส่งมอบรันซ้ำเพื่อตรวจขั้นตอนและสมุดทดลอง ไม่มีการจูน Solver จากเฉลยชุดสุดท้าย
ชุดเก่า 270 เคสเคยถูกตรวจแล้ว จัดเป็น regression replay ไม่เรียกว่าชุดใหม่ที่ระบบยังไม่เคยถูกประเมิน

### กรณีทดสอบจากไฟล์ของคุณ

ตรวจเงื่อนไขผลลัพธ์ผ่าน **{probes['correct']}/{probes['cases']} กรณี**
ในนี้มีโจทย์ที่แก้คำตอบได้ {probes['correct_answers']}/{probes['answerable_cases']} และกรณีปฏิเสธหรือขอข้อมูลอย่างเหมาะสมอีก {probes['cases']-probes['automatic_answers']} กรณี
จึงไม่เขียนว่า “แก้ได้ 19/19”
REVIEW เท่ากับ {probes['review_count']}/{probes['cases']} เพราะมีกรณีตั้งใจส่งข้อมูลไม่รองรับและกำหนด high risk;
ไม่รวมอัตรานี้กับชุดงานทั่วไปเพื่อทำให้ REVIEW ดูต่ำ

วงแหวน 1,000 โหนดและ clique 30 โหนดเข้าถึง Solver/Verifier จริง มี attempts มากกว่า 0
วงจรที่ปลายทางไปไม่ถึงตอบ False ถูกต้อง
Python object ที่อ้างตัวเองถูกปฏิเสธด้วย REPEATED_CONTAINER และคำขอถัดไปยังแก้ได้
กราฟ clique มีจำนวนลิงก์ตามกำลังสองของจำนวนโหนด ไม่ได้ทำให้การหา reachability กลายเป็นการไล่ทุกเส้นทางแบบเอ็กซ์โพเนนเชียล

### เวลาประมวลผลชุดเดิมในสภาพแวดล้อมนี้

| ช่วงเวลา (มิลลิวินาที) | ก่อน | หลัง |
|---|---:|---:|
| p50 | {oldb['latency_p50_ms']:.3f} | {olda['latency_p50_ms']:.3f} |
| p95 | {oldb['latency_p95_ms']:.3f} | {olda['latency_p95_ms']:.3f} |
| p99 | {oldb['latency_p99_ms']:.3f} | {olda['latency_p99_ms']:.3f} |
| ค่าสูงสุดที่พบ | {oldb['latency_max_ms']:.3f} | {olda['latency_max_ms']:.3f} |

วัด per-call wall time ด้วย perf_counter_ns และ nearest-rank percentile รวมการเริ่ม worker และการลองใหม่
p50/p95 เป็นเปอร์เซ็นไทล์ ไม่ใช่ค่าเฉลี่ย ไม่มี network/LLM call ในชุดนี้
ไม่ใช้เวลานี้สรุป throughput, การรับโหลดต่อเนื่อง, memory leak หรือ SLA

## การทดลองประกอบที่ยังเก็บไว้

`experiments/supporting.py` มี Buffon, Ramanujan, subset-sum, การประเมินหลักฐาน และตัวเข้ารหัส/ถอดรหัส
ส่วนเหล่านี้มีบันทึกผลจริงและขอบเขตของแต่ละการทดลอง แต่ไม่ได้เรียก Core หรือเพิ่ม memory
Entropy สูงอย่างเดียวไม่พิสูจน์ว่ารหัสมีความหมาย ไม่ใช้ผลตัวควบคุมเรียกว่าโมเดลวิวัฒนาการหรือ collapse
Buffon เป็นการจำลองที่ใช้ math.pi เพื่อสุ่มมุม และช่วงประมาณ 95% แปลงจาก Wilson interval ของอัตราข้ามเส้น

## รันด้วยคำสั่ง

จากโฟลเดอร์โปรเจกต์ที่แตก ZIP แล้ว:

```bash
python3 run_user_experiments.py --run-tests
python3 lab.py solve examples/recurrence.json --memory-dir {relative}
python3 lab.py solve examples/my_sequence.json --memory-dir {relative}
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 replay_snapshot.py
```

ผลใหม่อยู่ใน runs/user-review-เวลาที่รัน เปลี่ยน --memory-dir เป็นโฟลเดอร์ผลใหม่เพื่อใช้บทเรียนรอบนั้น
replay_snapshot.py สร้างโฟลเดอร์ใหม่ทุกครั้ง; เป็นเพียงการคำนวณบน snapshot เดิมที่มีอยู่ ไม่ได้ดึง CMS ใหม่หรือประเมินสิทธิ์รักษา

## หลักฐานและขอบเขตการตรวจ

- ชุดทดสอบโค้ด **{count}/{count} ผ่าน** ใช้เวลา {seconds:.3f} วินาทีในการรันครั้งนี้
- เซลล์ Python ในสมุดทดลอง **{status['code_cells_executed']}/{status['code_cells_executed']}** รันตามลำดับสำเร็จและเก็บ output จริง
- สภาพแวดล้อมนี้ไม่มี nbformat/nbclient/ipykernel จึงใช้ตัวรัน Python ตามลำดับเซลล์ ยังไม่ได้รันผ่าน Jupyter kernel หรือหน้า Colab โดยตรง
- ตรวจภาพกราฟจากไฟล์ PNG ที่สร้างจริง; ไม่อ้างว่าตรวจ layout ทั้งสมุดในหน้า Colab บนมือถือแล้ว
- ผลฉบับส่งมอบ: `{relative}/summary.json`
- โค้ด/ชุดข้อมูล/ผลยืนยัน/ประตู: protocol.json, dataset_manifest.json, training_outcomes.jsonl, learning_gate.json
- `source_audit.json` เก็บผลทดสอบควบคุมกับนิยามฟังก์ชันเดิม; source SHA-256: `{a['source_sha256']}`

ข้อจำกัดที่ยังเหลือชัดเจนคือคำตอบข้อความผิด 10 เคสในชุดเดิม และมี 5 เคสที่เลือกคำตอบภายหลังแย่กว่าคำตอบแรก
การแก้ด้านนี้ควรใช้แผน docs/NEXT_EXPERIMENT.md พร้อมชุดทดสอบสุดท้ายชุดใหม่
'''
(ROOT/'COLAB_REVIEW_TH.md').write_text(text,encoding='utf-8')
(ROOT/'README.md').write_text(f'''# Black Swan General Decision Lab — 0.2.1

ห้องทดลองเลือกวิธีแก้ปัญหา ตรวจคำตอบ ลองวิธีอื่น และเรียนรู้จากผลยืนยัน

เริ่มจาก [สมุดทดลอง Colab](notebooks/Black_Swan_Colab_Reviewed.ipynb) และ [ผลตรวจไฟล์ของผู้ใช้ภาษาไทย](COLAB_REVIEW_TH.md)
องค์ประกอบ 8 ส่วนเชื่อมกัน; {count} tests ผ่าน; เพิ่ม recurrence solver สองวิธีและชุดทดลองจากไฟล์ Untitled7
ข้อจำกัดข้อความ 10 เคสในชุดเดิมยังคงอยู่

```bash
python3 run_user_experiments.py --run-tests
python3 lab.py solve examples/recurrence.json --memory-dir {relative}
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

- src/black_swan_general: core 8 ส่วน และ 23 strategies
- experiments/: fixtures, source audit และการทดลองประกอบ
- run_user_experiments.py: การทดลองต่อจากไฟล์ Colab พร้อม gate และ raw evidence
- colab_runner.py: ตัวเริ่มรัน Python ปกติ
- notebooks/: สมุดทดลองพร้อม outputs ที่รันจริงตามลำดับ Python
- {relative}/: ผลส่งมอบฉบับนี้
- runs/verified-final/: ผลฐาน 0.2.0 ที่เก็บไว้
- provenance/user_colab_original_2026_09_14.py: ต้นฉบับครบก่อนจัดระเบียบ
- docs/CONTRACTS.md: รูปแบบข้อมูลและขอบเขตทุก objective

Core ใช้ Python standard library; กราฟใน notebook ใช้ Matplotlib
Notebook ตรวจด้วย sequential Python runner เพราะไม่มี Jupyter kernel ในสภาพแวดล้อมนี้
แพ็กเกจนี้เป็น General Decision Lab 0.2.1; ไม่ได้เปลี่ยนสาย Logic v8 ใน GitHub เป็น v9
''',encoding='utf-8')
(ROOT/'PROJECT_STATUS.md').write_text(f'''# Continuation record — user Colab review, 2026-09-14

Goal: general strategy selection, self-verification/correction and verified-outcome learning across data structures. REVIEW is exceptional for ordinary solvable tasks. Cybersecurity is only one experimental context.

Recovered uploaded source from Library identity libfile_e45f5c8b4f5c819182f339368a6d6efa after local attachment copy was missing. Original file is preserved under provenance/user_colab_original_2026_09_14.py; source hash {a['source_sha256']}.

Current package 0.2.1. Explicitly registered recurrence input and float/Fraction solvers use all 8 existing components. Independent closed-form verification and integer-linear-recurrence evaluator. Other user demonstrations organized under experiments/ with bounded execution and narrower claims. No neural training or autonomous invention.

Validation: {count} tests passed; notebook {status['code_cells_executed']} Python cells executed sequentially; actual Jupyter/Colab kernel and full mobile notebook rendering unverified. Final evidence {relative}. Probes {probes['correct']}/{probes['cases']} contract-correct with {probes['correct_answers']}/{probes['answerable_cases']} answers solved. Numeric holdout 12/12 correct both conditions, first choice 0/12 -> 12/12, attempts 2 -> 1, REVIEW 0. Learning 12 cases, gate validation 68 (60 previous+8 numeric), new holdout 12, memory 540 -> 564. Original 270 regression cases retain 225/235 correct answers and 5 REVIEW.

Original claims corrected: fixed person attribution remains even with evidence removed; protocol mode leaks success and decoder ignores token order; subset verifier lacks membership checks; opaque graph rejection does not test graph traversal; no production/load/memory-leak claim supported.

Next: improve semantic verifier and harmful later selection using docs/NEXT_EXPERIMENT.md and new final cases. Retain the 10 semantic BEST_EFFORT failures and five harmful later selections as known limits. No remote git changes in this turn.
''',encoding='utf-8')
write={'run':relative,'tests_passed':count,'notebook':status,'all_checks_passed':s['all_checks_passed']}
(ROOT/'reports/user-review/delivery_checks.json').write_text(json.dumps(write,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(ROOT/'COLAB_REVIEW_TH.md'),'tests':count,'run':relative}))
