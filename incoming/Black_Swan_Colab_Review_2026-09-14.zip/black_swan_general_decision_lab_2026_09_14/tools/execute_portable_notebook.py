"""Execute plain-Python notebook cells sequentially when Jupyter is unavailable.

This is explicitly not a Jupyter-kernel or Colab-browser compatibility test.
Each saved output is captured from actual execution of the notebook's source.
"""
import argparse
import base64
from contextlib import redirect_stdout, redirect_stderr
import io
import json
import os
from pathlib import Path
import time
import traceback


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('notebook',type=Path)
    parser.add_argument('--cwd',type=Path,required=True)
    args=parser.parse_args()
    path=args.notebook.resolve()
    notebook=json.loads(path.read_text())
    assert notebook['nbformat']==4 and notebook['nbformat_minor']==5
    ids=[cell['id'] for cell in notebook['cells']]
    assert len(ids)==len(set(ids))
    environment={'__name__':'__main__','__file__':str(path)}
    os.chdir(args.cwd)
    os.environ['MPLBACKEND']='Agg'
    count=0
    started=time.monotonic()
    for cell in notebook['cells']:
        if cell['cell_type']!='code': continue
        count+=1
        cell['outputs']=[]
        cell['execution_count']=count
        capture=io.StringIO()
        try:
            with redirect_stdout(capture), redirect_stderr(capture):
                exec(compile(cell['source'],f'{path.name}:cell-{count}','exec'),environment)
        except Exception as error:
            cell['outputs'].append({'output_type':'error','ename':type(error).__name__,'evalue':str(error),
                                    'traceback':traceback.format_exc().splitlines()})
            path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1)+'\n')
            raise
        if capture.getvalue():
            cell['outputs'].append({'output_type':'stream','name':'stdout','text':capture.getvalue()})
        variable=cell['metadata'].get('output_image_variable')
        if variable:
            image_path=environment[variable]
            cell['outputs'].append({'output_type':'display_data','metadata':{},'data':{
                'image/png':base64.b64encode(image_path.read_bytes()).decode(),'text/plain':'Measured first-choice comparison'}})
        print(f'cell {count} completed',flush=True)
    status={'method':'sequential plain Python, shared globals, actual captured outputs',
            'code_cells_executed':count,'success':True,'elapsed_seconds':time.monotonic()-started,
            'jupyter_kernel_executed':False,'colab_browser_executed':False,
            'missing_dependencies':['nbformat','nbclient','ipykernel'],
            'run_dir':str(environment['RUN_DIR'])}
    notebook['metadata']['black_swan_validation']=status
    path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1)+'\n')
    status_path=args.cwd/'reports/user-review/notebook_execution.json'
    status_path.write_text(json.dumps(status,indent=2)+'\n')
    print(json.dumps(status,indent=2))


if __name__=='__main__': main()
