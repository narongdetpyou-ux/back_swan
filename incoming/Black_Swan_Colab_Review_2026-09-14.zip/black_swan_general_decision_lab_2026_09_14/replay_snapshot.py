#!/usr/bin/env python3
"""Replay historical CMS-attributed values. No new download or rule inference."""
from pathlib import Path
import argparse,csv,json,sys
from datetime import datetime,timezone
from decimal import Decimal
from collections import defaultdict,Counter
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from black_swan_general import BlackSwanGeneralEngine
from black_swan_general.contracts import ProblemRequest,EvaluationCase
from black_swan_general.io import load_release
from black_swan_general.evaluation import evaluate_engine
from run_experiment import write_json,write_jsonl,sha


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--memory-dir',type=Path,default=ROOT/'runs/verified-final')
    args=parser.parse_args()
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=args.output or ROOT/'runs'/('snapshot-'+stamp)
    if out.exists(): raise SystemExit('Replay output exists; preserve it before rerunning.')
    source=ROOT/'data/raw/medicare_multicase_2013_2024.csv'
    rows=list(csv.DictReader(source.open()))
    keys=[(r['reporting_year'],r['hcpcs_code']) for r in rows]
    assert len(keys)==len(set(keys))
    grouped=defaultdict(list)
    for row in rows:
        if row['observation_status'] not in {'complete','not_published'}: raise ValueError('unknown status')
        grouped[row['hcpcs_code']].append(row)
    cases=[]
    for code,group in sorted(grouped.items()):
        values=[Decimal(r['total_services']) for r in group if r['observation_status']=='complete']
        assert values
        expected=float(sum(values)/len(values))
        payload=[{'value':float(r['total_services']) if r['observation_status']=='complete' else None} for r in group]
        req=ProblemRequest('snapshot-'+code,'column_summary',payload,{'column':'value','missing_semantics':'unknown'})
        cases.append(EvaluationCase(req,'snapshot_missing_aware_mean','replay',expected))
    memory=load_release(args.memory_dir)
    result=evaluate_engine(BlackSwanGeneralEngine(memory=memory),cases)
    write_json(out/'results.json',result)
    write_jsonl(out/'inputs.jsonl',(__import__('dataclasses').asdict(c.request) for c in cases))
    write_json(out/'provenance.json',dict(source_sha256=sha(source),rows=len(rows),unique_keys=len(set(keys)),
               status_counts=dict(Counter(r['observation_status'] for r in rows)),
               independently_revalidated_upstream=False,claim='correct arithmetic on stored snapshot values only'))
    print(json.dumps(result['metrics'],indent=2))
if __name__=='__main__': main()
