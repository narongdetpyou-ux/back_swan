#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Black Swan: organized continuation of the user's Untitled7 Colab experiment.

Run as Python or with Colab %run. Requires the accompanying reviewed project ZIP.
The original Colab source is preserved under provenance/.
Full experiment implementations: experiments/ and run_user_experiments.py.
This script contains no IPython shell syntax and never edits benchmark answers.
"""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import json
import subprocess
import sys
import zipfile

PROJECT_NAME = 'black_swan_general_decision_lab_2026_09_14'
ARCHIVE_NAME = 'Black_Swan_Colab_Review_2026-09-14.zip'


def locate_project(project_dir=None, archive=None):
    if project_dir is not None:
        root = Path(project_dir).expanduser().resolve()
        if not (root/'run_user_experiments.py').is_file():
            raise FileNotFoundError('project-dir does not contain run_user_experiments.py')
        return root
    bases = [Path.cwd(), Path(__file__).resolve().parent]
    for base in bases:
        for root in (base,base/PROJECT_NAME):
            if (root/'run_user_experiments.py').is_file():
                return root.resolve()
    candidates = [Path(archive)] if archive else [base/ARCHIVE_NAME for base in bases]
    for candidate in candidates:
        if candidate.is_file():
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            destination = Path.cwd()/('black-swan-session-'+stamp)
            with zipfile.ZipFile(candidate) as bundle:
                members = bundle.infolist()
                if sum(member.file_size for member in members) > 100_000_000:
                    raise ValueError('archive exceeds expected expanded size')
                for member in members:
                    target = (destination/member.filename).resolve()
                    if not target.is_relative_to(destination.resolve()):
                        raise ValueError('archive contains an unsafe member path')
                bundle.extractall(destination)
            return locate_project(destination/PROJECT_NAME)
    raise FileNotFoundError('Place '+ARCHIVE_NAME+' beside this script, or pass --project-dir /path/to/project')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-dir',type=Path)
    parser.add_argument('--archive',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--run-tests',action='store_true')
    args = parser.parse_args(argv)
    root = locate_project(args.project_dir,args.archive)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = args.output.resolve() if args.output else root/'runs'/('colab-'+stamp)
    command = [sys.executable,str(root/'run_user_experiments.py'),'--output',str(output)]
    if args.run_tests:
        command.append('--run-tests')
    proc = subprocess.run(command,cwd=root,check=False,timeout=600)
    if (output/'summary.json').exists():
        summary = json.loads((output/'summary.json').read_text())
        print('\nผลจากไฟล์:',output/'summary.json')
        for label,section in [('ข้อมูลเดิม',summary['old_regression']),('โจทย์ตัวเลขใหม่',summary['numerical'])]:
            before,after = section['before']['metrics'],section['after']['metrics']
            print(label,': เลือกครั้งแรกถูก',round(before['first_attempt_success_rate']*100,2),
                  '->',round(after['first_attempt_success_rate']*100,2),'%')
            print('คำตอบสุดท้ายถูก',after['correct_answers'],'/',after['answerable_cases'],
                  '| REVIEW',after['review_count'],'/',after['cases'])
        print('ผลทั้งหมด:', 'ผ่านเกณฑ์ที่กำหนด' if summary['all_checks_passed'] else 'มีข้อที่ต้องตรวจใน summary.json')
    return proc.returncode


if __name__ == '__main__':
    raise SystemExit(main())
