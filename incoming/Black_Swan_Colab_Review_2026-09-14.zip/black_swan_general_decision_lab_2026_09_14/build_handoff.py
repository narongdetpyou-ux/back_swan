from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
run=ROOT/'runs/verified-final'
s=json.loads((run/'summary.json').read_text())
a=json.loads((run/'metric_audit.json').read_text())
b=s['holdout']['baseline']['metrics'];m=s['holdout']['learned']['metrics']
pct=lambda n:f'{n*100:.1f}%'
rows='\n'.join(f"| {k} | {v['correct']}/{v['cases']} | {v['review']} |" for k,v in s['holdout']['learned']['by_family'].items())
report=f'''# Black Swan — โครงสร้างและผลทดลอง 14 กันยายน 2026

**โครงสร้างทั้ง 8 ส่วนรันได้แล้ว พร้อมใช้ทดลองจากไฟล์ของคุณ** ห้องทดลองนี้ต่อจากโค้ด General Decision Lab ที่พบในงานเดิม และพัฒนาเป็นแพ็กเกจ 0.2.0 แยกจาก Logic v8 ใน `back_swan` ชื่อ Black Swan เป็นชื่อโครงการ ไม่ได้กำหนดให้เป็นระบบไซเบอร์

## เป้าหมายที่ยึดในงานนี้

รับโจทย์หลายรูปแบบ → เลือกวิธีแก้ → ตรวจคำตอบ → ลองทางเลือก → จดจำผลที่ยืนยันแล้ว → ตรวจว่าบทเรียนช่วยงานใหม่โดยไม่ทำให้งานเก่าแย่ลง การส่ง REVIEW เป็นทางเลือกสำหรับงานเสี่ยงสูงที่ยังตัดสินไม่ได้

## โครงสร้าง 8 ส่วน

| ส่วน | ทำอะไร | สิ่งที่มีแล้ว |
|---|---|---|
| 1 Data Interpreter | อ่านว่าโจทย์เป็นข้อมูลแบบใด | ตัวเลขตามเวลา ตาราง ข้อความ กฎ กราฟ หลักฐานผสม เมทริกซ์ ลำดับ และตัวแปลงคอลัมน์ |
| 2 Strategy Selector | จัดลำดับว่าจะลองวิธีไหนก่อน | ใช้ลักษณะโจทย์และประวัติผลยืนยัน; เห็นคะแนนที่มาของการเลือก |
| 3 Solver | ลงมือคำนวณหรือหาคำตอบ | กลยุทธ์ที่ลงทะเบียนไว้ 21 แบบ; เพิ่มฟังก์ชันใหม่ได้ |
| 4 Verifier | ตรวจคำตอบจากข้อมูลต้นทาง | คำนวณซ้ำแยกจาก solver สำหรับงานที่มีคำตอบตรวจได้; งานภาษาและพยากรณ์ยังเป็น BEST_EFFORT |
| 5 Correction Loop | เปลี่ยนวิธีเมื่อวิธีแรกไม่ผ่าน | จำกัดจำนวนรอบและเวลา; ยุติ worker ที่ค้าง; เก็บแต่ละ attempt |
| 6 Outcome Memory | จำผลสำเร็จและล้มเหลว | เก็บผลที่ผู้ประเมินยืนยัน รวมถึง solver ที่ล้ม; ปฏิเสธ self-label และ label ขัดแย้ง |
| 7 Learning Gate | ตรวจบทเรียนก่อนเปิดใช้ | ชุด validation แยกจาก learning; ตรวจการถดถอยรายกลุ่มและคำตอบผิด |
| 8 Decision Policy | เลือกว่าจะตอบ ขอข้อมูล หยุด หรือ REVIEW | แยกสถานะชัดเจน พร้อมเหตุผลและรายการข้อมูลที่ยังขาด |

คู่มือเชิงเทคนิคและวิธีเพิ่มส่วนประกอบอยู่ใน `docs/CONTRACTS.md` แผนภาพที่แก้ไขต่อได้อยู่ใน `docs/architecture.mmd`

## ผลที่รันและตรวจแล้ว

ชุด learning {s['counts']['learning']} กรณี → validation {s['counts']['validation']} กรณี → holdout {s['counts']['holdout']} กรณี มีความจำ {s['active_records']} รายการผ่าน Learning Gate เฉลยอยู่คนละไฟล์กับโจทย์ และฟังก์ชันตัดสินใจรับเฉพาะโจทย์

| ตัววัดบน holdout เดียวกัน | ก่อนมีความจำ | หลังมีความจำ |
|---|---:|---:|
| คำตอบสุดท้ายถูกในโจทย์ที่มีเฉลย | {b['correct_answers']}/{b['answerable_cases']} ({pct(b['task_success_rate'])}) | {m['correct_answers']}/{m['answerable_cases']} ({pct(m['task_success_rate'])}) |
| วิธีแรกให้คำตอบตรงเฉลยและผ่าน verifier | {round(b['first_attempt_success_rate']*b['answerable_cases'])}/{b['answerable_cases']} ({pct(b['first_attempt_success_rate'])}) | {round(m['first_attempt_success_rate']*m['answerable_cases'])}/{m['answerable_cases']} ({pct(m['first_attempt_success_rate'])}) |
| จำนวนวิธีที่ลองเฉลี่ยต่อกรณีทั้งหมด | {b['mean_attempts']:.2f} | {m['mean_attempts']:.2f} |
| REVIEW | {b['review_count']}/{b['cases']} ({pct(b['review_rate'])}) | {m['review_count']}/{m['cases']} ({pct(m['review_rate'])}) |
| กรณีที่ยังไม่มีคำตอบอัตโนมัติ | 35/270 | 35/270 |
| คำตอบอัตโนมัติผิด | {b['automatic_wrong_count']} | {m['automatic_wrong_count']} |
| คำตอบแรกถูก แต่เลือกคำตอบท้ายผิด | {a['baseline']['harmed_by_later_selection']} | {a['learned']['harmed_by_later_selection']} |
| โปรแกรมตัดสินใจล้มโดยไม่จัดการ | {b['error_count']} | {m['error_count']} |

**ความจำช่วยเลือกวิธีได้เร็วขึ้น แต่ความถูกต้องของคำตอบสุดท้ายยังเท่าเดิม** ไม่ลดความสามารถ baseline เพื่อสร้างคะแนนพัฒนาการ: ทั้งก่อนและหลังเรียนมีโอกาสลองได้ถึง 4 วิธีเหมือนกัน

การเปลี่ยนรูปแบบตารางเป็นคอลัมน์ 30 กรณี: ตอบถูก 30/30 ทั้งก่อนและหลังเรียน จำนวนวิธีเฉลี่ยลดจาก {a['baseline']['transfer_mean_attempts']:.1f} เหลือ {a['learned']['transfer_mean_attempts']:.1f} โดยใช้ความจำเดิมครบ 30 กรณี การถ่ายโอนนี้อาศัย adapter ที่เขียนไว้ล่วงหน้า ไม่ใช่ระบบประดิษฐ์ตัวแปลงเอง

## REVIEW ต่ำแล้วแก้ปัญหาได้จริงเท่าไร

หลังเรียนมี SOLVED 185, BEST_EFFORT 50, CANNOT_SOLVE 20, NEED_MORE_DATA 10 และ REVIEW 5 รวม 270 กรณี

- ได้คำตอบอัตโนมัติ 235 กรณี: ถูก 225 ผิด 10
- อีก 35 กรณีจัดการสถานะได้ตรงเกณฑ์ แต่ยังไม่ได้คำตอบ จึงไม่นับเป็นการแก้โจทย์สำเร็จ
- ถ้าวัดทุกกรณีรวมกัน คำตอบอัตโนมัติที่ถูกคือ 225/270 หรือ {pct(m['correct_automatic_rate_all_cases'])}
- ค่า 260/270 คือความถูกต้องเมื่อรวมการเลือกสถานะด้วย ไม่ใช่จำนวนโจทย์ที่แก้สำเร็จ
- REVIEW ไม่เกิน 5% เป็นเป้าหมายทดลองชั่วคราวของประชากรโจทย์ชุดนี้ ไม่ใช่คำรับรองสำหรับข้อมูลทุกชนิด

## ข้อผิดพลาดที่พบและยังเหลือ

ผิด 10 กรณีในกลุ่ม `challenge_text_contrast` ซึ่งข้อความเปลี่ยนทิศความหมายด้วยประโยคหลัง เช่นเริ่มเชิงลบแต่ผลสุดท้ายเป็นบวก คำตอบผิดทั้งหมดอยู่ใน BEST_EFFORT ไม่ใช่ SOLVED ใน 5 กรณี solver แรกเคยตอบถูก แต่ขั้นเลือกผลท้ายเลือกคำตอบที่ผิด เพราะคะแนน verifier ตรวจได้เพียงลักษณะภาษาอย่างง่าย

ข้อผิดพลาดนี้เป็นความสามารถที่ยังขาดจริง ต้องปรับส่วนเข้าใจข้อความและวิธีประเมินคำตอบ ไม่ควรแก้ด้วยการเพิ่มความมั่นใจหรือเปลี่ยนเป็น REVIEW ทุกครั้ง เก็บรายละเอียดไว้ใน `runs/verified-final/unresolved_failures.json` และแผนทดลองถัดไปใน `docs/NEXT_EXPERIMENT.md`

ตัว core, solver และ verifier ยังเป็น Python ตามกฎที่เขียนไว้ การเรียนรู้ปรับลำดับกลยุทธ์ ไม่ได้ฝึก neural network, fine-tune โมเดล, สร้างอัลกอริทึมใหม่ หรือเข้าใจเอกสารและภาษาไทยทั่วไป การอ่านภาพ เสียง เอกสารยาว การค้นเว็บอัตโนมัติ และการพิสูจน์ความจริงของข้อความยังไม่มีใน runtime นี้

## สิ่งที่แก้จากโค้ดเดิม

แก้ verifier ที่เคยเชื่อชื่อวิธีใน metadata ให้ตรวจค่าคำตอบจากข้อมูลต้นทาง ตรวจ input ก่อน interpreter เพื่อรับมือรูปแบบผิดและวงจรอ้างอิง เปลี่ยนการจับเวลาหลังงานเป็น worker ที่ยุติได้จริง แยกรายการว่างกับข้อมูลหาย แยกน้ำหนักแหล่งข้อมูลจากข้อความที่แหล่งนั้นอ้างเอง และบันทึกความล้มเหลวของ solver ลง memory เพื่อเลี่ยงวิธีที่ล้มซ้ำ

ปรับการรายงานไม่ให้นับ fallback เป็น solved ตรวจการถดถอยรายกลุ่ม ตรวจตัวเลข NaN/ชุดตรวจว่าง และตรวจข้อมูลซ้ำข้ามชุดก่อนเริ่มเรียน รายละเอียดการแก้โจทย์ทดสอบที่นิยามผิดอยู่ใน `provenance/PROTOCOL_CORRECTIONS.md`

การทดสอบโปรแกรมผ่าน **37/37** รายการ รวมคำตอบปลอม, mutation ของ input, solver crash, hang/cancellation/cleanup, missing, constraints เสีย, ความจำจากความล้มเหลว และการห้าม holdout เขียน memory การผ่าน regression tests แยกจากข้อผิดพลาดทางความหมาย 10 กรณีใน benchmark

## ทดสอบกับข้อมูลที่เก็บไว้ก่อนหน้า

มี replay ตารางประวัติที่ระบุแหล่งเป็น CMS: 156 แถว, key ปีและรหัสไม่ซ้ำ, 117 แถว complete และ 39 แถว not_published คำนวณค่าเฉลี่ยโดยไม่แทน missing ด้วยศูนย์ได้ถูก 13/13 โจทย์

นี่คือการตรวจการคำนวณจาก snapshot ที่มีอยู่ ไม่ได้ดึงหรือตรวจคำตอบต้นทาง CMS ซ้ำในรอบนี้ และไม่ใช่การตัดสินสิทธิการรักษาหรือการเบิกจ่าย เก็บ source URL, สถานะข้อมูล และ checksum ใน `data/raw/` กับ `runs/historical-snapshot-replay/`

## ความเร็วที่วัดจริง

Linux / Python 3.12, local deterministic Python พร้อมสร้าง worker ต่อ attempt; ไม่มีการเรียกโมเดลหรือเครือข่าย ตัวเลขรวมเวลา engine และ worker startup แต่ไม่รวมการอ่านไฟล์ชุดโจทย์หรือการเขียนผล

| ต่อ decision | ก่อนเรียน | หลังเรียน |
|---|---:|---:|
| p50 | {b['latency_p50_ms']:.3f} ms | {m['latency_p50_ms']:.3f} ms |
| p95 | {b['latency_p95_ms']:.3f} ms | {m['latency_p95_ms']:.3f} ms |
| p99 | {b['latency_p99_ms']:.3f} ms | {m['latency_p99_ms']:.3f} ms |
| สูงสุด | {b['latency_max_ms']:.3f} ms | {m['latency_max_ms']:.3f} ms |

ไม่ได้ทดสอบ throughput ของบริการหรือการรับโหลดพร้อมกัน อัตราส่วน 1000/latency ไม่ใช่หลักฐานว่ารองรับคำขอจริงได้ตามนั้น

## ผลแยกตามกลุ่ม

| กลุ่ม | คำตอบหรือสถานะตรงเกณฑ์ | REVIEW |
|---|---:|---:|
{rows}

ชุดข้อมูลส่วนใหญ่เป็น synthetic fixtures ที่มี template ร่วมกันข้าม splits ส่วนใหม่ประกอบด้วย representation transfer, graph topology และ text contrast จึงยังไม่ใช่หลักฐานของ general reasoning ทุกโดเมน มีกรณีซ้ำภายใน holdout บางส่วนโดยตั้งใจวัดเส้นทางเดียวกัน; ไม่ควรตีความ 270 กรณีเป็น 270 โจทย์อิสระ ดูจำนวน unique ใน dataset manifest

## วิธีเริ่มทดลอง

แตก ZIP แล้วเปิด terminal ในโฟลเดอร์โครงการ ใช้ Python 3.12 บน Linux หรือ Colab ไม่มีแพ็กเกจเสริมและไม่ต้องใช้ API key

```bash
python3 lab.py solve examples/problem.json --memory-dir runs/verified-final
python3 run_experiment.py
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

คำสั่งแรกทดลองข้อมูลใหม่ด้วยความจำที่ผ่าน gate คำสั่งที่สองทำ learning → validation → holdout ใหม่และเก็บผลในโฟลเดอร์ run ชื่อใหม่ คำสั่งที่สามตรวจโปรแกรม คำตอบของตัวอย่างคือ 21.5 พร้อมวิธี `table_median`

หากมีชุดโจทย์ของตัวเอง ให้ใช้ JSONL สำหรับ inputs และ labels แยกกัน แล้วรัน:

```bash
python3 lab.py learn learning_inputs.jsonl learning_labels.jsonl validation_inputs.jsonl validation_labels.jsonl --label-source analyst_verified --output runs/my-experiment
python3 lab.py evaluate holdout_inputs.jsonl holdout_labels.jsonl --memory-dir runs/my-experiment --output my-holdout-results.json
```

ใส่ `--base-memory-dir runs/verified-final` ในคำสั่ง learn เมื่อต้องการเริ่มจากความจำเก่า ต้องมีผลยืนยันจริงรองรับ label-source; ตัวเลือกนี้ไม่ใช่การรับรองว่าไฟล์เฉลยถูกอัตโนมัติ

สำหรับโทรศัพท์ อ่านแผนภาพและผลทดลองได้จากคู่มือนี้ การรัน Python ต้องผ่านสภาพแวดล้อมอย่าง Colab หรือคอมพิวเตอร์ ZIP ไม่ใช่แอป iPhone ที่เปิดแล้วทำงานเอง

## หลักฐานและการทำซ้ำ

`runs/verified-final/` มีโจทย์/เฉลยแยกไฟล์, รายการ attempts, candidate/active memory, gate, source hashes, manifest และผลตรวจตัวเลข `reports/tests-37.log` เป็นผล regression tests ที่รันจริง `provenance/` ระบุจุดเริ่มต้นและผลเดิมโดยไม่เปลี่ยนประวัติ v7/v8

รอบแรกของวันที่ 14 หยุดก่อน training เพราะพบโจทย์ซ้ำข้ามชุด จากนั้นแก้การสุ่มตัวเลขตาม protocol correction ผล final เป็นการตรวจซ้ำชุดเดิมหลังแก้ API ความจำและการบันทึก solver failures ไม่มีการแก้ semantic solver ให้จำคำตอบ holdout ความจำหลังจบ holdout ตรงกับก่อนเปิดชุดสอบ

แนวทางแยกเกณฑ์/ข้อมูลประเมินและตรวจความสามารถจริงสอดคล้องกับ [เอกสารประเมินระบบของ OpenAI](https://developers.openai.com/api/docs/guides/evaluation-best-practices) ผลตัวเลขทั้งหมดข้างต้นมาจากการรันห้องทดลองนี้ ไม่ได้อ้างคะแนนระบบอื่น
'''
(ROOT/'BLACK_SWAN_GUIDE_TH.md').write_text(report)
(ROOT/'README.md').write_text('''# Black Swan General Decision Lab

ห้องทดลองการเลือกวิธีแก้ปัญหา ตรวจคำตอบ ลองแก้ใหม่ และเรียนรู้จากผลยืนยัน สำหรับข้อมูลหลายรูปแบบ

เริ่มอ่าน [คู่มือและผลทดลองภาษาไทย](BLACK_SWAN_GUIDE_TH.md) โครงสร้างครบ 8 ส่วน; regression 37 รายการผ่าน; benchmark มีข้อผิดพลาดทางความหมาย 10 กรณีที่บันทึกไว้ชัดเจน

Python 3.12 / Linux (tested), standard library only:

```bash
python3 lab.py solve examples/problem.json --memory-dir runs/verified-final
python3 lab.py solve examples/cases.jsonl --memory-dir runs/verified-final
python3 run_experiment.py
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 audit_results.py runs/verified-final
```

- `src/black_swan_general/`: 8 components, explicit adapters, isolated execution, input readers.
- `lab.py`: solve/evaluate/learn on your own inputs and separately verified labels.
- `configs/experiment.lock.json`: predefined seeds, counts, provisional gates and claim limits.
- `schemas/`, `examples/`, `docs/`: contracts, working examples, architecture and experiment template.
- `runs/verified-final/`: primary measured evidence. Older runs are retained as provenance.
- `data/raw/`: historical CMS-attributed transformed snapshot, not re-fetched upstream.
- `reports/`, `provenance/`: tests, original code identities, corrections and source map.

This standalone lab is package 0.2.0, not Logic v9. The private `back_swan` main branch remains the historical Logic v8 experiment. No production policies, paid API calls, external messages or live data connectors are activated by running this package.

Memory learns strategy ranking; it does not generate arbitrary algorithms or train neural weights. Read the measured boundaries in the Thai guide before interpreting the benchmark.
''')
# Independent byte check: solver/engine/generator identity matches the final measured run.
for relative,expected in s['source_hashes'].items():
    actual=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    assert actual==expected, relative
print('Guide created; all benchmark source hashes match.')
