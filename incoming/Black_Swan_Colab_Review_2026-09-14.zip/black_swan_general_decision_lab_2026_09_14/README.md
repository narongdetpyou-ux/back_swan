# Black Swan General Decision Lab — 0.2.1

ห้องทดลองเลือกวิธีแก้ปัญหา ตรวจคำตอบ ลองวิธีอื่น และเรียนรู้จากผลยืนยัน

เริ่มจาก [สมุดทดลอง Colab](notebooks/Black_Swan_Colab_Reviewed.ipynb) และ [ผลตรวจไฟล์ของผู้ใช้ภาษาไทย](COLAB_REVIEW_TH.md)
องค์ประกอบ 8 ส่วนเชื่อมกัน; 45 tests ผ่าน; เพิ่ม recurrence solver สองวิธีและชุดทดลองจากไฟล์ Untitled7
ข้อจำกัดข้อความ 10 เคสในชุดเดิมยังคงอยู่

```bash
python3 run_user_experiments.py --run-tests
python3 lab.py solve examples/recurrence.json --memory-dir runs/notebook-20260914T133001876329Z
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

- src/black_swan_general: core 8 ส่วน และ 23 strategies
- experiments/: fixtures, source audit และการทดลองประกอบ
- run_user_experiments.py: การทดลองต่อจากไฟล์ Colab พร้อม gate และ raw evidence
- colab_runner.py: ตัวเริ่มรัน Python ปกติ
- notebooks/: สมุดทดลองพร้อม outputs ที่รันจริงตามลำดับ Python
- runs/notebook-20260914T133001876329Z/: ผลส่งมอบฉบับนี้
- runs/verified-final/: ผลฐาน 0.2.0 ที่เก็บไว้
- provenance/user_colab_original_2026_09_14.py: ต้นฉบับครบก่อนจัดระเบียบ
- docs/CONTRACTS.md: รูปแบบข้อมูลและขอบเขตทุก objective

Core ใช้ Python standard library; กราฟใน notebook ใช้ Matplotlib
Notebook ตรวจด้วย sequential Python runner เพราะไม่มี Jupyter kernel ในสภาพแวดล้อมนี้
แพ็กเกจนี้เป็น General Decision Lab 0.2.1; ไม่ได้เปลี่ยนสาย Logic v8 ใน GitHub เป็น v9
