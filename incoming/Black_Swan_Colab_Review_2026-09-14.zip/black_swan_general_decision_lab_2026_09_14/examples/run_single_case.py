#!/usr/bin/env python3
"""Small example showing memory-backed strategy selection."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from black_swan_general import BlackSwanGeneralEngine, OutcomeMemory, ProblemRequest


from black_swan_general.io import load_release
release_dir = ROOT / "runs" / "verified-2026-09-14-r2"
memory = load_release(release_dir) if release_dir.exists() else OutcomeMemory()
engine = BlackSwanGeneralEngine(memory=memory)

request = ProblemRequest(
    problem_id="example-001",
    objective="forecast_next",
    payload={"values": [2, 5, 8, 11, 14, 17]},
    risk_level="low",
)
decision = engine.decide(request)
print(f"route={decision.route}")
print(f"answer={decision.answer}")
print(f"strategy={decision.selected_strategy}")
print(f"reason={decision.reason_code}")
print(f"memory_used={decision.memory_used}")

