"""Reviewed fixtures derived from the user's source plus actual traversal controls."""
from black_swan_general.contracts import ProblemRequest, EvaluationCase


def probe_cases():
    cases = []
    def add(name, objective, payload, *, constraints=None, risk='low', answer=None, route=None, scope='original_intent'):
        request = ProblemRequest(name, objective, payload, constraints or {}, risk)
        cases.append(EvaluationCase(request,scope,'probe',answer,route))
    robust = {'column':'data','missing_semantics':'robust'}
    add('matrix-20','matrix_trace',[[i+j for j in range(20)] for i in range(20)],answer=380)
    add('missing-most','column_summary',{'columns':{'data':[None,None,None,None,42.0,None,None]}},constraints=robust,answer=42)
    add('high-risk-exact','matrix_trace',[[1,2],[3,4]],risk='high',answer=5)
    add('empty','column_summary',{},route='NEED_MORE_DATA')
    add('ragged','matrix_trace',[[1,2],[3]],route='CANNOT_SOLVE')
    add('missing-all','column_summary',{'columns':{'data':[None,None,None]}},constraints=robust,route='NEED_MORE_DATA')
    add('unknown-objective','unsupported_action_xyz',[1,2,3],route='CANNOT_SOLVE')
    add('table-for-trace','matrix_trace',{'columns':{'A':[1,2,3],'B':[4,5,6]}},risk='high',route='REVIEW')
    add('nested-cell','column_summary',{'columns':{'data':[[],[None],[None,None]]}},constraints=robust,route='CANNOT_SOLVE')
    add('tensor-for-trace','matrix_trace',[[[1,2],[3,4]],[[5,6],[7,8]]],route='CANNOT_SOLVE')
    add('tree','column_summary',{'node_id':'root','value':10,'children':[
        {'node_id':'child_a','value':20,'children':[{'node_id':'child_a_1','value':None,'children':[]}]},
        {'node_id':'child_b','value':30,'children':[]}]},
        constraints={'column':'value','missing_semantics':'robust'},route='CANNOT_SOLVE')
    add('finite-repeated-id','matrix_trace',{'node':{'id':'A','parent':{'id':'B','parent':{'id':'A'}}}},route='CANNOT_SOLVE')
    add('opaque-ring-1000','column_summary',{'nodes':[{'node_id':f'node_{i}','value':float(i),
        'connections':[f'node_{(i+1)%1000}']} for i in range(1000)]},
        constraints={'column':'value','missing_semantics':'robust'},risk='high',route='REVIEW')
    add('opaque-2000','column_summary',{'matrix_disguised_as_nodes':[{'node_id':f'node_{i}','value':float(i*1.5),
        'links':[f'node_{(i+3)%2000}',f'node_{(i*7)%2000}']} for i in range(2000)]},
        constraints={'column':'value','missing_semantics':'robust'},route='CANNOT_SOLVE')
    add('opaque-clique-30','column_summary',{'nodes_clique':[{'node_id':f'node_{i}','value':100.0,
        'dependencies':[f'node_{j}' for j in range(30)]} for i in range(30)]},
        constraints={'column':'value','missing_semantics':'robust'},route='CANNOT_SOLVE')
    for n,shape in ((1000,'ring'),(30,'clique')):
        nodes = [str(i) for i in range(n)]
        edges = [[str(i),str((i+1)%n)] for i in range(n)] if shape == 'ring' else [
            [str(i),str(j)] for i in range(n) for j in range(n)]
        add(f'traversal-{shape}-{n}','reachable',{'nodes':nodes,'edges':edges,'source':'0','target':str(n-1),'directed':True},
            answer=True,scope='actual_graph_traversal')
    add('disconnected-cycle','reachable',{'nodes':['a','b','c'],'edges':[['a','b'],['b','a']],
        'source':'a','target':'c','directed':True},answer=False,scope='actual_graph_traversal')
    add('sequence-user-corrected','count_items',[2,4,6,8,10],answer=5,scope='corrected_user_request')
    return cases


def recurrence_case(identifier, split, steps, a, b):
    request = ProblemRequest(identifier,'recurrence_value',{'recurrence':'muller_5_6','steps':steps,'weights':[a,b]})
    # Evaluator oracle: integer linear recurrence. Does not call a solver or verifier.
    ys = [a+b,5*a+6*b,25*a+36*b]
    for _ in range(3,steps+2):
        ys.append(111*ys[-1]-1130*ys[-2]+3000*ys[-3])
    expected = ys[steps+1]/ys[steps]
    return EvaluationCase(request,'numerical_recurrence',split,expected,numeric_tolerance=1e-9)


def recurrence_splits():
    return {
        'learning':[recurrence_case(f'learn-num-{i}','learning',28+i,2+i,3+i) for i in range(12)],
        'validation':[recurrence_case(f'val-num-{i}','validation',42+i,30+i,41+i) for i in range(8)],
        'holdout':[recurrence_case(f'hold-num-{i}','holdout',60+i,70+i,91+i) for i in range(12)]}
