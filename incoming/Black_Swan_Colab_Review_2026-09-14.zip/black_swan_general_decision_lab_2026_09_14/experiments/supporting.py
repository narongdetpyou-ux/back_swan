"""Bounded scientific demonstrations. These do not call Black Swan Core."""
from collections import Counter
from decimal import Decimal, localcontext
import itertools
import math
import random
import struct
import time


def buffon(needles=20000, length=1.0, distance=1.0, seed=91452):
    if type(needles) is not int or not 1 <= needles <= 1000000:
        raise ValueError('needles must be between 1 and 1000000')
    if not all(type(x) in (int, float) and math.isfinite(x) for x in (length, distance)):
        raise ValueError('finite lengths required')
    if not 0 < length <= distance:
        raise ValueError('short-needle formula requires 0 < length <= distance')
    rng = random.Random(seed)
    hits = sum(rng.random()*distance/2 <= length/2*math.sin(rng.random()*math.pi/2)
               for _ in range(needles))
    p, z = hits/needles, 1.959963984540054
    denominator = 1 + z*z/needles
    center = (p + z*z/(2*needles))/denominator
    radius = z*math.sqrt(p*(1-p)/needles + z*z/(4*needles**2))/denominator
    low, high = max(0, center-radius), min(1, center+radius)
    factor = 2*length/distance
    estimate = factor/p if hits else None
    return {'seed':seed, 'needles':needles, 'hits':hits, 'estimate':estimate,
            'absolute_error':abs(estimate-math.pi) if estimate is not None else None,
            'approx_95pct_interval':[factor/high, factor/low if low > 0 else None],
            'interval_method':'Wilson interval for crossing probability, monotonically transformed',
            'scope':'Simulation uses math.pi to draw angles; not a derivation of pi without knowing pi.'}


def ramanujan(terms=3, precision=50):
    if type(terms) is not int or not 1 <= terms <= 10 or type(precision) is not int or not 25 <= precision <= 100:
        raise ValueError('bounded positive terms and precision required')
    reference = Decimal('3.141592653589793238462643383279502884197169399375105820974944592307816406286')
    with localcontext() as ctx:
        ctx.prec = precision
        constant = 2*Decimal(2).sqrt()/9801
        total = Decimal(0)
        rows = []
        for k in range(terms):
            total += Decimal(math.factorial(4*k))*(1103+26390*k)/(Decimal(math.factorial(k))**4*Decimal(396)**(4*k))
            value = 1/(constant*total)
            rows.append({'terms':k+1,'estimate':str(value),'absolute_error':str(abs(value-reference))})
    return {'precision':precision,'rows':rows,'reference':str(reference),
            'scope':'Finite-series approximation, not exact equality to pi.'}


def verify_subset(numbers, target, indices):
    return (isinstance(indices, list) and all(type(i) is int and 0 <= i < len(numbers) for i in indices)
            and len(indices) == len(set(indices)) and sum(numbers[i] for i in indices) == target)


def _subset_input(numbers, target):
    if len(numbers) > 32 or type(target) is not int or any(type(x) is not int for x in numbers):
        raise ValueError('at most 32 integer values and an integer target required')


def subset_bruteforce(numbers, target, max_checks=100000):
    _subset_input(numbers, target)
    if type(max_checks) is not int or max_checks < 1:
        raise ValueError('positive search budget required')
    checked = 0
    for size in range(len(numbers)+1):
        for indices in itertools.combinations(range(len(numbers)), size):
            if checked >= max_checks:
                return {'status':'BUDGET_EXHAUSTED','indices':None,'checked':checked}
            checked += 1
            if sum(numbers[i] for i in indices) == target:
                return {'status':'SOLVED','indices':list(indices),'checked':checked}
    return {'status':'UNSAT','indices':None,'checked':checked}


def subset_mitm(numbers, target):
    _subset_input(numbers, target)
    cut = len(numbers)//2
    left = {0:[]}
    for i in range(cut):
        left.update({value+numbers[i]:indices+[i] for value,indices in list(left.items())})
    right = {0:[]}
    for i in range(cut,len(numbers)):
        right.update({value+numbers[i]:indices+[i] for value,indices in list(right.items())})
    for value,indices in right.items():
        if target-value in left:
            return {'status':'SOLVED','indices':left[target-value]+indices,'stored_sums':len(left)+len(right)}
    return {'status':'UNSAT','indices':None,'stored_sums':len(left)+len(right)}


def subset_experiments(seed=91453):
    rng = random.Random(seed)
    rows = []
    for n in (15,20,24):
        numbers = [rng.randint(10,500) for _ in range(n)]
        target = sum(numbers[i] for i in rng.sample(range(n),max(3,n//4)))
        started = time.perf_counter_ns()
        result = subset_bruteforce(numbers,target)
        search_ms = (time.perf_counter_ns()-started)/1e6
        started = time.perf_counter_ns()
        accepted = verify_subset(numbers,target,result['indices'])
        verify_ms = (time.perf_counter_ns()-started)/1e6
        rows.append({'n':n,'numbers':numbers,'target':target,'possible_subsets':2**n,
                     **result,'verified':accepted,'search_ms':search_ms,'verify_ms':verify_ms})
    numbers, target = list(range(2,50,2)), 999
    capped = subset_bruteforce(numbers,target,max_checks=1000)
    alternative = subset_mitm(numbers,target)
    return {'seed':seed,'planted_cases':rows,'bounded_no_solution_case':{'numbers':numbers,'target':target,
            'first':capped,'alternative':alternative},'forged_index_rejected':not verify_subset([2,4],6,[0,0,0]),
            'empty_solution':subset_bruteforce([],0),
            'scope':'Early-exit examples and one bounded case; not an empirical proof of P versus NP.'}


def entropy(tokens):
    if not tokens:
        return 0.0
    return -sum((c/len(tokens))*math.log2(c/len(tokens)) for c in Counter(tokens).values())


def encode_action(action):
    values = [action[k] for k in ('p','t','f')]
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in values):
        raise ValueError('three finite numbers required')
    return struct.pack('!3d',*values).hex()


def decode_action(packet):
    if not isinstance(packet,str) or len(packet) != 48:
        return None
    try:
        values = struct.unpack('!3d',bytes.fromhex(packet))
    except (ValueError,struct.error):
        return None
    if not all(math.isfinite(v) for v in values):
        return None
    return dict(zip(('p','t','f'),values))


def task_succeeds(action, target):
    return action is not None and all(abs(action[k]-target[k]) < .01 for k in target)


def protocol_experiments(seed=91454):
    rng = random.Random(seed)
    rows = []
    for i in range(12):
        target = {'p':rng.uniform(80,120),'t':rng.uniform(260,290),'f':rng.uniform(400,460)}
        packet = encode_action(target)
        # Receiver sees bytes only. Neither labels nor target nor mode reach it.
        shuffled = packet[16:32]+packet[:16]+packet[32:]
        random_packet = bytes(rng.randrange(256) for _ in range(24)).hex()
        rows.append({'id':i,'target':target,'packet':packet,
                     'success':task_succeeds(decode_action(packet),target),
                     'shuffled_success':task_succeeds(decode_action(shuffled),target),
                     'truncated_success':task_succeeds(decode_action(packet[:-2]),target),
                     'random_success':task_succeeds(decode_action(random_packet),target),
                     'entropy_bytes':entropy(bytes.fromhex(packet)),
                     'random_entropy_bytes':entropy(bytes.fromhex(random_packet))})
    return {'seed':seed,'rows':rows,'scope':'Handwritten encoder/decoder validity and controls; no model evolution or model-collapse claim.'}


def evidence_assessment(observations):
    """Return observed associations and missing evidence without identifying a culprit."""
    known = {k:v for k,v in observations.items() if v is not None}
    missing = [k for k in ('badge_owner','sensor_count','device_owner','operator_identity') if observations.get(k) is None]
    tensions = []
    if known.get('badge_owner') and known.get('sensor_count') == 0:
        tensions.append('Badge event and zero sensor reading need timing/sensor reconciliation.')
    return {'observed':known,'unresolved_personal_attribution':True,'culprit':None,
            'tensions':tensions,'information_needed':missing,
            'scope':'A device or account owner does not establish the operator at the event time.'}
