"""Source-only audit: do not execute the exported notebook's top-level cells."""
import ast
import hashlib
import io
import re
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace


def inspect_source(path):
    path = Path(path)
    source = path.read_text(encoding='utf-8')
    try:
        compile(source,str(path),'exec')
        compile_error = None
    except SyntaxError as error:
        compile_error = {'line':error.lineno,'message':error.msg}
    # Remove IPython shell syntax only to inspect class/function definitions.
    normalized = re.sub(r'^(\s*)!.*$',r'\1pass',source,flags=re.M)
    tree = ast.parse(normalized)
    definitions = {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    safe_names = ['verify_solution','AgentSimulator','AdvancedInvestigatorAgent']
    module = ast.Module(body=[definitions[n] for n in safe_names],type_ignores=[])
    import random
    namespace = {'math':__import__('math'),'random':random.Random(0),'time':SimpleNamespace(sleep=lambda _:None)}
    # These three definitions have been read and contain no external actions.
    exec(compile(module,'reviewed-original-definitions','exec'),namespace)
    simulator = namespace['AgentSimulator']
    tokens = simulator.generate_protocol()['tokens']
    changed = list(tokens); changed[1] = 'UNRELATED_TOKEN'
    target = {'p':101.3,'t':273.15,'f':432.0}
    assignment = next(n for n in tree.body if isinstance(n,ast.Assign)
                      and any(isinstance(t,ast.Name) and t.id == 'EVIDENCE_GRAPH' for t in n.targets))
    evidence = ast.literal_eval(assignment.value)
    evidence['workstation_forensics']['Charlie_PC']['active_scripts'] = ['No incriminating script found']
    namespace['EVIDENCE_GRAPH'] = evidence
    captured = io.StringIO()
    with redirect_stdout(captured):
        namespace['AdvancedInvestigatorAgent']().start_investigation()
    findings = {
        'plain_python_compile_error':compile_error,
        'shell_magic_lines':[i for i,line in enumerate(source.splitlines(),1) if line.lstrip().startswith('!')],
        'python_null_lines':[n.lineno for n in ast.walk(tree) if isinstance(n,ast.Name) and n.id == 'null'],
        'subset_sum_verifier_accepts_unavailable_value':namespace['verify_solution']([999],999),
        'original_protocol_ignores_nonkey_token_mutation':simulator.receiver_interpret(changed,'evolved') == target,
        'original_protocol_ignores_token_order':simulator.receiver_interpret(list(reversed(tokens)),'evolved') == target,
        'original_investigator_blames_charlie_after_evidence_removed':'ผู้ก่อการตัวจริง: Charlie' in captured.getvalue(),
        'has_literal_metrics_assignments':all(name in source for name in ('baseline_metrics = {','learned_metrics = {')),
        'contains_production_approval_claim':'APPROVED FOR PRODUCTION' in source,
        'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'source_lines':len(source.splitlines()),
        'execution_outputs_in_export':False,
        'scope':'Inspected source and controlled definitions only; no claim to have replayed the user Colab session.'}
    return findings
