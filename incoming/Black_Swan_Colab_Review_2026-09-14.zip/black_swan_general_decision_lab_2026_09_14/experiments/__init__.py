"""Reproducible companions to the user's Colab experiments."""
