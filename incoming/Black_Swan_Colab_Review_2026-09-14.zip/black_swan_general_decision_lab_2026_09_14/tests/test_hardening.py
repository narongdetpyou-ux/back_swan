import math
import multiprocessing as mp
import time
import unittest
from dataclasses import replace
from black_swan_general import BlackSwanGeneralEngine, EngineConfig, OutcomeMemory, ProblemRequest
from black_swan_general.contracts import CandidateAnswer, EvaluationCase
from black_swan_general.evaluation import collect_verified_outcomes, evaluate_engine
from black_swan_general.generators import generate_known_cases
from black_swan_general.interpreter import DataInterpreter
from black_swan_general.learning_gate import LearningGate
from black_swan_general.strategies import Strategy, StrategyRegistry, DEFAULT_STRATEGIES
from black_swan_general.verifier import Verifier


def hanging(request, profile):
    while True:
        time.sleep(.01)


def crashing(request, profile):
    raise RuntimeError('injected fault')


def forged(request, profile):
    return CandidateAnswer('forged', 999, {'method':'matrix_total'}, 'claims to be correct')


def mutating(request, profile):
    request.payload[0][0] = 999
    return CandidateAnswer('mutating', 999, {'method':'matrix_total'}, 'mutates its input')


class HardeningTests(unittest.TestCase):
    def test_recomputation_rejects_forged_answers_for_exact_families(self):
        cases = generate_known_cases('validation', per_family=1, seed=32)
        cases += [EvaluationCase(ProblemRequest('m','matrix_total', [[2,3]]),'m','validation',5),
                  EvaluationCase(ProblemRequest('c','count_items',['a','b']),'s','validation',2)]
        engine = BlackSwanGeneralEngine()
        checked = 0
        for case in cases:
            d = engine.decide(case.request)
            if d.route != 'SOLVED':
                continue
            attempt = next(a for a in d.attempts if a.candidate and a.candidate.strategy == d.selected_strategy)
            wrong = not d.answer if type(d.answer) is bool else 999 if isinstance(d.answer,(float,int)) else 'wrong'
            result = Verifier().verify(case.request,d.data_profile,replace(attempt.candidate,answer=wrong))
            self.assertFalse(result.accepted,case.family)
            checked += 1
        self.assertGreaterEqual(checked,8)

    def test_wrong_solver_is_corrected_by_alternative(self):
        registry=StrategyRegistry((Strategy('forged','matrix',('matrix_total',),forged),)+DEFAULT_STRATEGIES)
        d=BlackSwanGeneralEngine(registry=registry).decide(ProblemRequest('f','matrix_total',[[1,2]]))
        self.assertEqual((d.route,d.answer),('SOLVED',3))
        self.assertEqual(len(d.attempts),2)
        self.assertEqual(d.attempts[0].verification.reason_code,'ANSWER_RECOMPUTATION_MISMATCH')

    def test_solver_cannot_mutate_verifier_input(self):
        registry=StrategyRegistry((Strategy('mutating','matrix',('matrix_total',),mutating),)+DEFAULT_STRATEGIES)
        payload=[[1]]
        d=BlackSwanGeneralEngine(registry=registry).decide(ProblemRequest('mutate','matrix_total',payload))
        self.assertEqual(d.answer,1)
        self.assertEqual(payload,[[1]])
        self.assertFalse(d.attempts[0].verification.accepted)

    def test_crash_recovers_with_alternative(self):
        registry=StrategyRegistry((Strategy('crashing','matrix',('matrix_total',),crashing),)+DEFAULT_STRATEGIES)
        d=BlackSwanGeneralEngine(registry=registry).decide(ProblemRequest('crash','matrix_total',[[2]]))
        self.assertEqual((d.route,d.answer),('SOLVED',2))
        self.assertTrue(d.attempts[0].error)

    def test_hang_is_cancelled_and_next_request_works(self):
        registry=StrategyRegistry((Strategy('hanging','matrix',('matrix_total',),hanging),))
        engine=BlackSwanGeneralEngine(registry=registry,config=EngineConfig(time_budget_ms=60))
        initial={p.pid for p in mp.active_children()}
        started=time.monotonic()
        d=engine.decide(ProblemRequest('hang','matrix_total',[[1]]))
        self.assertLess(time.monotonic()-started, .6)
        self.assertEqual(d.terminal_reason,'TIME_BUDGET_EXHAUSTED')
        self.assertNotIn(d.route,{'SOLVED','BEST_EFFORT'})
        self.assertEqual({p.pid for p in mp.active_children()},initial)
        self.assertEqual(BlackSwanGeneralEngine().decide(ProblemRequest('next','count_items',['a'])).answer,1)

    def test_cycle_deep_and_invalid_constraints_are_rejected_before_interpretation(self):
        cyclic=[];cyclic.append(cyclic)
        deep=0
        for _ in range(40): deep=[deep]
        for payload,constraints in [(cyclic,{}),(deep,{}),({'values':[1,2]}, {'period':'bad'}),(1, []),(1, {'x':math.nan})]:
            d=BlackSwanGeneralEngine().decide(ProblemRequest('bad','forecast_next',payload,constraints))
            self.assertEqual(d.route,'CANNOT_SOLVE')
            self.assertFalse(d.attempts)

    def test_empty_sequence_is_zero_not_missing(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('empty','count_items',[]))
        self.assertEqual((d.route,d.answer),('SOLVED',0))

    def test_missing_column_semantics_requests_specific_information(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('unknown','column_summary',[{'value':1},{'value':None}]))
        self.assertEqual(d.route,'NEED_MORE_DATA')
        self.assertIn('MISSING_SEMANTICS_UNSPECIFIED',d.information_needed)

    def test_invalid_numeric_rows_are_not_silently_dropped(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('bad','column_summary',[{'value':2},{'value':'bad'}],{'missing_semantics':'unknown'}))
        self.assertEqual(d.route,'CANNOT_SOLVE')

    def test_missing_fact_does_not_match_null_condition(self):
        p={'facts':{},'rules':[{'when':{'x':None},'result':'wrong'},{'when':{},'result':'default'}]}
        d=BlackSwanGeneralEngine().decide(ProblemRequest('null','rule_decision',p,{'precedence':'first'}))
        self.assertEqual(d.answer,'default')

    def test_non_square_trace_not_certified(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('rect','matrix_trace',[[1,2,3],[4,5,6]]))
        self.assertEqual(d.route,'CANNOT_SOLVE')

    def test_untrusted_weight_inside_payload_is_ignored(self):
        p={'components':[{'source':'a','vote':True,'trust':10000},{'source':'b','vote':False,'trust':0}]}
        c={'aggregation':'trust_weighted','source_weights':{'a':.1,'b':.9}}
        d=BlackSwanGeneralEngine().decide(ProblemRequest('weights','evidence_decision',p,c))
        self.assertEqual(d.answer,'reject')
        d=BlackSwanGeneralEngine().decide(ProblemRequest('weights','evidence_decision',p,{'aggregation':'trust_weighted'}))
        self.assertEqual(d.route,'NEED_MORE_DATA')

    def test_no_unsupported_language_certified_as_neutral(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('thai','sentiment','ฉันไม่ชอบสิ่งนี้'))
        self.assertEqual(d.route,'CANNOT_SOLVE')

    def test_forecasts_remain_best_effort(self):
        d=BlackSwanGeneralEngine().decide(ProblemRequest('future','forecast_next',{'values':[1,3,5,7]}))
        self.assertEqual(d.route,'BEST_EFFORT')

    def test_holdout_cannot_write_to_memory(self):
        cases=generate_known_cases('holdout',per_family=1,seed=3)
        memory=OutcomeMemory()
        with self.assertRaises(ValueError):
            collect_verified_outcomes(BlackSwanGeneralEngine(),cases,memory)
        self.assertEqual(len(memory),0)

    def test_fallback_correctness_does_not_count_as_problem_solved(self):
        cases=[EvaluationCase(ProblemRequest('unknown','invent',{'new':1}),'unknown','test',evaluator_expected_route='CANNOT_SOLVE')]
        m=evaluate_engine(BlackSwanGeneralEngine(),cases)['metrics']
        self.assertEqual(m['contract_accuracy'],1)
        self.assertEqual(m['task_success_rate'],0)
        self.assertEqual(m['correct_answers'],0)

    def test_gate_rejects_nan_empty_and_hidden_family_regression(self):
        m={'cases':10,'task_success_rate':.8,'false_confidence_rate':0,'review_rate':0,'error_rate':0}
        gate=LearningGate()
        self.assertFalse(gate.evaluate(m,{**m,'task_success_rate':math.nan},label_sources=['synthetic_oracle']).passed)
        self.assertFalse(gate.evaluate({**m,'cases':0},{**m,'cases':0},label_sources=['synthetic_oracle']).passed)
        b={'a':{'cases':5,'success_rate':1},'b':{'cases':5,'success_rate':.6}}
        c={'a':{'cases':5,'success_rate':.6},'b':{'cases':5,'success_rate':1}}
        self.assertFalse(gate.evaluate(m,m,label_sources=['synthetic_oracle'],baseline_families=b,candidate_families=c).passed)

    def test_columnar_adapter_reuses_table_memory_without_retraining(self):
        cases=generate_known_cases('learning',per_family=3,seed=88)
        memory=OutcomeMemory()
        collect_verified_outcomes(BlackSwanGeneralEngine(),cases,memory)
        p=ProblemRequest('new-layout','column_summary',{'columns':{'value':[20,21,22,None,200]}},{'missing_semantics':'robust'})
        before=BlackSwanGeneralEngine().decide(p)
        after=BlackSwanGeneralEngine(memory=memory).decide(p)
        self.assertEqual(after.answer,21.5)
        self.assertTrue(after.memory_used)
        self.assertEqual(after.adapter,'columnar_to_table')
        self.assertLess(len(after.attempts),len(before.attempts))

if __name__=='__main__': unittest.main()

class MemoryFailureTests(unittest.TestCase):
    def test_failed_attempt_is_learned_and_not_repeated_first(self):
        registry=StrategyRegistry((Strategy('crashing','matrix',('matrix_total',),crashing),)+DEFAULT_STRATEGIES)
        engine=BlackSwanGeneralEngine(registry=registry)
        memory=OutcomeMemory()
        cases=[EvaluationCase(ProblemRequest(f'learn-crash-{i}','matrix_total',[[i+2]]),'m','learning',i+2) for i in range(3)]
        collect_verified_outcomes(engine,cases,memory)
        failures=[r for r in memory.all() if r.strategy=='crashing']
        self.assertEqual(len(failures),3)
        self.assertTrue(all(not r.success for r in failures))
        learned=BlackSwanGeneralEngine(registry=registry,memory=memory)
        d=learned.decide(ProblemRequest('new-crash-case','matrix_total',[[13]]))
        self.assertEqual(d.selected_strategy,'matrix_total')
        self.assertEqual(len(d.attempts),1)
