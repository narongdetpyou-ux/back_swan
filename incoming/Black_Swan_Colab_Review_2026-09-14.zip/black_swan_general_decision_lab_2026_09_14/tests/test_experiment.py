from __future__ import annotations

from dataclasses import asdict
import json
import unittest

from black_swan_general import BlackSwanGeneralEngine, OutcomeMemory
from black_swan_general.evaluation import collect_verified_outcomes, evaluate_engine
from black_swan_general.generators import generate_known_cases, generate_novel_holdout
from black_swan_general.learning_gate import LearningGate


def _case_identity(case) -> str:
    request = asdict(case.request)
    request.pop("problem_id")
    return json.dumps(request, sort_keys=True, separators=(",", ":"))


class ExperimentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.learning = generate_known_cases("learning", per_family=15, seed=731_001)
        cls.validation = generate_known_cases("validation", per_family=5, seed=731_002)
        cls.holdout = (
            generate_known_cases("holdout", per_family=10, seed=731_003)
            + generate_novel_holdout(seed=731_103)
        )
        cls.memory = OutcomeMemory()
        collect_verified_outcomes(BlackSwanGeneralEngine(), cls.learning, cls.memory)

    def test_split_counts_and_no_exact_input_leakage(self):
        self.assertEqual(len(self.learning), 180)
        self.assertEqual(len(self.validation), 60)
        self.assertEqual(len(self.holdout), 200)
        identities = [set(map(_case_identity, split)) for split in (
            self.learning, self.validation, self.holdout
        )]
        self.assertFalse(identities[0] & identities[1])
        self.assertFalse(identities[0] & identities[2])
        self.assertFalse(identities[1] & identities[2])

    def test_training_uses_only_trusted_external_labels(self):
        self.assertGreater(len(self.memory), 500)
        self.assertEqual(
            {record.label_source for record in self.memory.all()}, {"synthetic_oracle"}
        )

    def test_learning_gate_and_locked_holdout(self):
        baseline_validation = evaluate_engine(BlackSwanGeneralEngine(), self.validation)
        candidate_validation = evaluate_engine(
            BlackSwanGeneralEngine(memory=self.memory), self.validation
        )
        gate = LearningGate().evaluate(
            baseline_validation["metrics"], candidate_validation["metrics"],
            label_sources=(record.label_source for record in self.memory.all()),
        )
        self.assertTrue(gate.passed)
        self.assertGreaterEqual(
            candidate_validation["metrics"]["task_success_rate"],
            baseline_validation["metrics"]["task_success_rate"],
        )

        self.assertGreater(candidate_validation["metrics"]["first_attempt_success_rate"],
                           baseline_validation["metrics"]["first_attempt_success_rate"])
        holdout = evaluate_engine(BlackSwanGeneralEngine(memory=self.memory), self.holdout)
        metrics = holdout["metrics"]
        self.assertEqual(metrics["cases"], 200)
        self.assertEqual(metrics["error_count"], 0)
        self.assertLessEqual(metrics["review_rate"], 0.05)
        self.assertEqual(metrics["task_success_rate"], 1.0)

    def test_novel_structure_cases_do_not_use_learned_memory(self):
        engine = BlackSwanGeneralEngine(memory=self.memory)
        novel = [case for case in self.holdout if case.family.startswith("novel_")]
        self.assertEqual(len(novel), 60)
        decisions = [engine.decide(case.request) for case in novel]
        self.assertTrue(all(not decision.memory_used for decision in decisions))
        self.assertTrue(all(decision.route == "SOLVED" for decision in decisions))


if __name__ == "__main__":
    unittest.main()

