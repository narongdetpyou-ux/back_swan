from __future__ import annotations

from dataclasses import asdict, replace
import json
from pathlib import Path
import tempfile
import unittest

from black_swan_general import BlackSwanGeneralEngine, OutcomeMemory, ProblemRequest
from black_swan_general.interpreter import DataInterpreter
from black_swan_general.memory import stable_problem_hash
from black_swan_general.selector import StrategySelector
from black_swan_general.strategies import StrategyRegistry


class ComponentTests(unittest.TestCase):
    def test_interpreter_recognizes_supported_structures(self):
        interpreter = DataInterpreter()
        fixtures = [
            (ProblemRequest("a", "sentiment", "not bad"), "text"),
            (ProblemRequest("b", "forecast_next", {"values": [1, 2, 3]}), "time_series"),
            (ProblemRequest("c", "column_summary", [{"value": 1}]), "table"),
            (ProblemRequest("d", "count_items", ["a", "b"]), "sequence"),
            (ProblemRequest("e", "matrix_total", [[1, 2], [3, 4]]), "matrix"),
            (ProblemRequest("f", "unknown", {"new": "shape"}), "opaque"),
        ]
        for request, expected in fixtures:
            with self.subTest(expected=expected):
                self.assertEqual(interpreter.interpret(request).data_type, expected)

    def test_engine_contract_contains_no_evaluator_label(self):
        keys = set(asdict(ProblemRequest("a", "count_items", [1])).keys())
        self.assertEqual(keys, {"problem_id", "objective", "payload", "constraints", "risk_level"})
        self.assertFalse(any("expected" in key or "label" in key for key in keys))

    def test_verified_memory_changes_strategy_ranking(self):
        request = ProblemRequest(
            "rank-1", "forecast_next", {"values": [1, 3, 5, 7, 9, 11]}
        )
        profile = DataInterpreter().interpret(request)
        registry = StrategyRegistry()
        memory = OutcomeMemory()
        source_hash = stable_problem_hash(asdict(request))
        for index in range(3):
            for strategy, success in (("ts_last", False), ("ts_linear", True)):
                memory.add_verified(
                    profile_signature=profile.signature,
                    data_type=profile.data_type,
                    objective=profile.objective,
                    strategy=strategy,
                    success=success,
                    reward=1.0 if success else -1.0,
                    verifier_score=0.78,
                    issue_codes=("TEST_ORACLE",),
                    label_source="synthetic_oracle",
                    source_problem_hash=f"{source_hash}-{index}-{strategy}",
                )
        ranked = StrategySelector(memory).rank(profile, registry.applicable(profile))
        self.assertEqual(ranked[0].strategy, "ts_linear")
        self.assertGreaterEqual(ranked[0].memory_examples, 3)

    def test_memory_rejects_self_labels_and_tampering(self):
        memory = OutcomeMemory()
        with self.assertRaisesRegex(ValueError, "untrusted"):
            memory.add_verified(
                profile_signature="p", data_type="text", objective="sentiment",
                strategy="text_keyword", success=True, reward=1.0,
                verifier_score=0.5, issue_codes=(), label_source="engine_self_label",
                source_problem_hash="x",
            )
        record = memory.add_verified(
            profile_signature="p", data_type="text", objective="sentiment",
            strategy="text_keyword", success=True, reward=1.0,
            verifier_score=0.5, issue_codes=(), label_source="analyst_verified",
            source_problem_hash="x",
        )
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            OutcomeMemory([replace(record, reward=-1.0)])

    def test_memory_round_trip_preserves_hashes(self):
        memory = OutcomeMemory()
        memory.add_verified(
            profile_signature="p", data_type="sequence", objective="count_items",
            strategy="sequence_count", success=True, reward=1.0,
            verifier_score=0.97, issue_codes=("OK",), label_source="synthetic_oracle",
            source_problem_hash="source",
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "memory.jsonl"
            memory.write_jsonl(path)
            loaded = OutcomeMemory.from_jsonl(path)
        self.assertEqual(memory.all(), loaded.all())

    def test_novel_matrix_is_solved_without_memory(self):
        decision = BlackSwanGeneralEngine().decide(
            ProblemRequest("matrix", "matrix_trace", [[1, 2], [3, 4]])
        )
        self.assertEqual(decision.route, "SOLVED")
        self.assertEqual(decision.answer, 5.0)
        self.assertFalse(decision.memory_used)


if __name__ == "__main__":
    unittest.main()

