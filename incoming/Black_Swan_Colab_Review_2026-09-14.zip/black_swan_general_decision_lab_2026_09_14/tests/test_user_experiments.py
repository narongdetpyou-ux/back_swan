"""Tests for demonstrated defects and the numerical extension."""
import math
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from black_swan_general import BlackSwanGeneralEngine
from black_swan_general.contracts import ProblemRequest, CandidateAnswer
from experiments.cases import recurrence_case, recurrence_splits
from experiments.supporting import buffon, decode_action, encode_action, subset_bruteforce, subset_mitm, verify_subset, evidence_assessment


class UserExperimentTests(unittest.TestCase):
    def test_float_instability_is_corrected_by_core(self):
        case = recurrence_case('muller','probe',35,1,1)
        decision = BlackSwanGeneralEngine().decide(case.request)
        self.assertEqual(decision.route,'SOLVED')
        self.assertEqual(decision.selected_strategy,'recurrence_fraction')
        self.assertEqual(len(decision.attempts),2)
        self.assertFalse(decision.attempts[0].verification.accepted)
        self.assertAlmostEqual(decision.answer,case.evaluator_expected_answer,places=9)
        self.assertLess(decision.answer,6)  # finite step is not exactly the limit

    def test_closed_form_verifier_rejects_plausible_wrong_value(self):
        case = recurrence_case('wrong','probe',35,1,1)
        engine = BlackSwanGeneralEngine()
        candidate = CandidateAnswer('recurrence_fraction',6.0,{},'claimed exact')
        result = engine.verifier.verify(case.request,engine.interpreter.interpret(case.request),candidate)
        self.assertFalse(result.accepted)

    def test_recurrence_boundaries_and_invalid_contract(self):
        engine = BlackSwanGeneralEngine()
        for steps in (0,1,2,200):
            case = recurrence_case(f'edge-{steps}','probe',steps,2,7)
            decision = engine.decide(case.request)
            self.assertEqual(decision.route,'SOLVED')
            self.assertAlmostEqual(decision.answer,case.evaluator_expected_answer,places=9)
        for steps in (-1,201,True):
            req = ProblemRequest('bad','recurrence_value',{'recurrence':'muller_5_6','steps':steps,'weights':[1,1]})
            self.assertEqual(engine.decide(req).route,'CANNOT_SOLVE')

    def test_subset_membership_multiplicity_empty_and_budget(self):
        self.assertFalse(verify_subset([2,4],6,[0,0,0]))
        self.assertFalse(verify_subset([2,4],6,[2]))
        self.assertTrue(verify_subset([],0,[]))
        self.assertEqual(subset_bruteforce([],0)['indices'],[])
        self.assertEqual(subset_bruteforce([2,4,6],999,2)['status'],'BUDGET_EXHAUSTED')
        self.assertEqual(subset_mitm([2,4,6],999)['status'],'UNSAT')
        result = subset_mitm([8,-4,3,3],6)
        self.assertTrue(verify_subset([8,-4,3,3],6,result['indices']))

    def test_decoder_gets_no_target_or_mode_and_rejects_bad_bytes(self):
        action = {'p':101.3,'t':273.15,'f':432.0}
        self.assertEqual(decode_action(encode_action(action)),action)
        self.assertIsNone(decode_action('00'))
        self.assertIsNone(decode_action('xx'*24))
        import struct
        self.assertIsNone(decode_action(struct.pack('!3d',math.nan,1,2).hex()))

    def test_seeded_buffon_and_applicable_formula(self):
        self.assertEqual(buffon(100),buffon(100))
        for args in [(0,1,1),(10,2,1),(10,1,0)]:
            with self.assertRaises(ValueError): buffon(*args)

    def test_device_ownership_does_not_certify_person(self):
        result = evidence_assessment({'badge_owner':'A','device_owner':'B','sensor_count':0})
        self.assertIsNone(result['culprit'])
        self.assertIn('operator_identity',result['information_needed'])

    def test_numeric_dataset_roles_are_separate(self):
        splits = recurrence_splits()
        identifiers = []
        for role,cases in splits.items():
            self.assertTrue(all(c.split == role for c in cases))
            identifiers += [c.request.problem_id for c in cases]
        self.assertEqual(len(identifiers),len(set(identifiers)))


if __name__ == '__main__': unittest.main()
