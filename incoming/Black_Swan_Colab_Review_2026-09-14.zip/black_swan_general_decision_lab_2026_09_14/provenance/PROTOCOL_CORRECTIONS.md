# Corrections before final scoring

- Initial 2026-09-14 run stopped at input-overlap validation, before training or grading. Small integer generator ranges produced an identical numeric problem in learning and validation. Replaced the numeric base sampling with seeded continuous sampling; task rules and labels remain unchanged.
- Counting an empty list has the exact answer 0. Historical missing-input fixtures now use null. The previous test conflated a known empty collection with missing input.
- Default attempt budget increased from 2 to 4 so the baseline can try all registered alternatives. The learning regression test now requires no accuracy loss AND improved first-attempt success, rather than requiring artificial initial failures.
- Original files and original report remain identified by the starting-files manifest. No claim that historical 200/200 meant 200 solved tasks is retained.
