#!/usr/bin/env python3
"""Run the reviewed Colab experiment plan in a new evidence directory."""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from black_swan_general import BlackSwanGeneralEngine, OutcomeMemory
from black_swan_general.contracts import ProblemRequest
from black_swan_general.evaluation import collect_verified_outcomes, evaluate_engine
from black_swan_general.generators import input_record, label_record
from black_swan_general.io import load_release, read_cases
from black_swan_general.learning_gate import LearningGate
from black_swan_general.memory import stable_problem_hash
from experiments.cases import probe_cases, recurrence_splits
from experiments.source_audit import inspect_source
from experiments.supporting import buffon, ramanujan, subset_experiments, protocol_experiments, evidence_assessment
from run_experiment import write_json, write_jsonl, sha, without_rows


def run(output, memory_dir, run_tests=False):
    output, memory_dir = Path(output).resolve(), Path(memory_dir).resolve()
    if output.exists():
        raise ValueError('output already exists; choose a new path')
    previous = load_release(memory_dir)
    splits = recurrence_splits()
    identities = {name:{stable_problem_hash(input_record(c)) for c in cases} for name,cases in splits.items()}
    for left,right in [('learning','validation'),('learning','holdout'),('validation','holdout')]:
        if identities[left] & identities[right]:
            raise ValueError('recurrence cross-split duplicate')
    output.mkdir(parents=True)
    source_files = list((ROOT/'src').rglob('*.py'))+list((ROOT/'experiments').glob('*.py'))+[Path(__file__).resolve()]
    protocol = {'version':'0.2.1','base_memory_sha256':sha(memory_dir/'active_memory.jsonl'),
                'counts':{name:len(cases) for name,cases in splits.items()},
                'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in sorted(source_files)},
                'exact_cross_split_overlap':0,
                'scope':'One new recurrence family with changed parameters; existing 270 cases are inspected regression replay.',
                'promotion':'Only verified learning labels; validation gate before final numeric holdout.',
                'acceptance':['all reviewed probe contracts','new recurrence answers independently verified',
                              'gate passes without old-family regression','no memory writes from holdout'],
                'seeds':{'buffon':91452,'subset':91453,'protocol':91454},
                'environment':{'python':sys.version,'platform':platform.platform()},
                'timing':'per-decision wall time includes interpreter, ranking and isolated solver/verifier; no network',
                'production_readiness':'not evaluated'}
    # Persist protocol and input/label splits before evaluating any outcome.
    write_json(output/'protocol.json',protocol)
    for name,cases in splits.items():
        write_jsonl(output/'datasets'/f'{name}_inputs.jsonl',map(input_record,cases))
        write_jsonl(output/'datasets'/f'{name}_labels.jsonl',map(label_record,cases))
    probes = probe_cases()
    write_jsonl(output/'datasets'/'probe_inputs.jsonl',map(input_record,probes))
    write_jsonl(output/'datasets'/'probe_labels.jsonl',map(label_record,probes))
    audit = inspect_source(ROOT/'provenance/user_colab_original_2026_09_14.py')
    write_json(output/'source_audit.json',audit)
    probe_result = evaluate_engine(BlackSwanGeneralEngine(memory=previous),probes)
    write_json(output/'core_probes.json',probe_result)
    # An actual object cycle cannot be represented in JSON; exercise the API.
    cycle = {}; cycle['self'] = cycle
    engine = BlackSwanGeneralEngine(memory=previous)
    started = time.perf_counter_ns()
    cycle_decision = engine.decide(ProblemRequest('actual-object-cycle','count_items',cycle))
    cycle_ms = (time.perf_counter_ns()-started)/1e6
    recovery = engine.decide(ProblemRequest('after-cycle','matrix_trace',[[1,2],[3,4]]))
    cycle_result = {'decision':asdict(cycle_decision),'latency_ms':cycle_ms,'next_decision':asdict(recovery),
                    'scope':'API repeated-container rejection, separate from graph edge cycles.'}
    write_json(output/'object_cycle.json',cycle_result)
    old_validation = read_cases(memory_dir/'datasets/validation_inputs.jsonl',memory_dir/'datasets/validation_labels.jsonl','validation')
    validation = old_validation+splits['validation']
    baseline_validation = evaluate_engine(BlackSwanGeneralEngine(memory=previous),validation)
    candidate_memory = OutcomeMemory(previous.all())
    training = collect_verified_outcomes(BlackSwanGeneralEngine(memory=previous),splits['learning'],candidate_memory)
    candidate_memory.write_jsonl(output/'candidate_memory.jsonl')
    write_jsonl(output/'training_outcomes.jsonl',training)
    candidate_validation = evaluate_engine(BlackSwanGeneralEngine(memory=candidate_memory),validation)
    gate = LearningGate().evaluate(baseline_validation['metrics'],candidate_validation['metrics'],
        label_sources=[r.label_source for r in candidate_memory.all()],
        baseline_families=baseline_validation['by_family'],candidate_families=candidate_validation['by_family'])
    write_json(output/'learning_gate.json',asdict(gate))
    write_json(output/'validation_before.json',baseline_validation)
    write_json(output/'validation_after.json',candidate_validation)
    # Rejecting new learning preserves the old memory object for evaluation.
    active = OutcomeMemory(candidate_memory.all() if gate.passed else previous.all())
    active.write_jsonl(output/'active_memory.jsonl')
    write_json(output/'memory_release.json',{'gate_passed':gate.passed,'memory_file':'active_memory.jsonl',
               'sha256':sha(output/'active_memory.jsonl'),'gate_sha256':sha(output/'learning_gate.json')})
    frozen = sha(output/'active_memory.jsonl')
    new_before = evaluate_engine(BlackSwanGeneralEngine(memory=previous),splits['holdout'])
    new_after = evaluate_engine(BlackSwanGeneralEngine(memory=active),splits['holdout'])
    old_holdout = read_cases(memory_dir/'datasets/holdout_inputs.jsonl',memory_dir/'datasets/holdout_labels.jsonl','holdout')
    old_before = evaluate_engine(BlackSwanGeneralEngine(),old_holdout)
    old_after = evaluate_engine(BlackSwanGeneralEngine(memory=active),old_holdout)
    for name,result in [('numeric_before',new_before),('numeric_after',new_after),
                        ('regression_before',old_before),('regression_after',old_after)]:
        write_json(output/(name+'.json'),result)
    active.write_jsonl(output/'memory_after_holdout.jsonl')
    unchanged = sha(output/'memory_after_holdout.jsonl') == frozen == sha(output/'active_memory.jsonl')
    if not unchanged:
        raise RuntimeError('evaluation mutated memory')
    supporting = {'buffon':buffon(),'ramanujan':ramanujan(),'subset':subset_experiments(),
                  'protocol':protocol_experiments(),
                  'evidence':evidence_assessment({'badge_owner':'Dr. Sarah','sensor_count':0,'device_owner':'Kevin','operator_identity':None})}
    write_json(output/'supporting_experiments.json',supporting)
    checks = {
        'reviewed_probe_contracts':all(row['correct'] for row in probe_result['rows']),
        'graph_traversals_actually_executed':all(row['attempts'] > 0 and row['correct'] for row in probe_result['rows'] if row['family'] == 'actual_graph_traversal'),
        'actual_object_cycle_rejected':cycle_decision.reason_code == 'REPEATED_CONTAINER',
        'next_request_recovers':recovery.route == 'SOLVED' and recovery.answer == 5,
        'learning_gate_passed':gate.passed,
        'numeric_answers_correct':new_after['metrics']['correct_answers'] == len(splits['holdout']),
        'numeric_first_choice_improves':new_after['metrics']['first_attempt_success_rate'] > new_before['metrics']['first_attempt_success_rate'],
        'old_regression_answer_count_preserved':old_after['metrics']['correct_answers'] == 225,
        'old_regression_automatic_errors_not_increased':old_after['metrics']['automatic_wrong_count'] <= 10,
        'memory_frozen_for_holdout':unchanged}
    tests = {'executed':False}
    if run_tests:
        proc = subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,
                              env={**__import__('os').environ,'PYTHONPATH':str(ROOT/'src')},
                              text=True,capture_output=True,timeout=180)
        (output/'tests.log').write_text(proc.stdout+proc.stderr)
        tests = {'executed':True,'returncode':proc.returncode,'log':'tests.log'}
        checks['regression_tests_passed'] = proc.returncode == 0
    summary = {'run':str(output),'version':'0.2.1','checks':checks,'all_checks_passed':all(checks.values()),
        'source_audit':audit,'core_probes':without_rows(probe_result),
        'numerical':{'before':without_rows(new_before),'after':without_rows(new_after)},
        'old_regression':{'before':without_rows(old_before),'after':without_rows(old_after)},
        'learning':{'training_cases':len(splits['learning']),'validation_cases':len(validation),
                    'holdout_cases':len(splits['holdout']),'previous_memory_records':len(previous),
                    'new_outcomes':len(training),'active_memory_records':len(active),'gate_passed':gate.passed},
        'tests':tests,'holdout_memory_unchanged':unchanged,
        'scope':'Core probes and new numerical learning run through all eight components. Supporting math/evidence/protocol demos do not train Core.',
        'known_limit':'The previous natural-language contrast failures remain; no production approval.'}
    write_json(output/'summary.json',summary)
    write_json(output/'dataset_manifest.json',{str(p.relative_to(output)):sha(p) for p in sorted((output/'datasets').glob('*.jsonl'))})
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--memory-dir',type=Path,default=ROOT/'runs/verified-final')
    parser.add_argument('--run-tests',action='store_true')
    args = parser.parse_args(argv)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = args.output or ROOT/'runs'/('user-review-'+stamp)
    result = run(output,args.memory_dir,args.run_tests)
    print(json.dumps({'run':result['run'],'all_checks_passed':result['all_checks_passed'],
                      'checks':result['checks'],'learning':result['learning']},ensure_ascii=False,indent=2))
    return 0 if result['all_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
