#!/usr/bin/env python3
"""Reconcile reported metrics from raw decisions, without re-running/tuning solvers."""
from pathlib import Path
import argparse,json
from collections import Counter

def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args()
    summary=json.loads((a.run/'summary.json').read_text())
    out={}
    for stage in ['baseline','learned']:
        rows=[json.loads(line) for line in (a.run/f'holdout_{stage}_decisions.jsonl').read_text().splitlines()]
        m=summary['holdout'][stage]['metrics']
        counts=Counter(r['route'] for r in rows)
        answerable=[r for r in rows if r['answerable']]
        correct_answers=sum(r['correct'] for r in answerable)
        assert m['correct_answers']==correct_answers
        assert m['review_count']==counts['REVIEW']
        assert m['automatic_answers']==counts['SOLVED']+counts['BEST_EFFORT']
        assert m['task_success_rate']==correct_answers/len(answerable)
        transfer=[r for r in rows if r['family'].startswith('transfer_')]
        out[stage]=dict(metrics_reconciled=True,route_counts=dict(counts),
            harmed_by_later_selection=sum(r['first_attempt_correct'] and not r['correct'] for r in rows),
            correct_first_and_final=sum(r['first_attempt_correct'] and r['correct'] for r in rows),
            transfer_cases=len(transfer),transfer_correct=sum(r['correct'] for r in transfer),
            transfer_mean_attempts=sum(r['attempts'] for r in transfer)/len(transfer),
            transfer_memory_used=sum(r['memory_used'] for r in transfer))
    (a.run/'metric_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
